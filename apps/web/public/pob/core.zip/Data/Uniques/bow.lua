-- Item data (c) Grinding Gear Games

return {
-- Weapon: Bow
[[
Arborix
Assassin Bow
Variant: Pre 3.5.0
Variant: Pre 3.9.0
Variant: Pre 3.11.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 62, 212 Dex
Source: Vendor Recipe
Implicits: 1
{variant:3}+(15-25)% to Global Critical Strike Multiplier
{variant:4,5}Grants Level 30 Dash Skill
{variant:1}Adds (60-70) to (180-210) Physical Damage
{variant:2,3,4}Adds (95-115) to (240-265) Physical Damage
{variant:5}Adds (80-100) to (200-225) Physical Damage
{variant:1,2,3}(80-100)% increased Evasion Rating
{variant:1,2,3}Bow Attacks fire 2 additional Arrows
{variant:4,5}Bow Attacks fire 2 additional Arrows if you haven't Cast Dash recently
{variant:4,5}(20-30)% increased Attack Speed if you haven't Cast Dash recently
{variant:4,5}(100-160)% increased Evasion Rating if you've Cast Dash recently
{variant:4,5}(20-30)% increased Movement Speed if you've Cast Dash recently
{variant:4,5}Travel Skills other than Dash are Disabled
{variant:4,5}Iron Reflexes
{variant:1,2,3}Every 16 seconds you gain Iron Reflexes for 8 seconds
{variant:1,2,3}30% more Damage with Arrow Hits at Close Range while you have Iron Reflexes
{variant:1,2,3}30% increased Attack, Cast and Movement Speed while you do not have Iron Reflexes
{variant:1,2,3}You have Far Shot while you do not have Iron Reflexes
]],[[
The Bane of Hope
Maraketh Bow
League: Mirage
Source: No longer obtainable
Requires Level 71
Implicits: 1
10% increased Movement Speed
(90-130)% increased Physical Damage
+(28-35)% to Physical Damage over Time Multiplier
Adds (20-30) to (40-50) Physical Damage
(15-30)% chance to Impale Enemies on Hit with Attacks
Trigger Level 20 Tears of Rot when Equipped
]],[[
Chin Sol
Assassin Bow
Variant: Pre 1.0.0
Variant: Pre 1.2.0
Variant: Pre 2.0.0
Variant: Pre 3.5.0
Variant: Pre 3.9.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 62, 212 Dex
Implicits: 2
{variant:6,7}+(15-25)% to Global Critical Strike Multiplier
{variant:2,3}(6-12)% increased Elemental Damage with Attack Skills
+(10-20) to Dexterity
{variant:1,2}(75-100)% increased Physical Damage
{variant:3,4}(150-180)% increased Physical Damage
{variant:5,6}(200-260)% increased Physical Damage
{variant:7}(100-140)% increased Physical Damage
Adds 25 to 50 Fire Damage
{variant:1,2}5% increased Attack Speed
{variant:3,4,5,6,7}(10-14)% increased Attack Speed
{variant:1,2,3,4}100% more Damage with Arrow Hits at Close Range
{variant:5,6,7}50% more Damage with Arrow Hits at Close Range
Bow Knockback at Close Range
]],[[
The Crimson Storm
Steelwood Bow
League: Betrayal
Source: Drops from unique{Fortification Leaders} in normal{Safehouses}
Crafted: true
Suffix: None
Variant: Pre 3.17.0
Variant: Current
Requires Level 57, 190 Dex
Implicits: 2
{variant:2}6% increased Movement Speed
{variant:1}(4-6)% increased Movement Speed
{variant:1}(140-170)% increased Physical Damage
{variant:2}(60-80)% increased Physical Damage
(25-35)% increased Critical Strike Chance
50% chance to inflict Bleeding on Critical Strike with Attacks
Enemies you inflict Bleeding on grant (60-100)% increased Flask Charges
Adds (100-120) to (150-165) Physical Damage against Bleeding Enemies
50% chance to Maim Enemies on Critical Strike with Attacks
]],[[
Darkscorn
Assassin Bow
League: Legion
Variant: Pre 1.2.0
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.7.0
Variant: Pre 3.9.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 62, 212 Dex
Implicits: 2
{variant:6,7}+(15-25)% to Global Critical Strike Multiplier
{variant:1,2}(6-12)% increased Elemental Damage with Attack Skills
{variant:1,2,3}(100-125)% increased Physical Damage
{variant:4,5,6}(130-150)% increased Physical Damage
{variant:7}(60-80)% increased Physical Damage
{variant:2}Adds (6-10) to (10-14) Physical Damage
{variant:3,4}Adds (10-15) to (15-20) Physical Damage
{variant:5,6,7}Adds (15-20) to (25-30) Physical Damage
{variant:1,2,3,4}10% increased Attack Speed
{variant:5,6,7}20% increased Attack Speed
(15-30)% increased Global Accuracy Rating
25% of Physical Damage Converted to Chaos Damage
25% of Physical Damage from Hits taken as Chaos Damage
{variant:5,6,7}20% chance for Poisons inflicted with this Weapon to deal 300% more Damage
]],[[
Death's Harp
Death Bow
Variant: Pre 1.2.0
Variant: Pre 2.2.0
Variant: Pre 3.0.0
Variant: Pre 3.10.0
Variant: Pre 3.17.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 32, 107 Dex
Implicits: 1
{variant:2,3,4,5,6,7}(30-50)% increased Critical Strike Chance
{variant:1,2,3,4,5}(100-125)% increased Physical Damage
{variant:6,7}(90-105)% increased Physical Damage
10% increased Attack Speed
{variant:1,2,4}+100% to Global Critical Strike Multiplier
{variant:3}+150% to Global Critical Strike Multiplier
{variant:5,6,7}+50% to Global Critical Strike Multiplier
{variant:1,2,3,4,5,6}Bow Attacks fire an additional Arrow
{variant:7}Bow Attacks fire 2 additional Arrows
]],[[
Death's Opus
Death Bow
Source: No longer obtainable
Variant: Pre 1.2.0
Variant: Pre 2.2.0
Variant: Pre 3.0.0
Variant: Pre 3.10.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 44, 107 Dex
Implicits: 1
{variant:2,3,4,5,6}(30-50)% increased Critical Strike Chance
{variant:1,2,3,4,5}(100-125)% increased Physical Damage
{variant:6}(90-105)% increased Physical Damage
Adds (10-20) to (30-35) Physical Damage
10% increased Attack Speed
{variant:1,2,4}+100% to Global Critical Strike Multiplier
{variant:3}+150% to Global Critical Strike Multiplier
{variant:5,6}+50% to Global Critical Strike Multiplier
Bow Attacks fire 2 additional Arrows
]],[[
Doomfletch
Royal Bow
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.1.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 28, 95 Dex
Implicits: 2
{variant:2}(6-12)% increased Elemental Damage with Attack Skills
{variant:3,4,5}(20-24)% increased Elemental Damage with Attack Skills
{variant:2,3}Adds (8-12) to (16-20) Physical Damage
{variant:4,5}Adds (12-16) to (20-24) Physical Damage
(10-14)% increased Attack Speed
{variant:1,2,3}(30-40)% increased Critical Strike Chance
60% increased Mana Regeneration Rate
{variant:1,2,3}Gain 110% of Weapon Physical Damage as Extra Damage of a random Element
{variant:4}Gain 100% of Weapon Physical Damage as Extra Damage of a random Element
{variant:5}Gain 100% of Weapon Physical Damage as Extra Damage of each Element
]],[[
Doomfletch's Prism
Royal Bow
Source: No longer obtainable
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.1.0
Variant: Current
Requires Level 40, 95 Dex
Implicits: 2
{variant:2}(6-12)% increased Elemental Damage with Attack Skills
{variant:3,4}(20-24)% increased Elemental Damage with Attack Skills
{variant:2,3}Adds (8-12) to (16-20) Physical Damage
{variant:4}Adds (12-16) to (20-24) Physical Damage
(10-14)% increased Attack Speed
{variant:1,2,3}(30-40)% increased Critical Strike Chance
60% increased Mana Regeneration Rate
{variant:1,2,3}Gain 110% of Weapon Physical Damage as Extra Damage of each Element
{variant:4}Gain 100% of Weapon Physical Damage as Extra Damage of each Element
]],[[
The Flame of Hope
Maraketh Bow
League: Mirage
Source: No longer obtainable
Requires Level 71
Implicits: 1
10% increased Movement Speed
(90-110)% increased Fire Damage
Adds (180-230) to (310-360) Fire Damage
(14-18)% increased Attack Speed
Inflict Fire Exposure on Hit against Enemies with
5 Cinderflame, applying -25% to Fire Resistance
Trigger Level 20 Cinders when Equipped
]],[[
The Gluttonous Tide
Citadel Bow
Source: Drops from unique{The Eater of Worlds}
Requires Level 58, 185 Dex
(120-160)% increased Physical Damage
(16-20)% increased Attack Speed
Lose all Frenzy Charges on reaching Maximum Frenzy Charges to make the next Bow Attack you perform fire that many additional Arrows
+(30-50)% Global Critical Strike Multiplier while you have a Frenzy Charge
(20-40)% chance to gain a Frenzy Charge for each Enemy you hit with a Critical Strike
]],[[
Hopeshredder
Ranger Bow
Elder Item
Source: Drops from unique{The Elder}
Variant: Pre 3.4.0
Variant: Current
Requires Level 60, 212 Dex
Adds (130-150) to (270-300) Cold Damage
{variant:2}(15-25)% increased Attack Speed
{variant:2}+(400-500) to Accuracy Rating
{variant:1}+(400-500) to Accuracy Rating
4% increased Movement Speed per Frenzy Charge
2% chance to Avoid Damage of each Element from Hits per Frenzy Charge
12 to 14 Added Cold Damage per Frenzy Charge
0.5% of Attack Damage Leeched as Life per Frenzy Charge
{variant:1}400 Cold Damage taken per second per Frenzy Charge while moving
{variant:2}200 Cold Damage taken per second per Frenzy Charge while moving
]],[[
Infractem
Decimation Bow
Variant: Pre 1.2.0
Variant: Pre 2.6.0
Variant: Pre 3.7.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 53, 170 Dex
Implicits: 1
(30-50)% increased Critical Strike Chance
+(20-30) to Dexterity
{variant:1,2}(90-100)% increased Physical Damage
{variant:3,4}(110-125)% increased Physical Damage
{variant:5}(70-80)% increased Physical Damage
{variant:2,3,4,5}Adds (25-35) to (36-45) Physical Damage
10% increased Movement Speed
{variant:1,2,3}+(200-250) to Accuracy Rating
{variant:4,5}+(350-400) to Accuracy Rating
{variant:1,2}Cannot Leech
{variant:3,4,5}Cannot Leech Life
Arrows Pierce all Targets
]],[[
Replica Infractem
Decimation Bow
Variant: Pre 3.17.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 53, 170 Dex
Implicits: 1
(30-50)% increased Critical Strike Chance
+(20-30) to Dexterity
{variant:1}(110-125)% increased Physical Damage
{variant:2}(70-80)% increased Physical Damage
Adds (25-35) to (36-45) Physical Damage
10% increased Movement Speed
+(350-400) to Accuracy Rating
Cannot Leech Mana
Projectiles from Attacks Fork
Projectiles from Attacks can Fork 1 additional time
]],[[
Iron Commander
Death Bow
Requires Level 32, 107 Dex
Implicits: 1
(30-50)% increased Critical Strike Chance
Adds (8-12) to (16-24) Physical Damage
(14-20)% increased Attack Speed
(14-20)% increased Totem Life
(14-20)% increased Totem Placement speed
Siege Ballista has +1 to maximum number of Summoned Totems per 200 Dexterity
Adds 1 to 3 Physical Damage to Attacks per 25 Dexterity
]],[[
Replica Iron Commander
Death Bow
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 32, 107 Dex
Implicits: 1
(30-50)% increased Critical Strike Chance
Adds (8-12) to (16-24) Physical Damage
(14-20)% increased Attack Speed
(14-20)% increased Totem Life
(14-20)% increased Totem Placement speed
Shrapnel Ballista has +1 to maximum number of Summoned Totems per 200 Strength
Adds 1 to 3 Physical Damage to Attacks per 25 Strength
]],[[
Lioneye's Glare
Imperial Bow
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Pre 3.17.0
Variant: Pre 3.20.0
Variant: Pre 3.28.0
Variant: Current
Requires Level 66, 212 Dex
Implicits: 3
{variant:7}(20-24)% increased Global Physical Damage
{variant:2}(6-12)% increased Elemental Damage with Attack Skills
{variant:3,4,5,6}(20-24)% increased Elemental Damage with Attack Skills
{variant:1,2,3,4}(150-175)% increased Physical Damage
{variant:5}(90-105)% increased Physical Damage
{variant:6,7}(180-200)% increased Physical Damage
{variant:1,2,3,4,5}Adds (6-12) to (20-32) Physical Damage
{variant:6,7}Adds (7-14) to (24-34) Physical Damage
{variant:1,2,3,4,5,6}(10-20)% increased Attack Speed
+(80-100) to maximum Mana
{variant:7}Attacks you use yourself Repeat an additional time
{variant:7}Attacks you use yourself have 50% more Attack Speed
Hits can't be Evaded
{variant:4,5,6,7}Far Shot
]],[[
Null's Inclination
Ranger Bow
Variant: Pre 3.14.0
Variant: Pre 3.26.0
Variant: Current
Requires Level 60, 212 Dex, 212 Int
Trigger Socketed Minion Spells on Kill with this Weapon
Minion Spells Triggered by this Item have a 0.25 second Cooldown with 5 Uses
+212 Intelligence Requirement
Adds (50-80) to (130-180) Chaos Damage
(7-12)% increased Attack Speed
+(7-11)% to Chaos Resistance
{variant:2}Minions deal 1% increased Damage per 5 Dexterity
{variant:3}Minions deal 2% increased Damage per 5 Dexterity
{variant:1}Minions deal 1% increased Damage per 10 Dexterity
]],[[
Nuro's Harp
Harbinger Bow
Variant: Pre 2.5.0
Variant: Pre 3.26.0
Variant: Current
Requires Level 68, 212 Dex
Implicits: 1
(30-50)% increased Critical Strike Chance
No Physical Damage
{variant:1,2}Adds (120-140) to (180-210) Cold Damage
{variant:3}Adds (180-210) to (240-280) Cold Damage
(10-15)% increased Attack Speed
(10-30)% increased Light Radius
15% chance to create Chilled Ground when you Freeze an Enemy
Create Consecrated Ground when you Shatter an Enemy
{variant:2}40% increased Effect of Chilled Ground
{variant:3}(30-50)% increased Effect of Chilled Ground
{variant:3}(30-50)% increased Effect of Consecrated Ground you create
]],[[
Quill Rain
Short Bow
Variant: Pre 2.6.0
Variant: Pre 3.9.0
Variant: Current
Requires Level 5, 26 Dex
+(10-20) to Dexterity
{variant:2,3}100% increased Physical Damage
100% increased Attack Speed
{variant:2,3}Grants 2 Mana per Enemy Hit
(50-100)% increased Projectile Speed
+(25-50) to Accuracy Rating
{variant:1}50% less Damage
{variant:2}40% less Damage
{variant:3}30% less Damage
]],[[
Replica Quill Rain
Short Bow
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 5, 26 Dex
Socketed Gems are Supported by Level 1 Arrow Nova
+(10-20) to Dexterity
100% increased Physical Damage
(25-30)% increased Attack Speed
Grants 2 Mana per Enemy Hit
(50-100)% increased Projectile Speed
+(25-50) to Accuracy Rating
]],[[
Reach of the Council
Spine Bow
Variant: Pre 2.4.0
Variant: Pre 2.6.0
Variant: Pre 3.5.0
Variant: Pre 3.11.0
Variant: Pre 3.17.0
Variant: Current
{variant:4,5,6}Socketed Gems are Supported by Level 20 Greater Volley
{variant:1}(50-70)% increased Physical Damage
{variant:2,3}(40-50)% increased Physical Damage
{variant:4,5,6}(50-75)% increased Physical Damage
{variant:1}Adds (25-40) to (100-115) Physical Damage
{variant:2,3,4,5}Adds (15-30) to (70-95) Physical Damage
{variant:6}Adds (10-16) to (45-60) Physical Damage
(8-12)% increased Attack Speed
{variant:1,2}Bow Attacks fire 4 additional Arrows
{variant:3}Bow Attacks fire 2 additional Arrows
20% reduced Projectile Speed
{variant:5,6}Arrows fired from the first firing points always Pierce
{variant:5,6}Arrows fired from the second firing points Fork
{variant:5,6}Arrows fired from the third firing points Return to you
{variant:5,6}Arrows fired from the fourth firing points Chain +2 times
]],[[
Roth's Reach
Recurve Bow
Variant: Pre 3.9.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 18, 71 Dex
Implicits: 1
{variant:2,3}+(15-25)% to Global Critical Strike Multiplier
(60-80)% increased Physical Damage
{variant:1,2}(4-8)% increased Attack Speed
{variant:1,2}Skills Chain +1 times
{variant:3}Skills Chain +2 times
30% increased Projectile Speed
{variant:1,2}(20-40)% increased Elemental Damage with Attack Skills
{variant:3}(60-80)% increased Elemental Damage with Attack Skills
]],[[
Silverbranch
Crude Bow
Variant: Pre 2.0.0
Variant: Current
Requires Level 2
+1 to Level of Socketed Bow Gems
{variant:1}(50-80)% increased Physical Damage
{variant:2}(80-100)% increased Physical Damage
10% increased Attack Speed
Gain 10 Mana per Enemy Killed
+30 to Accuracy Rating
]],[[
Silverbough
Crude Bow
Source: No longer obtainable
Requires Level 36
+1 to Level of Socketed Gems
+1 to Level of Socketed Bow Gems
(80-100)% increased Physical Damage
Adds (15-25) to (50-60) Physical Damage
10% increased Attack Speed
Gain 10 Mana per Enemy Killed
+30 to Accuracy Rating
]],[[
Widowhail
Crude Bow
(150-250)% increased bonuses gained from Equipped Quiver
]],[[
Slivertongue
Harbinger Bow
Variant: Pre 3.5.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 68, 212 Dex
Implicits: 1
(30-50)% increased Critical Strike Chance
{variant:1}Adds (60-75) to (170-220) Physical Damage
{variant:2}Adds (110-125) to (245-265) Physical Damage
{variant:3}Adds (80-95) to (220-240) Physical Damage
{variant:1}100% increased Critical Strike Chance with arrows that Fork
{variant:2,3}(150-200)% increased Critical Strike Chance with arrows that Fork
{variant:1}Arrows that Pierce have 50% chance to inflict Bleeding
{variant:1}Arrows Pierce all Targets after Chaining
{variant:2,3}Arrows Pierce all Targets after Forking
{variant:2,3}Arrows that Pierce have +50% to Critical Strike Multiplier
]],[[
Storm Cloud
Long Bow
Variant: Pre 2.0.0
Variant: Current
Requires Level 9, 38 Dex
No Physical Damage
{variant:1}Adds 1 to 75 Lightning Damage
{variant:2}Adds 1 to 85 Lightning Damage
(36-50)% increased Attack Speed
]],[[
The Tempest
Long Bow
Source: No longer obtainable
Requires Level 32, 38 Dex
No Physical Damage
100% increased Lightning Damage
Adds 1 to 85 Lightning Damage
(36-50)% increased Attack Speed
]],[[
Voltaxic Rift
Spine Bow
Variant: Pre 3.9.0
Variant: Pre 3.20.0
Variant: Pre 3.28.0
Variant: Current
{variant:1,2}Adds 1 to (275-325) Lightning Damage
{variant:3,4}Adds 1 to (600-750) Lightning Damage
(10-15)% increased Attack Speed
{variant:1,2}60% of Lightning Damage Converted to Chaos Damage
{variant:3,4}100% of Lightning Damage Converted to Chaos Damage
{variant:1,2}10% chance to Shock
{variant:4}Treats Enemy Monster Chaos Resistance values as inverted
Your Chaos Damage can Shock
{variant:2,3}Hits with this Weapon Shock Enemies as though dealing 300% more Damage
{variant:2,3,4}+40% to Maximum Effect of Shock
]],[[
Windripper
Imperial Bow
Variant: Pre 1.1.2
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.5.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 66, 212 Dex
Implicits: 2
{variant:3}(6-12)% increased Elemental Damage with Attack Skills
{variant:4,5,6}(20-24)% increased Elemental Damage with Attack Skills
{variant:1}Adds 40 to 60 Cold Damage
{variant:2,3,4}Adds (32-40) to (48-60) Cold Damage
{variant:5,6}Adds (48-60) to (72-90) Cold Damage
{variant:1}Adds 1 to 100 Lightning Damage
{variant:2,3,4}Adds 1 to (80-100) Lightning Damage
{variant:5,6}Adds 1 to (120-150) Lightning Damage
(10-15)% increased Attack Speed
{variant:1,2}(80-100)% increased Critical Strike Chance
{variant:3,4}(60-80)% increased Critical Strike Chance
{variant:5,6}(30-40)% increased Critical Strike Chance
{variant:1,2}25% increased Quantity of Items Dropped by Slain Frozen Enemies
{variant:3,4,5}15% increased Quantity of Items Dropped by Slain Frozen Enemies
{variant:1,2}50% increased Rarity of Items Dropped by Slain Shocked Enemies
{variant:3,4,5,6}30% increased Rarity of Items Dropped by Slain Shocked Enemies
{variant:6}30% increased Rarity of Items Dropped by Frozen Enemies
]],[[
Replica Windripper
Imperial Bow
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 66, 212 Dex
Implicits: 1
(20-24)% increased Elemental Damage with Attack Skills
Adds (48-60) to (72-90) Cold Damage
Adds 1 to (120-150) Lightning Damage
(10-15)% increased Attack Speed
(30-40)% increased Critical Strike Chance
Enemies Frozen by you take 20% increased Damage
+(90-120) Energy Shield gained on Killing a Shocked Enemy
]],[[
Xoph's Inception
{variant:1}Bone Bow
{variant:2}Citadel Bow
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Xoph Breach or from unique{Xoph, Dark Embers}
Upgrade: Upgrades to unique{Xoph's Nurture} using currency{Blessing of Xoph}
Requires Level 23, 80 Dex
{variant:1}(70-90)% increased Physical Damage
{variant:2}(160-190)% increased Physical Damage
{variant:1}Gain (20-30) Life per Ignited Enemy Killed
{variant:2}Gain (200-300) Life per Ignited Enemy Killed
Gain 20% of Physical Damage as Extra Fire Damage
10% chance to Ignite
{variant:2}Projectiles Pierce all Burning Enemies
{variant:2}Arrows deal 30 to 50 Added Fire Damage for each time they've Pierced
]],[[
Xoph's Nurture
Citadel Bow
League: Breach
Source: Upgraded from unique{Xoph's Inception} using currency{Blessing of Xoph}
Variant: Pre 3.3.0
Variant: Pre 3.9.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 64, 185 Dex
{variant:3,4}Socketed Gems are Supported by Level 20 Ignite Proliferation
{variant:1,2,3}(250-300)% increased Physical Damage
{variant:4}(165-195)% increased Physical Damage
50% of Physical Damage Converted to Fire Damage
10% chance to Ignite
{variant:1}Ignites you inflict spread to other Enemies within 1.2 metres
{variant:2}Ignites you inflict spread to other Enemies within 1.5 metres
Recover (40-60) Life when you Ignite an Enemy
]],
[[
Wing of the Wyvern
Imperial Bow
Source: Drops from unique{Uber Incarnation of Fear} in normal{Moment of Trauma}
Requires Level 66, 212 Dex
Implicits: 1
(20-24)% increased Elemental Damage with Attack Skills
Trigger a Socketed Spell when a Hit from this
Weapon Freezes a Target, with a 0.25 second Cooldown
Adds (164-204) to (250-300) Cold Damage
Adds (163-199) to (241-293) Chaos Damage
(20-30)% increased Attack Speed
Your Chaos Damage can Freeze
Battlemage
]],
}
