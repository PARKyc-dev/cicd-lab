-- Item data (c) Grinding Gear Games

return {
-- Ring
[[
Ahkeli's Meadow
Ruby Ring
League: Delve
Source: Drops from unique{Aul, the Crystal King}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{tags:attribute}+20 to Strength
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Ahkeli's Mountain
Ruby Ring
League: Delve
Source: Drops from unique{Ahuatotli, the Blind}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{tags:attribute}+20 to Strength
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Ahkeli's Valley
Ruby Ring
League: Delve
Source: Drops from unique{Kurgal, the Blackblooded}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{tags:attribute}+20 to Strength
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Andvarius
Gold Ring
Requires Level 20
Implicits: 1
(6-15)% increased Rarity of Items found
{tags:attribute}+10 to Dexterity
(50-70)% increased Rarity of Items found
{tags:resistance}-20% to all Elemental Resistances
]],[[
Astral Projector
Topaz Ring
Requires Level 40
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}+(30-50) to Intelligence
{tags:caster}(20-25)% increased Spell Damage
30% chance to Avoid Elemental Ailments
{tags:caster}Nova Spells have 20% less Area of Effect
{tags:caster}Nova Spells Cast at the targeted location instead of around you
]],[[
The Bandit Lord's Band
Gold Ring
League: Settlers
Source: Drops from unique{Sasan, the Bandit Lord}
Requires Level 44
Implicits: 1
(6-15)% increased Rarity of Items found
(25-35)% increased Quantity of Gold Dropped by Slain Enemies
]],[[
Berek's Grip
Two-Stone Ring
League: Domination, Nemesis
Variant: Pre 2.6.0
Variant: Pre 3.8.0
Variant: Current
Requires Level 20
Implicits: 1
{tags:resistance}+(12-16)% to Cold and Lightning Resistances
{variant:1}{tags:elemental_damage}(10-15)% increased Cold Damage
{variant:2,3}{tags:elemental_damage}(25-30)% increased Cold Damage
{variant:1}{tags:elemental_damage,attack}Adds 1 to (1-50) Lightning Damage to Attacks
{variant:2,3}{tags:elemental_damage,attack,caster}Adds 1 to (50-70) Lightning Damage to Spells and Attacks
{tags:resource}+(30-40) to maximum Life
{variant:1}{tags:resource}1% of Damage Leeched as Life against Shocked Enemies
{variant:2,3}{tags:resource}1% of Damage Leeched as Life against Shocked Enemies
{variant:3}{tags:defences}1% of Damage Leeched as Energy Shield against Frozen Enemies
{variant:1,2}{tags:resource}1% of Damage Leeched as Mana against Frozen Enemies
]],[[
Berek's Pass
Two-Stone Ring
League: Domination, Nemesis
Variant: Pre 2.6.0
Variant: Current
Requires Level 20
Implicits: 1
{tags:resistance}+(12-16)% to Fire and Cold Resistances
{variant:1}{tags:elemental_damage}(10-15)% increased Fire Damage
{variant:2}{tags:elemental_damage}(25-30)% increased Fire Damage
{variant:1}{tags:elemental_damage,attack,caster}Adds 1 to (10-30) Cold Damage to Spells and Attacks
{variant:2}{tags:elemental_damage,attack,caster}Adds (20-25) to (30-50) Cold Damage to Spells and Attacks
{tags:defences}+(30-40) to maximum Energy Shield
30% increased Damage while Ignited
{tags:defences}+5000 to Armour while Frozen
]],[[
Berek's Respite
Two-Stone Ring
League: Domination, Nemesis
Variant: Pre 2.6.0
Variant: Current
Requires Level 20
Implicits: 1
{tags:resistance}+(12-16)% to Fire and Lightning Resistances
{variant:1}{tags:elemental_damage,attack,caster}Adds 1 to (10-30) Fire Damage to Spells and Attacks
{variant:2}{tags:elemental_damage,attack,caster}Adds (20-25) to (30-50) Fire Damage to Spells and Attacks
{variant:1}{tags:elemental_damage}(10-15)% increased Lightning Damage
{variant:2}{tags:elemental_damage}(25-30)% increased Lightning Damage
{tags:resource}+(30-40) to maximum Mana
When you Kill a Shocked Enemy, inflict an equivalent Shock on each nearby Enemy
When you Kill an Ignited Enemy, inflict an equivalent Ignite on each nearby Enemy
]],[[
Blackflame
Amethyst Ring
League: Ritual
Source: Purchase from Ritual Reward
Requires Level 49
Implicits: 1
{tags:resistance}+(17-23)% to Chaos Resistance
{tags:elemental_damage}+(8-12)% to Fire Damage over Time Multiplier
50% reduced Ignite Duration on Enemies
(10-15)% chance to Ignite
Enemies Ignited by you take Chaos Damage instead of Fire Damage from Ignite
Withered does not expire on Enemies Ignited by you
{tags:resistance}+(20-25)% to Fire and Chaos Resistances
]],[[
Blackheart
Iron Ring
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
{variant:1}{tags:physical_damage}5% increased Global Physical Damage
{variant:1}{tags:chaos_damage,attack}Adds 1 to 3 Chaos Damage to Attacks
{variant:2}{tags:chaos_damage,attack}Adds (10-15) to (20-25) Chaos Damage to Attacks
{variant:1}{tags:resource}+(20-30) to maximum Life
{variant:1}{tags:resource}Regenerate (2-4) Life per second
{variant:2}{tags:resource}Regenerate (10-15) Life per second
10% chance to Cause Monsters to Flee
]],[[
Voidheart
Iron Ring
Source: No longer obtainable
Variant: Pre 2.4.0
Variant: Current
Requires Level 48
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
{tags:physical_damage}5% increased Global Physical Damage
{tags:chaos_damage,attack}Adds 1 to 3 Chaos Damage to Attacks
{tags:resource}+(20-30) to maximum Life
{tags:resource}Regenerate (2-4) Life per second
10% chance to Cause Monsters to Flee
{variant:1}{tags:attack}Melee Attacks cause Bleeding
{variant:2}{tags:attack}Melee Attacks have (30-50)% chance to cause Bleeding
{variant:1}{tags:attack}Melee Attacks Poison on Hit
{variant:2}{tags:attack}Melee Attacks have (20-40)% chance to Poison on Hit
]],[[
Bloodboil
Coral Ring
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Requires Level 24
Implicits: 1
{tags:resource}+(20-30) to maximum Life
{variant:1}{tags:elemental_damage,attack}Adds (7-10) to (15-20) Fire Damage to Attacks
{variant:2}{tags:elemental_damage,attack}Adds (12-15) to (25-30) Fire Damage to Attacks
{tags:resource}+(20-40) to maximum Life
{tags:resistance}+(10-15)% to Cold Resistance
{variant:1}45% increased Effect of Chill on you
{variant:2}75% reduced Effect of Chill on you
{variant:1}100% increased Ignite Duration on you
{variant:2}{tags:speed}10% increased Movement Speed while Ignited
]],[[
Winterweave
Coral Ring
Requires Level 24
Implicits: 1
{tags:resource}+(20-30) to maximum Life
{tags:elemental_damage,attack}Adds (12-15) to (25-30) Fire Damage to Attacks
{tags:elemental_damage,attack}Adds (12-15) to (25-30) Cold Damage to Attacks
{tags:resource}+(20-40) to maximum Life
{tags:resistance}+(25-30)% to Cold Resistance
{tags:speed}10% increased Movement Speed while Ignited
The Effect of Chill on you is reversed
]],[[
Brinerot Mark
Unset Ring
League: Warbands
Variant: Pre 2.6.0
Variant: Current
Requires Level 45
Implicits: 1
Has 1 Socket
{variant:2}25% increased Effect of Buffs granted by Socketed Golem Skills
{variant:2}{tags:resource,defences}Socketed Golem Skills gain 20% of Maximum Life as Extra Maximum Energy Shield
{variant:1}+2 to Level of Socketed Golem Gems
{variant:2}+3 to Level of Socketed Golem Gems
{variant:1}Socketed Gems are Supported by Level 15 Concentrated Effect
{variant:1}Socketed Gems are Supported by Level 15 Minion Life
{variant:1}{tags:caster}(10-25)% increased Spell Damage
{variant:2}{tags:caster}(20-25)% increased Spell Damage
{tags:defences}+(15-25) to maximum Energy Shield
{tags:resistance}+(20-40)% to Lightning Resistance
]],[[
Call of the Brotherhood
Two-Stone Ring
Variant: Pre 2.6.0
Variant: Current
Requires Level 20
Implicits: 1
{tags:resistance}+(12-16)% to Cold and Lightning Resistances
{tags:attribute}+(15-25) to Intelligence
{tags:elemental_damage}(15-25)% increased Lightning Damage
{tags:resource}(30-40)% increased Mana Regeneration Rate
{variant:1}{tags:elemental_damage}50% of Lightning Damage Converted to Cold Damage
{variant:2}{tags:elemental_damage}40% of Lightning Damage Converted to Cold Damage
{tags:caster}Your spells have 100% chance to Shock against Frozen Enemies
]],[[
Circle of Ambition
Prismatic Ring
Source: Drops from unique{Synthete Nightmare} in normal{The Cortex} (Uber)
Requires Level 20
Variant: Thunder: Skill Reservation
Variant: Thunder: Lightning Damage
Variant: Thunder: Buff Effect
Variant: Thunder: Max Resistance
Variant: Thunder: Lightning Resistance
Variant: Ash: Ash: Skill Reservation
Variant: Ash: Fire Damage
Variant: Ash: Buff Effect
Variant: Ash: Max Resistance
Variant: Ash: Fire Resistance
Variant: Ice: Skill Reservation
Variant: Ice: Cold Damage
Variant: Ice: Buff Effect
Variant: Ice: Max Resistance
Variant: Ice: Cold Resistance
Variant: Purity: Skill Reservation
Variant: Purity: Physical Damage
Variant: Purity: Buff Effect
Variant: Purity: Sentinel Damage
Variant: Purity: Damage Reduction
Variant: Agony: Skill Reservationwatcher
Variant: Agony: Chaos Damage
Variant: Agony: Buff Effect
Variant: Agony: Agony Damage
Variant: Agony: Chaos Resistance
Selected Variant: 1
Has Alt Variant: true
Selected Alt Variant: 2
Has Alt Variant Two: true
Selected Alt Variant Two: 3
Implicits: 0
{tags:attribute}+(10-20) to all Attributes
{tags:resistance}+(10-20)% to all Elemental Resistances
{variant:24}Agony Crawler deals (70-100)% increased Damage
{variant:22}{tags:chaos_damage}(40-60)% increased Chaos Damage while affected by Herald of Agony
{variant:25}{tags:resistance}+(31-43)% to Chaos Resistance while affected by Herald of Agony
{variant:12}{tags:elemental_damage}(40-60)% increased Cold Damage while affected by Herald of Ice
{variant:15}{tags:resistance}+(50-60)% to Cold Resistance while affected by Herald of Ice
{variant:7}{tags:elemental_damage}(40-60)% increased Fire Damage while affected by Herald of Ash
{variant:10}{tags:resistance}+(50-60)% to Fire Resistance while affected by Herald of Ash
{variant:23}Herald of Agony has (40-60)% increased Buff Effect
{variant:21}{tags:resource}Herald of Agony has (30-40)% increased Mana Reservation Efficiency
{variant:8}Herald of Ash has (40-60)% increased Buff Effect
{variant:6}{tags:resource}Herald of Ash has (30-40)% increased Mana Reservation Efficiency
{variant:13}Herald of Ice has (40-60)% increased Buff Effect
{variant:11}{tags:resource}Herald of Ice has (30-40)% increased Mana Reservation Efficiency
{variant:18}Herald of Purity has (40-60)% increased Buff Effect
{variant:16}{tags:resource}Herald of Purity has (30-40)% increased Mana Reservation Efficiency
{variant:3}Herald of Thunder has (40-60)% increased Buff Effect
{variant:1}{tags:resource}Herald of Thunder has (30-40)% increased Mana Reservation Efficiency
10% increased Mana Reservation Efficiency of Herald Skills
{variant:2}{tags:elemental_damage}(40-60)% increased Lightning Damage while affected by Herald of Thunder
{variant:5}{tags:resistance}+(50-60)% to Lightning Resistance while affected by Herald of Thunder
{variant:14}{tags:resistance}+1% to maximum Cold Resistance while affected by Herald of Ice
{variant:9}{tags:resistance}+1% to maximum Fire Resistance while affected by Herald of Ash
{variant:4}{tags:resistance}+1% to maximum Lightning Resistance while affected by Herald of Thunder
{variant:17}{tags:physical_damage}(40-60)% increased Physical Damage while affected by Herald of Purity
{variant:20}4% additional Physical Damage Reduction while affected by Herald of Purity
{variant:19}Sentinels of Purity deal (70-100)% increased Damage
]],[[
Circle of Anguish
Ruby Ring
League: Synthesis
Source: Drops from unique{Altered/Augmented/Rewritten/Twisted Synthete}
Requires Level 52
Has Alt Variant: true
Variant: Skill Reservation (Pre 3.11.0)
Variant: Skill Reservation (Current)
Variant: Fire Damage
Variant: Buff Effect (Pre 3.11.0)
Variant: Buff Effect (Current)
Variant: Max Resistance
Variant: Fire Resistance
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{tags:attribute}{fractured}+(20-30) to Strength
{tags:elemental_damage}Adds (20-25) to (26-35) Fire Damage
{tags:resistance}+(20-30)% to Fire Resistance
{variant:3}{tags:elemental_damage}(40-60)% increased Fire Damage while affected by Herald of Ash
{variant:7}{tags:resistance}+(50-60)% to Fire Resistance while affected by Herald of Ash
{variant:4}Herald of Ash has (70-100)% increased Buff Effect
{variant:5}Herald of Ash has (40-60)% increased Buff Effect
{variant:1}{tags:resource}Herald of Ash has (60-80)% reduced Mana Reservation Efficiency
{variant:2}{tags:resource}Herald of Ash has (30-40)% increased Mana Reservation Efficiency
{variant:6}{tags:resistance}+1% to maximum Fire Resistance while affected by Herald of Ash
]],[[
Circle of Fear
Sapphire Ring
League: Synthesis
Source: Drops from unique{Altered/Augmented/Rewritten/Twisted Synthete}
Requires Level 52
Has Alt Variant: true
Variant: Skill Reservation (Pre 3.11.0)
Variant: Skill Reservation (Current)
Variant: Cold Damage
Variant: Buff Effect (Pre 3.11.0)
Variant: Buff Effect (Current)
Variant: Max Resistance
Variant: Cold Resistance
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:attribute}{fractured}+(20-30) to Dexterity
{tags:elemental_damage}Adds (20-25) to (26-35) Cold Damage
{tags:resistance}+(20-30)% to Cold Resistance
{variant:3}{tags:elemental_damage}(40-60)% increased Cold Damage while affected by Herald of Ice
{variant:7}{tags:resistance}+(50-60)% to Cold Resistance while affected by Herald of Ice
{variant:4}Herald of Ice has (70-100)% increased Buff Effect
{variant:5}Herald of Ice has (40-60)% increased Buff Effect
{variant:1}{tags:resource}Herald of Ice has (60-80)% reduced Mana Reservation Efficiency
{variant:2}{tags:resource}Herald of Ice has (30-40)% increased Mana Reservation Efficiency
{variant:6}{tags:resistance}+1% to maximum Cold Resistance while affected by Herald of Ice
]],[[
Circle of Guilt
Iron Ring
League: Synthesis
Source: Drops from unique{Altered/Augmented/Rewritten/Twisted Synthete}
Requires Level 52
Has Alt Variant: true
Variant: Skill Reservation (Pre 3.11.0)
Variant: Skill Reservation (Current)
Variant: Physical Damage
Variant: Buff Effect (Pre 3.11.0)
Variant: Buff Effect (Current)
Variant: Sentinel Damage
Variant: Damage Reduction
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
{tags:attribute}{fractured}+(10-20) to all Attributes
{tags:physical_damage}Adds (8-10) to (13-15) Physical Damage
{tags:defences}+(350-400) to Armour
{variant:4}Herald of Purity has (70-100)% increased Buff Effect
{variant:5}Herald of Purity has (40-60)% increased Buff Effect
{variant:1}{tags:resource}Herald of Purity has (60-80)% reduced Mana Reservation Efficiency
{variant:2}{tags:resource}Herald of Purity has (30-40)% increased Mana Reservation Efficiency
{variant:3}{tags:physical_damage}(40-60)% increased Physical Damage while affected by Herald of Purity
{variant:7}4% additional Physical Damage Reduction while affected by Herald of Purity
{variant:6}Sentinels of Purity deal (70-100)% increased Damage
]],[[
Circle of Nostalgia
Amethyst Ring
League: Synthesis
Source: Drops from unique{Altered/Augmented/Rewritten/Twisted Synthete}
Requires Level 52
Has Alt Variant: true
Variant: Skill Reservation (Pre 3.11.0)
Variant: Skill Reservation (Current)
Variant: Chaos Damage
Variant: Buff Effect (Pre 3.11.0)
Variant: Buff Effect (Current)
Variant: Agony Damage
Variant: Chaos Resistance
Implicits: 1
{tags:resistance}+(17-23)% to Chaos Resistance
{tags:attribute}{fractured}+(10-20) to all Attributes
{tags:chaos_damage}Adds (15-20) to (21-30) Chaos Damage
{tags:resistance}+(17-23)% to Chaos Resistance
{variant:6}Agony Crawler deals (70-100)% increased Damage
{variant:3}{tags:chaos_damage}(40-60)% increased Chaos Damage while affected by Herald of Agony
{variant:7}{tags:resistance}+(31-43)% to Chaos Resistance while affected by Herald of Agony
{variant:4}Herald of Agony has (70-100)% increased Buff Effect
{variant:5}Herald of Agony has (40-60)% increased Buff Effect
{variant:1}{tags:resource}Herald of Agony has (60-80)% reduced Mana Reservation Efficiency
{variant:2}{tags:resource}Herald of Agony has (30-40)% increased Mana Reservation Efficiency
]],[[
Circle of Regret
Topaz Ring
League: Synthesis
Source: Drops from unique{Altered/Augmented/Rewritten/Twisted Synthete}
Requires Level 52
Has Alt Variant: true
Variant: Skill Reservation (Pre 3.11.0)
Variant: Skill Reservation (Current)
Variant: Lightning Damage
Variant: Buff Effect (Pre 3.11.0)
Variant: Buff Effect (Current)
Variant: Max Resistance
Variant: Lightning Resistance
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}{fractured}+(20-30) to Intelligence
{tags:elemental_damage}Adds 1 to (48-60) Lightning Damage
{tags:resistance}+(20-30)% to Lightning Resistance
{variant:4}Herald of Thunder has (70-100)% increased Buff Effect
{variant:5}Herald of Thunder has (40-60)% increased Buff Effect
{variant:1}{tags:resource}Herald of Thunder has (60-80)% reduced Mana Reservation Efficiency
{variant:2}{tags:resource}Herald of Thunder has (30-40)% increased Mana Reservation Efficiency
{variant:3}{tags:elemental_damage}(40-60)% increased Lightning Damage while affected by Herald of Thunder
{variant:7}{tags:resistance}+(50-60)% to Lightning Resistance while affected by Herald of Thunder
{variant:6}{tags:resistance}+1% to maximum Lightning Resistance while affected by Herald of Thunder
]],[[
Death Rush
Amethyst Ring
League: Onslaught
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 46
Implicits: 1
{tags:resistance}+(17-23)% to Chaos Resistance
{variant:1,2}{tags:attack}+(300-350) to Accuracy Rating
{variant:1}{tags:defences}+(60-80) to Armour
{variant:2}{tags:defences}+(260-300) to Armour
{variant:2}{tags:resource}+(40-50) to maximum Life
{variant:1,2}{tags:resistance}+(15-20)% to Chaos Resistance
{variant:1,2}{tags:resource,attack}(0.6-0.8)% of Physical Attack Damage Leeched as Life
{variant:3}{tags:resource}Recover 5% of Life on Kill
{variant:1}You gain Onslaught for 2 seconds on Kill
{variant:2}You gain Onslaught for 4 seconds on Kill
{variant:3}Gain Adrenaline for 3 seconds on Kill
]],[[
Doedre's Damning
Paua Ring
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:resource}+(20-30) to maximum Mana
{variant:1}{tags:attribute}+(5-10) to Intelligence
{variant:2}{tags:attribute}+(5-20) to Intelligence
{variant:1}{tags:resistance}+5% to all Elemental Resistances
{variant:2}{tags:resistance}+(5-20)% to all Elemental Resistances
{variant:1}{tags:resource}Gain 5 Mana per Enemy Killed
{variant:2}{tags:resource}Gain (5-20) Mana per Enemy Killed
{tags:caster}You can apply an additional Curse
]],[[
Replica Doedre's Damning
Paua Ring
Variant: Pre 3.16.0
Variant: Pre 3.19.0
Variant: Pre 3.20.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 1
{tags:resource}+(20-30) to maximum Mana
{variant:1,2}{tags:attribute}+(5-10) to Intelligence
{variant:3,4}{tags:attribute}+(5-20) to Intelligence
{variant:1,2}{tags:resistance}+5% to all Elemental Resistances
{variant:3,4}{tags:resistance}+(5-20)% to all Elemental Resistances
{variant:1,2}{tags:resource}Gain 5 Mana per Enemy Killed
{variant:3,4}{tags:resource}Gain (5-20) Mana per Enemy Killed
{tags:caster}You can apply one fewer Curse
{variant:1}{tags:caster}(25-35)% increased Effect of your Curses
{variant:2,3}{tags:caster}(15-25)% increased Effect of your Curses
{variant:4}{tags:caster}(10-15)% increased Effect of your Curses
]],[[
Dream Fragments
Sapphire Ring
Variant: Pre 2.6.0
Variant: Current
Requires Level 24
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:resource}20% increased maximum Mana
{tags:resource}50% increased Mana Regeneration Rate
{variant:2}{tags:resistance}+(30-40)% to Cold Resistance
{variant:2}Cannot be Chilled
{variant:2}Cannot be Frozen
{variant:1}Cannot be Frozen
]],[[
Emberwake
Ruby Ring
Variant: Pre 3.0.0
Variant: Pre 3.9.0
Variant: Pre 3.16.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 16
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{variant:1}{tags:elemental_damage}(15-25)% increased Fire Damage
{variant:2,3,4,5}{tags:elemental_damage}(30-40)% increased Fire Damage
{variant:1,2,3,4}{tags:caster,speed}(5-10)% increased Cast Speed
{variant:5}{tags:caster,speed}(10-20)% increased Cast Speed
{variant:1}5% chance to Ignite
{variant:2,3,4,5}10% chance to Ignite
{variant:1}{tags:elemental_damage}Ignited Enemies Burn 80% slower
{variant:2}{tags:elemental_damage}Ignited Enemies Burn 65% slower
{variant:3}{tags:elemental_damage}Ignited Enemies Burn (65-50)% slower
{variant:1}{tags:critical}Your Critical Strikes do not deal extra Damage
{variant:4}{tags:elemental_damage}40% less Burning Damage
{variant:5}{tags:elemental_damage}35% less Burning Damage
You can inflict an additional Ignite on each Enemy
]],[[
Replica Emberwake
Ruby Ring
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.29.0
Variant: Current
Requires Level 16
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{tags:elemental_damage}(30-40)% increased Fire Damage
{variant:1}{tags:caster,speed}(5-10)% increased Cast Speed
{variant:2}{tags:caster,speed}(10-20)% increased Cast Speed
90% reduced Ignite Duration on Enemies
10% chance to Ignite
{variant:1}{tags:elemental_damage}Ignites you inflict deal Damage (35-45)% faster
{variant:2}{tags:elemental_damage}Ignites you inflict deal Damage (40-60)% faster
]],[[
Essence Worm
Unset Ring
Requires Level 38
Implicits: 1
Has 1 Socket
+2 to Level of Socketed Aura Gems
{tags:resource}Socketed Gems have no Reservation
{tags:resource}Your Blessing Skills are Disabled
{tags:resource}80% reduced Reservation Efficiency of Skills
]],[[
Fated End
Paua Ring
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 38
Implicits: 1
{tags:resource}+(20-30) to maximum Mana
{tags:attribute}+(20-40) to Intelligence
{tags:caster,speed}Curse Skills have (8-12)% increased Cast Speed
Non-Aura Hexes expire upon reaching 200% of base Effect
Non-Aura Hexes gain 20% increased Effect per second
]],[[
Gifts from Above
Diamond Ring
League: Anarchy
Variant: Pre 2.6.0
Variant: Current
Requires Level 28
Implicits: 1
{tags:critical}(20-30)% increased Global Critical Strike Chance
{variant:2}{tags:critical}Trigger Level 10 Consecrate when you deal a Critical Strike
{tags:critical}(30-35)% increased Global Critical Strike Chance
(10-15)% increased Light Radius
{variant:1}{tags:critical}Creates Consecrated Ground on Critical Strike
{tags:critical}(40-50)% increased Rarity of Items Dropped by Enemies killed with a Critical Strike
{variant:2}50% increased Damage while on Consecrated Ground
{variant:2}+5% Chance to Block Attack Damage while on Consecrated Ground
]],[[
Replica Gifts from Above
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Diamond Ring
Requires Level 28
Implicits: 1
{tags:critical}(20-30)% increased Global Critical Strike Chance
{tags:critical}Trigger Level 10 Consecrate when you deal a Critical Strike
{tags:critical}(30-35)% increased Global Critical Strike Chance
(10-15)% increased Light Radius
{tags:critical}(40-50)% increased Rarity of Items Dropped by Enemies killed with a Critical Strike
Inflict Hallowing Flame on Hit while on Consecrated Ground
]],[[
Grattus Signet
Diamond Ring
League: Necropolis
Source: Created from 4 different unique{Grattus} family corpses in the normal{Necropolis}
Requires Level 64
Implicits: 1
{tags:critical}(20-30)% increased Global Critical Strike Chance
{tags:attack,speed}(5-10)% increased Attack Speed
{tags:caster,speed}(5-10)% increased Cast Speed
{tags:defences}+(40-60) to maximum Energy Shield
{tags:resource}+(30-50) to maximum Life
Attacks inflict Unnerve on Critical Strike for 4 seconds
Spells inflict Intimidate on Critical Strike for 4 seconds
]],[[
The Hateful Accuser 
Nameless Ring
League: Settlers of Kalguur
Requires Level 50
Implicits: 2
50% increased Elemental Ailment Duration on you
50% reduced Effect of Curses on you
Grants level 20 Penance Mark
{tags:caster,speed}(6-12)% increased Cast Speed
{tags:resource}+(30-60) to maximum Life
{tags:resistance}+(7-19)% to Chaos Resistance
]],[[
Heartbound Loop
Moonstone Ring
Requires Level 20
Implicits: 1
{tags:defences}+(15-25) to maximum Energy Shield
{tags:resource}Regenerate (10-15) Life per second
{tags:resource}(20-40)% increased Mana Regeneration Rate
{tags:resource}Minions have 15% increased maximum Life
Minions have 10% increased Area of Effect
{tags:physical_damage}350 Physical Damage taken on Minion Death
]],[[
Ixchel's Temptation
Gold Ring
League: Affliction
Requires Level 20
Implicits: 1
(6-15)% increased Rarity of Items found
{tags:attribute}+(10-15) to all Attributes
{tags:chaos_damage,attack}Adds (7-10) to (15-18) Chaos Damage to Attacks
{tags:elemental_damage,caster}Adds (9-12) to (19-22) Fire Damage to Spells
{tags:critical}+(15-20)% to Global Critical Strike Multiplier
{tags:defences}+(80-100) to Armour
{tags:defences}+(80-100) to Evasion Rating
{tags:defences}+(30-35) to maximum Energy Shield
{tags:resource}+(25-30) to maximum Life
{tags:resource}+(20-25) to maximum Mana
{tags:resistance}+(8-10)% to all Elemental Resistances
{tags:attack,caster,speed}(6-8)% increased Attack and Cast Speed
Maximum Quality is 200%
Corrupted
]],[[
Anathema
Moonstone Ring
LevelReq: 49
Implicits: 1
{tags:defences}+(15-25) to maximum Energy Shield
{tags:attribute}+(30-40) to Intelligence
{tags:caster,speed}(10-15)% increased Cast Speed
(10-20)% chance to gain a Power Charge when you Cast a Curse Spell
Your Curse Limit is equal to your maximum Power Charges
]],[[
The Highwayman
Gold Ring
League: Heist
Variant: Pre 3.19.0
Variant: Current
Requires Level 44
Implicits: 1
(6-15)% increased Rarity of Items found
(15-25)% increased Rarity of Items found
{variant:2}{tags:resource}1% of Damage Leeched as Life
{variant:1}{tags:speed}5% increased Movement Speed
{variant:2}{tags:speed}(5-10)% increased Movement Speed
{variant:1}25% chance to Steal Power, Frenzy, and Endurance Charges on Hit
{variant:2}Steal Power, Frenzy, and Endurance Charges on Hit
{variant:1}0.5% of Damage Leeched as Life while you have at least 5 total Endurance, Frenzy and Power Charges
Total Recovery per second from Life Leech is Doubled
]],[[
Honoured Alliance
Coral Ring
League: Ancestor
Source: No longer obtainable
LevelReq: 49
Implicits: 1
{tags:resource}+(20-30) to maximum Life
10% chance to Trigger Summon Spirit of Akoya on Kill
{tags:attribute}+(10-20) to all Attributes
{tags:resource}(30-50)% increased Mana Regeneration Rate
{tags:resource}(10-15)% of Damage taken Recouped as Life
]],
[[
The Hungry Loop
Unset Ring
Requires Level 45
Implicits: 1
Has 1 Socket
Consumes Socketed Uncorrupted Support Gems when they reach Maximum Level
Can Consume 4 Uncorrupted Support Gems
Has not Consumed any Gems
]],[[
Icefang Orbit
Iron Ring
Requires Level: 49
League: Blight
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
{tags:attribute}+(20-30) to Dexterity
25% chance to Poison on Hit
{tags:chaos_damage}(40-60)% increased Damage with Poison
You are Chilled when you are Poisoned
Non-Chilled Enemies you Poison are Chilled
Poisoned Enemies you Kill with Hits Shatter
]],[[
Kaom's Sign
Coral Ring
Variant: Pre 2.0.0
Variant: Pre 3.19.0
Variant: Current
Implicits: 1
{tags:resource}+(20-30) to maximum Life
{variant:3}Grants Level 10 Enduring Cry Skill
{tags:attribute}+(10-20) to Strength
{variant:1}{tags:resource,attack}0.4% of Physical Attack Damage Leeched as Life
{variant:2}{tags:resource,attack}Gain (2-4) Life per Enemy Hit with Attacks
+1 to Maximum Endurance Charges
]],[[
Kaom's Way
Coral Ring
Variant: Pre 3.16.0
Variant: Current
Source: No longer obtainable
Requires Level 32
Implicits: 1
{tags:resource}+(20-30) to maximum Life
{tags:attribute}+(10-20) to Strength
{variant:1}{tags:resource}Regenerate 0.4% of Life per second per Endurance Charge
{variant:2}{tags:resource}Regenerate 0.2% of Life per second per Endurance Charge
{tags:resource,attack}Gain (2-4) Life per Enemy Hit with Attacks
+1 to Maximum Endurance Charges
{variant:2}2% increased Area of Effect per Endurance Charge
]],[[
Kikazaru
Topaz Ring
Variant: Pre 2.6.0
Variant: Pre 3.16.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 20
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}+(10-15) to all Attributes
{variant:1}{tags:resource}Regenerate (13-17) Life per second
{tags:resource}(20-40)% increased Mana Regeneration Rate
{variant:1}{tags:caster}20% increased Effect of Curses on you
{variant:2}{tags:caster}40% increased Effect of Curses on you
{variant:3,4}{tags:caster}60% reduced Effect of Curses on you
{variant:2,3}{tags:resource}Regenerate 1 Life per second per Level
{variant:4}{tags:resource}Regenerate 3 Life per second per Level
]],[[
Nimis
Topaz Ring
Source: Drops from unique{The Eater of Worlds} (Uber)
LevelReq: 48
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}+(30-50) to Dexterity
(25-35)% increased Projectile Damage
Projectiles Return to you
Projectiles are fired in random directions
]],[[
Le Heup of All
Iron Ring
Variant: Pre 2.6.0
Variant: Current
Requires Level 24
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
{variant:1}{tags:attribute}+(10-20) to all Attributes
{variant:2}{tags:attribute}+(10-30) to all Attributes
{variant:1}(10-20)% increased Damage
{variant:2}(10-30)% increased Damage
{variant:1}(10-20)% increased Rarity of Items found
{variant:2}(10-30)% increased Rarity of Items found
{variant:1}{tags:resistance}+(10-20)% to all Elemental Resistances
{variant:2}{tags:resistance}+(10-30)% to all Elemental Resistances
]],[[
Lori's Lantern
Prismatic Ring
Variant: Pre 1.0.0
Variant: Current
Requires Level 30
Implicits: 2
{variant:1}{tags:resistance}+(8-12)% to all Elemental Resistances
{variant:2}{tags:resistance}+(8-10)% to all Elemental Resistances
{tags:resistance}+10% to all Elemental Resistances
{tags:speed}(6-8)% increased Movement Speed when on Low Life
31% increased Light Radius
{tags:resistance}+(20-25)% to Chaos Resistance when on Low Life
Damage of Enemies Hitting you is Unlucky while you are on Low Life
]],[[
Malachai's Artifice
Unset Ring
Variant: Pre 2.6.0
Variant: Current
Sockets: W
Requires Level 5
Implicits: 1
Has 1 Socket
All Sockets are White
{tags:elemental_damage}Socketed Gems have Elemental Equilibrium
{variant:1}{tags:resistance}-25% to all Elemental Resistances
{variant:2}{tags:resistance}-20% to all Elemental Resistances
{tags:resistance}+(75-100)% to Fire Resistance when Socketed with a Red Gem
{tags:resistance}+(75-100)% to Cold Resistance when Socketed with a Green Gem
{tags:resistance}+(75-100)% to Lightning Resistance when Socketed with a Blue Gem
]],[[
Replica Malachai's Artifice
Unset Ring
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 5
Implicits: 1
Has 1 Socket
All Sockets are White
{tags:critical}Socketed Gems have Secrets of Suffering
{tags:resistance}-20% to all Elemental Resistances
{tags:resistance}+(75-100)% to Fire Resistance when Socketed with a Red Gem
{tags:resistance}+(75-100)% to Cold Resistance when Socketed with a Green Gem
{tags:resistance}+(75-100)% to Lightning Resistance when Socketed with a Blue Gem
]],[[
Mark of Submission
Unset Ring
Requires Level 24
Implicits: 1
Has 1 Socket
{tags:caster}Curse Enemies with Socketed Hex Curse Gem on Hit
]],[[
Mark of the Elder
Steel Ring
Elder Item
Source: Drops from unique{The Elder} (Uber)
Requires Level 80
Implicits: 1
{tags:physical_damage,attack}Adds (3-4) to (10-14) Physical Damage to Attacks
20% chance to Trigger Level 20 Tentacle Whip on Kill
{tags:elemental_damage,attack}Adds (26-32) to (42-48) Cold Damage to Attacks
{tags:defences}(6-10)% increased maximum Energy Shield
{tags:resource}(6-10)% increased maximum Life
{tags:attack}(60-80)% increased Attack Damage if your opposite Ring is a Shaper Item
Cannot be Stunned by Attacks if your opposite Ring is an Elder Item
]],[[
Mark of the Shaper
Opal Ring
Shaper Item
Source: Drops from unique{The Elder} (Uber)
Requires Level 80
Implicits: 1
{tags:elemental_damage}(15-25)% increased Elemental Damage
20% chance to Trigger Level 20 Summon Volatile Anomaly on Kill
{tags:elemental_damage,caster}Adds (13-18) to (50-56) Lightning Damage to Spells
{tags:defences}(6-10)% increased maximum Energy Shield
{tags:resource}(6-10)% increased maximum Life
{tags:caster}(60-80)% increased Spell Damage if your opposite Ring is an Elder Item
Cannot be Stunned by Spells if your opposite Ring is a Shaper Item
]],[[
Ming's Heart
Amethyst Ring
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 69
Implicits: 1
{tags:resistance}+(17-23)% to Chaos Resistance
{variant:1}{tags:defences}15% increased maximum Energy Shield
{variant:2}{tags:defences}10% increased maximum Energy Shield
{variant:3}{tags:defences}(5-10)% increased maximum Energy Shield
{variant:4}{tags:defences}25% reduced maximum Energy Shield
{variant:1}{tags:resource}15% increased maximum Life
{variant:2}{tags:resource}10% increased maximum Life
{variant:3}{tags:resource}(5-10)% increased maximum Life
{variant:4}{tags:resource}25% reduced maximum Life
{tags:resistance}+(40-50)% to Chaos Resistance
{variant:1,2,3}{tags:physical_damage,chaos_damage}Gain 20% of Physical Damage as Extra Chaos Damage
{variant:4}{tags:physical_damage,chaos_damage}Gain (40-60)% of Physical Damage as Extra Chaos Damage
]],[[
Mokou's Embrace
Ruby Ring
Variant: Pre 3.19.0
Variant: Current
Requires Level 16
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{variant:1}{tags:elemental_damage}(15-25)% increased Fire Damage
{tags:resistance}+(25-40)% to Cold Resistance
{variant:1}(5-10)% chance to Ignite
{variant:1}{tags:attack,speed}20% increased Attack Speed while Ignited
{variant:2}{tags:attack,speed}(25-40)% increased Attack Speed while Ignited
{variant:1}{tags:caster,speed}20% increased Cast Speed while Ignited
{variant:2}{tags:caster,speed}(25-40)% increased Cast Speed while Ignited
+25% chance to be Ignited
{variant:2}All Damage Taken from Hits can Ignite you
]],[[
Mutewind Seal
Unset Ring
League: Warbands
Variant: Pre 2.6.0
Variant: Pre 3.16.0
Variant: Current
Requires Level 45
Implicits: 1
Has 1 Socket
{variant:2,3}{tags:attack,caster,speed}Socketed Golem Skills have 20% increased Attack and Cast Speed
{variant:2,3}Gain Onslaught for 10 seconds when you Cast Socketed Golem Skill
{variant:1}+2 to Level of Socketed Golem Gems
{variant:2,3}+3 to Level of Socketed Golem Gems
{variant:1}Socketed Gems are Supported by Level 13 Faster Attacks
{variant:1}Socketed Gems are Supported by Level 16 Minion Speed
{tags:physical_damage,attack}Adds (5-10) to (11-15) Physical Damage to Attacks
{tags:attack,speed}(5-10)% increased Attack Speed
{variant:1}{tags:speed}(1-2)% increased Movement Speed
{variant:2}{tags:speed}(3-5)% increased Movement Speed
]],[[
Ngamahu's Sign
Ruby Ring
League: Bloodlines
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 29
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{tags:attribute}+(15-25) to Strength
{variant:1}{tags:elemental_damage,attack,caster}Adds (8-10) to (12-14) Fire Damage to Spells and Attacks
{variant:2}{tags:elemental_damage,attack,caster}Adds (8-10) to (12-14) Fire Damage to Spells and Attacks
{variant:3,4}{tags:elemental_damage,attack,caster}Adds (20-25) to (30-35) Fire Damage to Spells and Attacks
{variant:4}{tags:defences}+(400-600) to Armour
{variant:1}{tags:resource}Gain (4-5) Life for each Ignited Enemy hit with Attacks
15% increased Ignite Duration on Enemies
{variant:1}5% chance to Ignite
{variant:2,3,4}10% chance to Ignite
{variant:2,3,4}{tags:resource}Recover (20-30) Life when you Ignite an Enemy
]],[[
Original Sin
Amethyst Ring
League: Sanctum
Source: Drops from unique{Lycia, Herald of the Scourge} in normal{The Beyond} while unique{The Original Scripture} is active in the normal{Relic Altar}
LevelReq: 52
Implicits: 1
{tags:resistance}+(17-23)% to Chaos Resistance
{tags:elemental_damage,chaos_damage}All Elemental Damage Converted to Chaos Damage
{tags:chaos_damage,resistance}Nearby Enemies' Chaos Resistance is 0
]],[[
The Pariah
Unset Ring
Variant: Pre 3.25.0
Variant: Pre 3.29.0
Variant: Current
League: Warbands
Requires Level 60
Implicits: 1
Has 1 Socket
+2 to Level of Socketed Gems
{tags:attack,caster,speed}(5-10)% increased Attack and Cast Speed
{variant:1,2}{tags:resource}+100 to Maximum Life per Red Socket
{variant:3}{tags:resource}+(100-200) to Maximum Life per Red Socket
{variant:1,2}{tags:resource}+100 to Maximum Mana per Green Socket
{variant:3}{tags:resource}+(100-200) to Maximum Mana per Green Socket
{variant:1,2}{tags:defences}+100 to Maximum Energy Shield per Blue Socket
{variant:3}{tags:defences}+(100-200) to Maximum Energy Shield per Blue Socket
{variant:1}15% increased Item Quantity per White Socket
{variant:2,3}60% increased Item Rarity per White Socket
]],[[
Perandus Signet
Paua Ring
Variant: Pre 2.0.0
Variant: Current
Implicits: 1
{tags:resource}+(20-30) to maximum Mana
{tags:resource}+(25-30) to maximum Mana
{tags:resource}(45-65)% increased Mana Regeneration Rate
{variant:1}3% increased Experience gain
{variant:2}2% increased Experience gain
{variant:1}{tags:attribute}3% increased Intelligence for each Unique Item Equipped
{variant:2}{tags:attribute}2% increased Intelligence for each Unique Item Equipped
3% chance for Slain monsters to drop an additional Scroll of Wisdom
]],[[
Polaric Devastation
Opal Ring
Source: Drops from unique{The Black Star}
Requires Level 80
Implicits: 1
{tags:elemental_damage}(15-25)% increased Elemental Damage
{tags:critical}(15-25)% increased Global Critical Strike Chance
{tags:resistance}+(20-40)% to Fire Resistance
{tags:resistance}+(20-40)% to Cold Resistance
(10-20)% increased Duration of Ailments on Enemies
Left Ring slot: Cover Enemies in Ash for 5 seconds when you Ignite them
Right Ring slot: Cover Enemies in Frost for 5 seconds when you Freeze them
]],[[
Praxis
Paua Ring
Variant: Pre 3.29.0
Variant: Current
Requires Level 22
Implicits: 1
{tags:resource}+(20-30) to maximum Mana
{tags:resource}+(30-60) to maximum Mana
{tags:resource}Regenerate (3-6) Mana per second
{tags:resource}-(8-4) to Total Mana Cost of Skills
{tags:resource}8% of Damage taken Recouped as Mana
{variant:2}{tags:resource}(20-30)% increased Mana Cost Efficiency
]],[[
Profane Proxy
Unset Ring
Sockets: G
LevelReq: 52
Implicits: 1
Has 1 Socket
{tags:caster}+3 to Level of Socketed Curse Gems
{tags:resistance}+(20-30)% to Cold Resistance
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:caster}Left Ring Slot: Your Chilling Skitterbot's Aura applies Socketed Hex Curse instead
{tags:caster}Right Ring Slot: Your Shocking Skitterbot's Aura applies Socketed Hex Curse instead
]],[[
Putembo's Meadow
Topaz Ring
League: Delve
Source: Drops from unique{Kurgal, the Blackblooded}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}+20 to Intelligence
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Putembo's Mountain
Topaz Ring
League: Delve
Source: Drops from unique{Aul, the Crystal King}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}+20 to Intelligence
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Putembo's Valley
Topaz Ring
League: Delve
Source: Drops from unique{Ahuatotli, the Blind}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}+20 to Intelligence
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Pyre
Sapphire Ring
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Current
Requires Level 11
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:resistance}+(25-35)% to Fire Resistance
{variant:1,2}{tags:elemental_damage}(25-35)% increased Burning Damage
{variant:3}{tags:elemental_damage}(60-80)% increased Burning Damage
{variant:1}{tags:elemental_damage}100% of Cold Damage Converted to Fire Damage
{variant:2,3}{tags:elemental_damage}40% of Cold Damage Converted to Fire Damage
10% increased Light Radius
Ignited Enemies Killed by your Hits are destroyed
]],[[
The Queller of Minds
Nameless Ring
League: Settlers of Kalguur
Requires Level 50
Implicits: 2
50% increased Elemental Ailment Duration on you
50% reduced Effect of Curses on you
Grants level 20 Pacify
{tags:caster,speed}(6-12)% increased Cast Speed
{tags:resource}+(30-60) to maximum Mana
{tags:resistance}+(7-19)% to Chaos Resistance
]],[[
Redblade Band
Unset Ring
League: Warbands
Variant: Pre 2.6.0
Variant: Current
Requires Level 45
Implicits: 1
Has 1 Socket
{variant:2}Socketed Golem Skills have 25% chance to Taunt on Hit
{variant:2}{tags:resource}Socketed Golem Skills have Minions Regenerate 5% of Life per second
{variant:1}+2 to Level of Socketed Golem Gems
{variant:2}+3 to Level of Socketed Golem Gems
{variant:1}Socketed Gems are Supported by Level 12 Multiple Projectiles
{variant:1}Socketed Gems are Supported by Level 17 Minion Damage
{tags:attribute}+(30-40) to Strength
{tags:elemental_damage}(20-30)% increased Fire Damage
{variant:1}{tags:elemental_damage,attack}Adds (8-12) to (20-30) Fire Damage to Attacks
{variant:2}{tags:resource}+(30-40) to maximum Life
]],[[
Rigwald's Crest
Two-Stone Ring
League: Talisman
Variant: Pre 3.19.0
Variant: Current
Source: Drops from unique{Rigwald, the Wolven King} (Level 60+)
Requires Level 49
Implicits: 1
{tags:resistance}+(12-16)% to Fire and Cold Resistances
Trigger Level 10 Summon Spectral Wolf on Kill
{variant:1}{tags:elemental_damage}(20-30)% increased Fire Damage
{variant:1}{tags:elemental_damage}(20-30)% increased Cold Damage
{tags:resource}(20-30)% increased Mana Regeneration Rate
]],[[
Romira's Banquet
Diamond Ring
Variant: Pre 1.1.0
Variant: Pre 2.2.0
Variant: Current
Requires Level 60
Implicits: 1
{tags:critical}(20-30)% increased Global Critical Strike Chance
{tags:attack}+333 to Accuracy Rating
{variant:1}{tags:critical}+(10-20)% to Global Critical Strike Multiplier
{variant:2}{tags:critical}+(10-15)% to Global Critical Strike Multiplier
{variant:3}{tags:critical}+(15-25)% to Global Critical Strike Multiplier
{tags:resource}+(40-60) to maximum Mana
{tags:resource,attack}0.4% of Physical Attack Damage Leeched as Mana
Gain a Power Charge on Non-Critical Strike
Lose all Power Charges on Critical Strike
]],[[
Rotblood Promise
Unset Ring
League: Ritual
Source: Purchase from Ritual Reward
Variant: Pre 3.16.0
Variant: Current
Requires Level 56
Implicits: 1
Has 1 Socket
{tags:caster}Socketed Gems are Supported by Level 20 Blasphemy
Curse Auras from Socketed Skills also affect you
{variant:1}{tags:caster}Socketed Curse Gems have 50% increased Reservation Efficiency
{variant:2}{tags:caster}Socketed Curse Gems have 80% increased Reservation Efficiency
{tags:attribute}+(20-30) to Intelligence
{tags:caster}20% reduced Effect of Curses on you
(15-25)% increased Damage with Hits and Ailments against Cursed Enemies
]],[[
The Selfish Shepherd
Nameless Ring
League: Settlers of Kalguur
Requires Level 50
Implicits: 2
50% increased Elemental Ailment Duration on you
{tags:caster}50% reduced Effect of Curses on you
Grants level 20 Affliction
{tags:caster,speed}(6-12)% increased Cast Speed
{tags:defences}+(30-60) to maximum Energy Shield
{tags:resistance}+(7-19)% to Chaos Resistance
]],[[
Shavronne's Revelation
Moonstone Ring
League: Anarchy, Onslaught
Variant: Pre 1.2.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 30
Implicits: 1
{tags:defences}+(15-25) to maximum Energy Shield
{tags:attribute}+(60-75) to Intelligence
{tags:resource}Right ring slot: You cannot Regenerate Mana
{variant:1}{tags:defences}Right ring slot: Regenerate 4% of Energy Shield per second
{variant:2,3}{tags:defences}Right ring slot: Regenerate 3% of Energy Shield per second
{variant:4}{tags:defences}Right ring slot: Regenerate 6% of Energy Shield per second
{variant:3}{tags:resource}Right ring slot: +100 to maximum Mana
{variant:4}{tags:resource}Right ring slot: +250 to maximum Mana
{tags:defences}Left ring slot: You cannot Recharge or Regenerate Energy Shield
{variant:3,4}{tags:resource}Left ring slot: Regenerate 40 Mana per Second
{variant:1,2}{tags:resource}Left ring slot: 100% increased Mana Regeneration Rate
{variant:3}{tags:defences}Left ring slot: +100 to maximum Energy Shield
{variant:4}{tags:defences}Left ring slot: +250 to maximum Energy Shield
]],[[
Sibyl's Lament
Coral Ring
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.9.0
Variant: Pre 3.28.0
Variant: Current
Requires Level 45
Implicits: 1
{tags:resource}+(20-30) to maximum Life
{tags:elemental_damage,attack}Adds (8-15) to (20-28) Fire Damage to Attacks
{variant:1}(20-40)% increased Rarity of Items found
{variant:2,3,4,5}(10-20)% reduced Rarity of Items found
{tags:elemental_damage,attack}(20-30)% increased Elemental Damage with Attack Skills
{variant:1,2}Left ring slot: you and your Minions prevent +30% of Reflected Elemental Damage
{variant:3}Left ring slot: you and your Minions prevent +40% of Reflected Elemental Damage
{variant:4}Left ring slot: you and your Minions prevent +80% of Reflected Elemental Damage
{variant:5}Left ring slot: you and your Minions prevent +100% of Reflected Elemental Damage
{variant:1,2}Right ring slot: you and your Minions prevent +30% of Reflected Physical Damage
{variant:3}Right ring slot: you and your Minions prevent +40% of Reflected Physical Damage
{variant:4}Right ring slot: you and your Minions prevent +80% of Reflected Physical Damage
{variant:5}Right ring slot: you and your Minions prevent +100% of Reflected Physical Damage
]],[[
Snakepit
Sapphire Ring
Variant: Pre 3.5.0
Variant: Current
Requires Level 68
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{variant:2}{tags:caster}(20-40)% increased Spell Damage
{variant:1}{tags:elemental_damage}(20-40)% increased Cold Damage
{tags:caster,speed}(5-10)% increased Cast Speed
{variant:1}{tags:caster}Spells fire an additional Projectile
{variant:2}Left ring slot: Projectiles from Spells cannot Chain
{variant:2}Left ring slot: Projectiles from Spells Fork
{variant:2}Right ring slot: Projectiles from Spells Chain +1 times
{variant:2}Right ring slot: Projectiles from Spells cannot Fork
{variant:2}Projectiles from Spells cannot Pierce
]],[[
Soulbound
Paua Ring
LevelReq: 44
Implicits: 1
{tags:resource}+(20-30) to maximum Mana
{tags:attribute}+(10-20) to all Attributes
Link Skills have (10-15)% increased Cast Speed
Link Skills have (10-15)% increased Skill Effect Duration
Linked Targets Cannot Die for 2 seconds after you Die
Lose no Experience when you die because a Linked target died
]],[[
Stormfire
Opal Ring
Variant: Pre 3.17.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 80
Implicits: 1
{tags:elemental_damage}(15-25)% increased Elemental Damage
{tags:resource}(40-45)% increased Mana Regeneration Rate
{tags:resistance}+(20-30)% to Fire and Lightning Resistances
{variant:1}{tags:elemental_damage}(4-6)% increased Burning Damage for each time you have Shocked a Non-Shocked Enemy Recently, up to a maximum of 120%
{variant:2,3}{tags:elemental_damage}(8-12)% increased Burning Damage for each time you have Shocked a Non-Shocked Enemy Recently, up to a maximum of 120%
{variant:1,2}{tags:elemental_damage}Adds (1-3) to (62-70) Lightning Damage to Hits against Ignited Enemies
{variant:3}{tags:elemental_damage}Adds (1-3) to (125-145) Lightning Damage to Hits against Ignited Enemies
Your Lightning Damage can Ignite
]],[[
Storm Secret
Topaz Ring
League: Harvest
Requires Level 56
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{tags:attribute}+(20-30) to Intelligence
{tags:elemental_damage}(20-30)% increased Lightning Damage
(10-15)% chance to Shock
Herald of Thunder also creates a storm when you Shock an Enemy
Herald of Thunder's Storms Hit Enemies with (30-50)% increased Frequency
{tags:elemental_damage}Take 250 Lightning Damage when Herald of Thunder Hits an Enemy
]],[[
The Taming
Prismatic Ring
League: Domination, Nemesis
Source: Vendor Recipe
Variant: Pre 3.0.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 30
Implicits: 1
{tags:resistance}+(8-10)% to all Elemental Resistances
{variant:1}{tags:resistance}+(10-15)% to all Elemental Resistances
{variant:2,3}{tags:resistance}+(20-30)% to all Elemental Resistances
{variant:1}{tags:elemental_damage}15% increased Elemental Damage
{variant:2}{tags:elemental_damage}30% increased Elemental Damage
{variant:1}5% chance to Freeze, Shock and Ignite
{variant:2,3}10% chance to Freeze, Shock and Ignite
{variant:1}{tags:elemental_damage}10% increased Elemental Damage with Hits and Ailments for
{variant:1}{tags:elemental_damage}each type of Elemental Ailment on Enemy
{variant:2}{tags:elemental_damage}20% increased Elemental Damage with Hits and Ailments for
{variant:2}{tags:elemental_damage}each type of Elemental Ailment on Enemy
{variant:3}{tags:elemental_damage}(30-40)% increased Elemental Damage with Hits and Ailments for
{variant:3}{tags:elemental_damage}each type of Elemental Ailment on Enemy
{variant:1}{tags:elemental_damage,attack}15% increased Elemental Damage with Attack Skills
{variant:2}{tags:elemental_damage,attack}30% increased Elemental Damage with Attack Skills
]],[[
Tasalio's Sign
Sapphire Ring
League: Bloodlines
Variant: Pre 2.6.0
Variant: Current
Requires Level 20
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{variant:1}{tags:physical_damage,attack}Adds 10 to 15 Physical Damage to Attacks against Frozen Enemies
{variant:1}{tags:elemental_damage,attack}Adds (5-6) to (7-9) Cold Damage to Attacks
{variant:2}{tags:elemental_damage,attack,caster}Adds (7-10) to (15-20) Cold Damage to Spells and Attacks
{tags:defences}+(200-300) to Evasion Rating
{variant:2}50% chance to Avoid being Chilled
{variant:1}20% reduced Chill Duration on you
{variant:1}5% chance to Freeze
{variant:2}10% chance to Freeze
{variant:2}{tags:elemental_damage}Adds 40 to 60 Cold Damage against Chilled Enemies
]],[[
Replica Tasalio's Sign
Sapphire Ring
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 20
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:elemental_damage,attack,caster}Adds (15-20) to (25-35) Cold Damage to Spells and Attacks
{tags:defences}+(200-300) to Evasion Rating
Your Cold Damage cannot Freeze
Immune to Chill
{tags:elemental_damage}Adds 60 to 80 Cold Damage against Chilled Enemies
]],[[
Tawhanuku's Timing
Moonstone Ring
Variant: Pre 3.29.0
Variant: Current
Implicits: 1
{tags:defences}+(15-25) to maximum Energy Shield
{tags:caster}(30-40)% increased Spell Damage
{variant:2}{tags:defences}+(60-80) to maximum Energy Shield
{tags:resource}+(60-80) to maximum Mana
(5-10)% chance to Freeze, Shock and Ignite
{tags:defences,caster}Spells cause you to gain Energy Shield equal to their Upfront
{tags:defences,caster}Cost every third time you Pay it
]],[[
Thief's Torment
Prismatic Ring
Variant: Pre 1.0.0
Variant: Pre 1.1.0
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 30
Implicits: 2
{variant:1}{tags:resistance}+(8-12)% to all Elemental Resistances
{variant:2,3,4,5,6}{tags:resistance}+(8-10)% to all Elemental Resistances
{variant:1,2}(15-25)% increased Quantity of Items found
{variant:3,4,5}(10-16)% increased Quantity of Items found
{variant:6}(20-30)% increased Rarity of Items found
Can't use other Rings
{variant:1,2,3}{tags:resistance}+(8-12)% to all Elemental Resistances
{variant:4}{tags:resistance}+(16-24)% to all Elemental Resistances
{variant:5,6}{tags:resistance}+(25-40)% to all Elemental Resistances
{variant:1,2,3}{tags:resource,attack}Gain (20-30) Life per Enemy Hit with Attacks
{variant:4,5,6}{tags:resource,attack}Gain (40-60) Life per Enemy Hit with Attacks
{variant:1,2,3}{tags:resource,attack}Gain 15 Mana per Enemy Hit with Attacks
{variant:4,5,6}{tags:resource,attack}Gain 30 Mana per Enemy Hit with Attacks
{tags:caster}50% reduced Effect of Curses on you
]],[[
Timeclasp
Moonstone Ring
Variant: Pre 2.6.0
Variant: Pre 3.17.0
Variant: Pre 3.19.0
Variant: Current
LevelReq: 25
Implicits: 1
{tags:defences}+(15-25) to maximum Energy Shield
{tags:attack,speed}(10-15)% increased Attack Speed
{variant:1}{tags:caster,speed}(5-8)% increased Cast Speed
{variant:2,3}{tags:caster,speed}(5-10)% increased Cast Speed
{variant:4}{tags:caster,speed}(10-15)% increased Cast Speed
{variant:1}{tags:defences}+(10-25) to maximum Energy Shield
{variant:2}{tags:defences}+(15-25) to maximum Energy Shield
{variant:3}{tags:defences}+(40-45) to maximum Energy Shield
{variant:1}{tags:resource}15% increased Mana Regeneration Rate
{variant:2,3}{tags:resource}15% increased Mana Regeneration Rate
{variant:1}{tags:caster}Temporal Chains has 30% reduced Effect on you
{variant:2}{tags:caster}Temporal Chains has 50% reduced Effect on you
{variant:3}(-10-10)% reduced Skill Effect Duration
{variant:4}(-20-20)% reduced Skill Effect Duration
{variant:4}{tags:resource}(6-12)% of Damage taken Recouped as Mana
{variant:4}{tags:resource}(6-12)% of Damage taken Recouped as Life
{variant:3,4}{tags:caster}Unaffected by Temporal Chains
]],[[
Timetwist
Moonstone Ring
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
LevelReq: 25
Implicits: 1
{tags:defences}+(15-25) to maximum Energy Shield
{tags:attack,speed}(10-15)% increased Attack Speed
{variant:1}{tags:caster,speed}(5-8)% increased Cast Speed
{variant:2}{tags:caster,speed}(10-15)% increased Cast Speed
{tags:defences}+(40-45) to maximum Energy Shield
{variant:1}{tags:resource}15% increased Mana Regeneration Rate
{variant:2}{tags:resource}15% increased Mana Regeneration Rate
(-10-10)% reduced Skill Effect Duration
{tags:caster}Unaffected by Temporal Chains
]],[[
Triumvirate Authority
Unset Ring
Requires Level 64
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Apex of Sacrifice} (3 stats) or in normal{The Alluring Abyss} (4 stats)
Has Alt Variant: true
Has Alt Variant Two: true
Has Alt Variant Three: true
Variant: More Damage
Variant: Less souls
Variant: Regain Souls
Variant: Ignore resistances
Variant: Ignore Phys. Dmg. Reduction
Variant: Grant Elusive
Variant: Tailwind
Variant: Area of Effect
Variant: Proj. Speed
Variant: Skill Effect Duration
Variant: Soul Gain Prevention Duration
Variant: Lucky Damage
Variant: Aura Effect
Implicits: 1
Has 1 Socket
+2 to Level of Socketed Vaal Gems
{variant:8}Socketed Vaal Skills have 60% increased Area of Effect
{variant:13}Socketed Vaal Skills have 50% increased Aura Effect
{variant:1}Socketed Vaal Skills deal 150% more Damage
{variant:10}Socketed Vaal Skills have 80% increased Skill Effect Duration
{variant:6}Socketed Vaal Skills grant Elusive when Used
{variant:12}Damage with Hits from Socketed Vaal Skills is Lucky
{variant:5}Hits from Socketed Vaal Skills ignore Enemy Physical Damage Reduction
{variant:4}Hits from Socketed Vaal Skills ignore Enemy Monster Resistances
{variant:9}{tags:speed}Socketed Vaal Skills have 80% increased Projectile Speed
{variant:11}Socketed Vaal Skills have 30% reduced Soul Gain Prevention Duration
{variant:2}Socketed Vaal Skills require 30% less Souls per Use
{variant:3}Socketed Vaal Skills have 20% chance to regain consumed Souls when used
{variant:7}You have Tailwind if you've used a Socketed Vaal Skill Recently
]],[[
Uzaza's Meadow
Sapphire Ring
League: Delve
Source: Drops from unique{Ahuatotli, the Blind}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:attribute}+20 to Dexterity
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Uzaza's Mountain
Sapphire Ring
League: Delve
Source: Drops from unique{Kurgal, the Blackblooded}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:attribute}+20 to Dexterity
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Uzaza's Valley
Sapphire Ring
League: Delve
Source: Drops from unique{Aul, the Crystal King}
Requires Level 49
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:attribute}+20 to Dexterity
{tags:defences}5% increased maximum Energy Shield
{tags:resource}5% increased maximum Life
]],[[
Valako's Sign
Topaz Ring
League: Bloodlines
Variant: Pre 2.6.0
Variant: Pre 3.11.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 38
Implicits: 1
{tags:resistance}+(20-30)% to Lightning Resistance
{variant:1}15% increased Damage with Hits against Shocked Enemies
{variant:2,3,4}40% increased Damage with Hits against Shocked Enemies
{tags:elemental_damage}20% increased Lightning Damage
{variant:1,2,3}{tags:resource}+(20-40) to maximum Mana
{variant:4}{tags:resource}+(100-150) to maximum Mana
{variant:1,2}{tags:resource}2% of Damage Leeched as Life against Shocked Enemies
{variant:3,4}{tags:resource}1% of Damage Leeched as Life against Shocked Enemies
{variant:1}5% chance to Shock
{variant:2}10% chance to Shock
{variant:3,4}25% chance to Shock
]],[[
Valyrium
Moonstone Ring
Variant: Pre 3.11.0
Variant: Current
Requires Level 38
Implicits: 1
{tags:defences}+(15-25) to maximum Energy Shield
{variant:1}{tags:defences}+(10-20) to maximum Energy Shield
{variant:2}{tags:defences}+(30-40) to maximum Energy Shield
{variant:1}{tags:resistance}+(20-30)% to Fire Resistance
{variant:2}{tags:resistance}+(30-40)% to Fire Resistance
{tags:resistance}-40% to Cold Resistance
Stun Threshold is based on Energy Shield instead of Life
]],[[
Venopuncture
Iron Ring
Requires Level: 49
League: Blight
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
{tags:attribute}+(20-30) to Strength
{tags:attack}25% chance to cause Bleeding on Hit
{tags:physical_damage,attack}(40-60)% increased Damage with Bleeding
You are Chilled while you are Bleeding
Non-Chilled Enemies you inflict Bleeding on are Chilled
Bleeding Enemies you Kill with Hits Shatter
]],[[
Ventor's Gamble
Gold Ring
Variant: Pre 3.25.0
Variant: Current
Requires Level 65
Implicits: 1
(6-15)% increased Rarity of Items found
{tags:resource}+(0-60) to maximum Life
{variant:1}(-10-10)% reduced Quantity of Items found
(-40-40)% reduced Rarity of Items found
{tags:resistance}+(-25-50)% to Fire Resistance
{tags:resistance}+(-25-50)% to Cold Resistance
{tags:resistance}+(-25-50)% to Lightning Resistance
{variant:2}{tags:resource}(-15-15)% reduced Mana Reservation Efficiency of Skills
]],[[
Vivinsect
Unset Ring
League: Betrayal
Source: Drops from unique{Research Leaders} in normal{Safehouses}
Variant: Fire and Chaos Resistances Pre 3.16.0
Variant: Cold and Chaos Resistances Pre 3.16.0
Variant: Lightning and Chaos Resistances Pre 3.16.0
Variant: Strength and Dexterity Pre 3.16.0
Variant: Dexterity and Intelligence Pre 3.16.0
Variant: Strength and Intelligence Pre 3.16.0
Variant: Effect of non-Damaging Ailments Pre 3.16.0
Variant: Focus Shock Nearby Enemies Pre 3.16.0
Variant: Minimum Frenzy Charges Pre 3.16.0
Variant: Minimum Power Charges Pre 3.16.0
Variant: Minimum Endurance Charges Pre 3.16.0
Variant: Fire and Chaos Resistances
Variant: Cold and Chaos Resistances
Variant: Lightning and Chaos Resistances
Variant: Strength and Dexterity
Variant: Dexterity and Intelligence
Variant: Strength and Intelligence
Variant: Focus Shock Nearby Enemies
Variant: Minimum Frenzy Charges
Variant: Minimum Power Charges
Variant: Minimum Endurance Charges
Requires Level 45
Implicits: 1
Has 1 Socket
+5 to Level of Socketed Aura Gems
{variant:13,14,15,16,17,18,19,20,21}Socketed Gems have 20% reduced Reservation Efficiency
{tags:attribute}+(15-25) to all Attributes
{variant:4}{tags:attribute}+(6-17) to Strength and Dexterity
{variant:15}{tags:attribute}+(31-35) to Strength and Dexterity
{variant:6}{tags:attribute}+(6-17) to Strength and Intelligence
{variant:17}{tags:attribute}+(31-35) to Strength and Intelligence
{variant:5}{tags:attribute}+(6-17) to Dexterity and Intelligence
{variant:16}{tags:attribute}+(31-35) to Dexterity and Intelligence
{variant:19}(3-4)% chance to gain a Frenzy Charge on Kill
{variant:20}(3-4)% chance to gain a Power Charge on Kill
{tags:resource}Regenerate 15 Life per second for each Uncorrupted Item Equipped
{tags:resource}-2 to Total Mana Cost of Skills for each Corrupted Item Equipped
{variant:1}{tags:resistance}+(8-15)% to Fire and Chaos Resistances
{variant:12}{tags:resistance}+(16-20)% to Fire and Chaos Resistances
{variant:18}Focus has (5-8)% increased Cooldown Recovery Rate
{variant:1,2,3,4,5,6,7,8,9,10,11}Socketed Gems have 20% reduced Mana Reservation Efficiency
{variant:2}{crafted}{tags:chaos,jewellery_resistance}+(8-15)% to Cold and Chaos Resistances
{variant:3}{crafted}{tags:chaos,jewellery_resistance}+(8-15)% to Lightning and Chaos Resistances
{variant:7}{crafted}(11-30)% increased Effect of non-Damaging Ailments on Enemies
{variant:8}{crafted}Shock nearby Enemies for (2-4) Seconds when you Focus
{variant:9}{crafted}+1 to Minimum Frenzy Charges
{variant:10}{crafted}+1 to Minimum Power Charges
{variant:11}{crafted}+1 to Minimum Endurance Charges
{variant:13}{crafted}{tags:chaos,jewellery_resistance}+(16-20)% to Cold and Chaos Resistances
{variant:14}{crafted}{tags:chaos,jewellery_resistance}+(16-20)% to Lightning and Chaos Resistances
{variant:18}{crafted}Shock nearby Enemies for 4 Seconds when you Focus
{variant:19}{crafted}+1 to Minimum Frenzy Charges
{variant:20}{crafted}+1 to Minimum Power Charges
{variant:21}{crafted}+1 to Minimum Endurance Charges
{variant:21}{crafted}(3-4)% chance to gain a Endurance Charge on Kill
]],[[
Voideye
Unset Ring
League: Ambush, Invasion
Requires Level 45
Implicits: 1
Has 1 Socket
+5 to Level of Socketed Gems
]],[[
Replica Voideye
Unset Ring
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 45
Implicits: 1
Has 1 Socket
+30% to Quality of Socketed Gems
]],[[
The Warden's Brand
Iron Ring
Requires Level 30
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
{tags:physical_damage,attack}Adds (5-15) to (25-50) Physical Damage to Attacks
{tags:attack,speed}30% reduced Attack Speed
15% chance to gain a Frenzy Charge when you Stun an Enemy
]],[[
Warrior's Legacy
Ruby Ring
Requires Level 16
Implicits: 1
{tags:resistance}+(20-30)% to Fire Resistance
{tags:attribute}+(30-50) to Strength
{tags:attack}(20-25)% increased Melee Damage
30% chance to Avoid being Stunned
{tags:attack,speed}20% less Attack Speed
{tags:attack}Strike Skills also target the previous location they were used
]],[[
Call of the Void
Sapphire Ring
Shaper Item
Elder Item
Source: Drops from unique{The Elder} (Uber Uber)
Requires Level 16
Implicits: 1
{tags:resistance}+(20-30)% to Cold Resistance
{tags:resistance}+(20-30)% to Cold Resistance
All Damage with Hits can Chill
All Damage Taken from Hits can Chill you
Enemies Chilled by your Hits can be Shattered as though Frozen
Enemies Chilled by your Hits lessen their Damage dealt by half of Chill Effect
]],[[
Kalandra's Touch
Ring
League: Kalandra
Reflects opposite Ring
Mirrored
]],[[
Betrayal's Sting
Steel Ring
Source: Drops from unique{Incarnation of Neglect} in normal{Moment of Loneliness}
Requires Level 80
Implicits: 1
{tags:physical_damage,attack}Adds (3-4) to (10-14) Physical Damage to Attacks
{tags:attribute}+(20-35) to Dexterity
{tags:resistance}-(30-20)% to all Elemental Resistances
{tags:resistance}+(20-30)% to Chaos Resistance
{tags:speed}5% increased Movement Speed
{tags:chaos_damage}(25-40)% chance to inflict an additional Poison on the same Target when you inflict Poison
]],[[
Coiling Whisper
Amethyst Ring
Source: Drops from unique{Incarnation of Fear} in normal{Moment of Trauma}
Requires Level 32
Implicits: 1
{tags:resistance}+(17-23)% to Chaos Resistance
{tags:caster}(25-50)% reduced Area of Effect of Hex Skills
Targets are Unaffected by your Hexes
When 90% of your Hex's Duration Expires on an Enemy, Eat 1 Soul per Enemy Power
]],[[
Enmity's Embrace
Vermillion Ring
Source: Drops from unique{Incarnation of Fear} in normal{Moment of Trauma}
Requires Level 80
Implicits: 1
{tags:resource}(5-7)% increased maximum Life
{tags:attribute}+(30-50) to Strength
{tags:elemental_damage}(10-20)% increased Fire Damage
{tags:resistance}(65-75)% reduced Fire Resistance
{tags:elemental_damage}Take (300-500) Fire Damage when you Use a Skill
Damage Penetrates Fire Resistance equal to your Overcapped Fire Resistance, up to a maximum of 200%
]],[[
Prospero's Protection
Iron Ring
Requires Level 32
Implicits: 1
{tags:physical_damage,attack}Adds 1 to 4 Physical Damage to Attacks
(4-6)% Chance to Block Attack Damage
{tags:attribute}+(15-35) to Strength
{tags:resource}+(45-60) to maximum Life
{tags:defences}Armour from Equipped Shield is doubled
{tags:defences}Gain no Armour from Equipped Body Armour
]],[[
Squirming Terror
Unset Ring
Requires Level 32
Implicits: 1
Has 1 Socket
An Enemy Writhing Worm spawns every 2 seconds
{tags:caster}20% chance to Trigger Socketed Spell on Kill, with a 0.5 second Cooldown
{tags:resource}Lose (10-20) Life per Enemy Killed
{tags:resource}Gain (5-10) Mana per Enemy Killed
]],
[[
Lost Unity
Formless Ring
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Requires Level 42
Implicits: 1
{tags:defences}(5-7)% increased Global Defences
Grants Level 30 Herald of the Hive Skill
{tags:resistance}+(10-20)% to all Elemental Resistances
{tags:resistance}+(23-37)% to Chaos Resistance
]],
[[
The Sundered Will
Fugitive Ring
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Requires Level 42
Implicits: 2
{tags:resistance}+2% to maximum Chaos Resistance
{tags:resistance}Cannot roll Modifiers of Non-Chaos Damage Types
{tags:attribute}+(7-13) to all Attributes
{tags:chaos_damage}Adds (7-11) to (17-23) Chaos Damage
{tags:resistance}+(13-29)% to Chaos Resistance
(20-30)% increased Area of Effect of Aura Skills
(20-35)% reduced Reservation Efficiency of Skills
Increases and Reductions to Chaos Damage also apply to Effect of
Auras from Chaos Skills at (10-15)% of their value, up to a maximum of 150%
]],
[[
The Unseen Hue
Opal Ring
Source: Drops from unique{Incarnation of Dread} in normal{Moment of Reverence}
Requires Level 80
Variant: Scorch
Variant: Brittle
Variant: Sap
Implicits: 1
{tags:elemental_damage}(15-25)% increased Elemental Damage
{tags:resistance}+(5-30)% to Fire Resistance
{tags:resistance}+(5-30)% to Cold Resistance
{tags:resistance}+(5-30)% to Lightning Resistance
{tags:attack,caster,speed}(6-12)% increased Attack and Cast Speed
(10-20)% increased Effect of Non-Damaging Ailments
{variant:2}Hits with Prismatic Skills always inflict Brittle
{variant:3}Hits with Prismatic Skills always Sap
{variant:1}Hits with Prismatic Skills always Scorch
]],[[
The Will of Esh
Synaptic Ring
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Requires Level 42
Implicits: 2
{tags:resistance}+2% to maximum Lightning Resistance
{tags:resistance}Cannot roll Modifiers of Non-Lightning Damage Types
{tags:attribute}+(15-25) to Intelligence
{tags:elemental_damage}Adds (1-2) to (43-56) Lightning Damage
{tags:resistance}+(20-30)% to Lightning Resistance
(20-30)% increased Area of Effect of Aura Skills
(20-35)% reduced Reservation Efficiency of Skills
Increases and Reductions to Lightning Damage also apply to Effect of
Auras from Lightning Skills at (10-15)% of their value, up to a maximum of 150%
]],
[[
The Will of Tul
Cryonic Ring
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Requires Level 42
Implicits: 2
{tags:resistance}+2% to maximum Cold Resistance
{tags:resistance}Cannot roll Modifiers of Non-Cold Damage Types
{tags:attribute}+(15-25) to Dexterity
{tags:elemental_damage}Adds (8-12) to (18-26) Cold Damage
{tags:resistance}+(20-30)% to Cold Resistance
(20-30)% increased Area of Effect of Aura Skills
(20-35)% reduced Reservation Efficiency of Skills
Increases and Reductions to Cold Damage also apply to Effect of
Auras from Cold Skills at (10-15)% of their value, up to a maximum of 150%
]],
[[
The Will of Uul-Netol
Organic Ring
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Requires Level 42
Implicits: 2
3% additional Physical Damage Reduction
Cannot roll Modifiers of Non-Physical Damage Types
{tags:attribute}+(15-25) to Strength
{tags:physical_damage}Adds (8-12) to (14-20) Physical Damage
{tags:defences}(20-30)% increased Armour
(20-30)% increased Area of Effect of Aura Skills
(20-35)% reduced Reservation Efficiency of Skills
Increases and Reductions to Physical Damage also apply to Effect of
Auras from Physical Skills at (10-15)% of their value, up to a maximum of 150%
]],
[[
The Will of Xoph
Enthalpic Ring
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Requires Level 42
Implicits: 2
{tags:resistance}+2% to maximum Fire Resistance
{tags:resistance}Cannot roll Modifiers of Non-Fire Damage Types
{tags:attribute}+(15-25) to Strength
{tags:elemental_damage}Adds (10-14) to (26-34) Fire Damage
{tags:resistance}+(20-30)% to Fire Resistance
(20-30)% increased Area of Effect of Aura Skills
(20-35)% reduced Reservation Efficiency of Skills
Increases and Reductions to Fire Damage also apply to Effect of
Auras from Fire Skills at (10-15)% of their value, up to a maximum of 150%
]],
[[
Woespike
Steel Ring
Source: Drops from unique{Uber Incarnation of Fear} in normal{Moment of Trauma}
Variant: Pre 3.28.0
Variant: Current
Requires Level 80
Implicits: 1
{tags:physical_damage,attack}Adds (3-4) to (10-14) Physical Damage to Attacks
{tags:attribute}+(25-40) to Strength and Dexterity
{tags:physical_damage,attack}Adds (8-12) to (18-24) Physical Damage to Attacks
{tags:attack}(10-20)% chance to Impale Enemies on Hit with Attacks
{variant:1}{tags:attack}(45-60)% chance on Melee Hit for the Strongest Impale on target to last for 1 additional Hit
{variant:2}{tags:attack}(20-30)% chance on Melee Hit for the Strongest Impale on target to last for 1 additional Hit
{variant:2}(40-50)% less Impale Duration
{variant:1}(40-25)% reduced Impale Duration
]],
[[
Zana's Ingenuity
Prismatic Ring
Source: Drops from unique{The Shaper} (Uber)
Variant: Life
Variant: Energy Shield
Variant: Mana
Variant: Reflect Immune
Variant: No damage from Crits
Variant: No Monster Suppress
Variant: No Enemy Pen
Variant: Charges cannot be stolen
Variant: Burning Ground Immune
Variant: Shocked Ground Immune
Variant: Desecrated Ground Immune
Variant: Chilled Ground Immune
Requires Level 64
Implicits: 1
{tags:resistance}+(8-10)% to all Elemental Resistances
{tags:attack,speed}(5-15)% increased Attack Speed
{variant:5}{group:2}{tags:critical}You take 100% reduced Extra Damage from Critical Strikes
{variant:2}{group:1}{tags:defences}20% increased maximum Energy Shield
{variant:1}{group:1}{tags:resource}10% increased maximum Life
{variant:3}{group:1}{tags:resource}20% increased maximum Mana
{tags:resistance}+(-15-15)% to all Elemental Resistances
{variant:4}{group:2}Damage cannot be Reflected
{variant:7}{group:2}Elemental Resistances cannot be Penetrated
{variant:9}{group:3}Unaffected by Burning Ground
{variant:12}{group:3}Unaffected by Chilled Ground
{variant:11}{group:3}Unaffected by Desecrated Ground
{variant:10}{group:3}Unaffected by Shocked Ground
{variant:8}{group:2}Monsters cannot steal or remove your Power, Frenzy or Endurance charges on Hit
{variant:6}{group:2}Monsters cannot Suppress your Spells
]],
}
