-- Item data (c) Grinding Gear Games

return {
-- Weapon: One Handed Axe
[[
Actum
Butcher Axe
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
Variant: Pre 3.26.0
Variant: Current
Has no Sockets
(200-250)% increased Physical Damage
You have no Intelligence
{variant:1}Critical Strike Chance is (20-30)% for Hits with this Weapon
{variant:2}Critical Strike Chance is (30-40)% for Hits with this Weapon
]],[[
Dreadarc
Cleaver
Implicits: 0
Adds (5-15) to (20-25) Physical Damage
Adds (5-15) to (20-25) Fire Damage
(7-10)% increased Attack Speed
+(15-25)% to Fire Resistance
5% increased Movement Speed
Curse Enemies with Flammability on Hit
]],[[
Dreadsurge
Cleaver
Source: No longer obtainable
LevelReq: 60
Implicits: 0
Adds (5-15) to (20-25) Physical Damage
Adds (223-250) to (264-280) Fire Damage
(7-10)% increased Attack Speed
+(15-25)% to Fire Resistance
5% increased Movement Speed
Hits ignore Enemy Monster Fire Resistance while you are Ignited
]],[[
Dyadus
Infernal Axe
Variant: Pre 2.6.0
Variant: Current
Implicits: 0
{variant:1}Adds (170-190) to (200-220) Fire Damage in Main Hand
{variant:2}Adds (255-285) to (300-330) Fire Damage in Main Hand
{variant:1}Adds (170-190) to (200-220) Cold Damage in Off Hand
{variant:2}Adds (255-285) to (300-330) Cold Damage in Off Hand
(10-15)% increased Attack Speed
25% chance to Ignite when in Main Hand
{variant:1}100% increased Chill Duration on Enemies when in Off Hand
{variant:1}40% increased Damage with Ignite inflicted on Chilled Enemies
{variant:2}100% increased Damage with Ignite inflicted on Chilled Enemies
{variant:2}Chill Enemies for 1 second on Hit with this Weapon when in Off Hand
]],[[
The Screaming Eagle
Jade Hatchet
Variant: Pre 2.0.0
Variant: Current
Implicits: 0
Socketed Gems are supported by Level 2 Chance to Flee
{variant:1}Adds (8-12) to (18-22) Physical Damage
{variant:2}Adds (10-15) to (25-30) Physical Damage
+(10-15) to maximum Life
Gain (5-7) Life per Enemy Killed
10% increased Movement Speed
]],[[
The Gryphon
Jade Hatchet
Source: No longer obtainable
Variant: Pre 2.0.0
Variant: Current
LevelReq: 32
Implicits: 0
Socketed Gems are supported by Level 2 Chance to Flee
(170-190)% increased Physical Damage
{variant:1}Adds (8-12) to (18-22) Physical Damage
{variant:2}Adds (10-15) to (25-30) Physical Damage
+(10-15) to maximum Life
Gain (5-7) Life per Enemy Killed
10% increased Movement Speed
15% increased Movement Speed if you've Killed Recently
]],[[
Jack, the Axe
Vaal Hatchet
Variant: Pre 3.13.0
Variant: Current
Implicits: 0
{variant:2}Grants Level 20 Thirst for Blood Skill
{variant:1}(90-110)% increased Physical Damage
{variant:2}(130-150)% increased Physical Damage
Adds (11-14) to (18-23) Physical Damage
{variant:1}(10-15)% increased Attack Speed
{variant:1}2% of Physical Attack Damage Leeched as Life
25% chance to cause Bleeding on Hit
{variant:2}+(25-35)% to Damage over Time Multiplier for Bleeding from Hits with this Weapon
{variant:1}50% reduced total Recovery per second from Life Leech
]],[[
Moonbender's Wing
Tomahawk
Variant: Pre 3.11.0
Variant: Current
Implicits: 0
{variant:1}Grants Level 1 Lightning Warp Skill
{variant:2}Trigger Level 15 Lightning Warp on Hit with this Weapon
{variant:1}(70-90)% increased Physical Damage
{variant:2}(30-50)% increased Physical Damage
{variant:1}Adds (5-9) to (13-17) Physical Damage
(30-50)% increased Critical Strike Chance
{variant:1}25% of Physical Damage Converted to Cold Damage
{variant:1}25% of Physical Damage Converted to Lightning Damage
{variant:2}Hits with this Weapon gain (75-100)% of Physical Damage as Extra Cold or Lightning Damage
]],[[
Relentless Fury
Decorative Axe
Variant: Pre 2.6.0
Variant: Current
Implicits: 0
(60-80)% increased Physical Damage
Adds (3-5) to (7-10) Physical Damage
{variant:1}0.6% of Physical Attack Damage Leeched as Life
{variant:2}2% of Physical Attack Damage Leeched as Life
Culling Strike
You gain Onslaught for 3 seconds on Culling Strike
100% chance to Avoid being Chilled during Onslaught
]],[[
Rigwald's Savagery
Royal Axe
League: Talisman Standard, Talisman Hardcore
Source: Drops from unique{Rigwald, the Wolven King} (Level 75+)
Variant: Pre 3.11.0
Variant: Pre 3.25.0
Variant: Current
Implicits: 0
Adds (50-70) to (135-165) Physical Damage
40% increased Physical Attack Damage while Dual Wielding
(10-15)% increased Attack Speed
{variant:1}35% increased Attack Speed with Swords
{variant:1}25% chance to cause Bleeding on Hit
{variant:2}+25 to Maximum Rage while wielding a Sword
{variant:3}+10 to Maximum Rage while wielding a Sword
]],[[
Soul Taker
Siege Axe
Variant: Pre 1.0.0
Variant: Pre 3.20.0
Variant: Pre 3.26.0
Variant: Pre 3.28.0
Variant: Current
Implicits: 0
{variant:1}(160-200)% increased Physical Damage
{variant:2}(100-140)% increased Physical Damage
{variant:3,4,5}(140-180)% increased Physical Damage
{variant:1,2}Adds 10 to 20 Physical Damage
{variant:3,4,5}Adds 30 to 40 Physical Damage
{variant:1,2,3}(20-25)% increased Attack Speed
{variant:4,5}(25-35)% increased Attack Speed
+(20-25)% to Cold Resistance
Your Physical Damage can Chill
Insufficient Mana doesn't prevent your Melee Attacks
{variant:5}Eat (2-4) Souls when you Kill a Rare or Unique Enemy with this Weapon
]],[[
Replica Soul Taker
Siege Axe
League: Heist
Source: No longer obtainable
Implicits: 0
(100-140)% increased Physical Damage
Adds 10 to 20 Physical Damage
(60-80)% increased Critical Strike Chance
+(20-25)% to Cold Resistance
Your Physical Damage can Freeze
Eldritch Battery
]],[[
Starcaller
Abyssal Axe
Source: Drops from unique{Incarnation of Fear} in normal{Moment of Trauma}
Requires Level 55, 128 Str, 60 Dex
Trigger Level 20 Starfall on Melee Critical Strike
+(10-20) to all Attributes
(120-180)% increased Physical Damage
(20-30)% increased Critical Strike Chance
(10-20)% increased Area of Effect
Gain (40-60)% of Weapon Physical Damage as Extra Damage of a random Element
]],
[[
The Grey Wind
Spectral Axe
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Variant: Pre 3.29.0
Variant: Current
Requires Level 33, 85 Str, 37 Dex
(30-50)% increased Fire Damage
{variant:1}Attacks with this Weapon have Added Fire Damage equal to (8-12)% of Player's Maximum Life
{variant:2}Attacks with this Weapon have Added Fire Damage equal to (6-10)% of Player's Maximum Life
Each Rage also grants +2% to Fire Damage Over Time Multiplier
Nearby Enemies have Fire Exposure while at maximum Rage
+(-5-5) to Maximum Rage
]],
-- Weapon: Two Handed Axe
[[
Atziri's Disfavour
Vaal Axe
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Alluring Abyss}
Variant: Pre 3.11.0
Variant: Pre 3.20.0
Variant: Current
LevelReq: 75
Implicits: 1
{variant:2,3}25% chance to Maim on Hit
{variant:1,2}+2 to Level of Socketed Support Gems
{variant:3}+30% to Quality of Socketed Support Gems
{variant:1}Adds (220-235) to (270-290) Physical Damage
{variant:2}Adds (205-220) to (250-270) Physical Damage
{variant:3}Adds (310-330) to (370-390) Physical Damage
(12-16)% increased Attack Speed
25% chance to cause Bleeding on Hit
{variant:1,2}+0.2 metres to Weapon Range
{variant:3}+1 metres to Weapon Range
]],[[
The Blood Reaper
Headsman Axe
Variant: Pre 3.0.0
Variant: Pre 3.12.0
Variant: Current
Implicits: 0
{variant:1}(100-120)% increased Physical Damage
{variant:2,3}(180-200)% increased Physical Damage
+100 to maximum Life
{variant:1,2}Regenerate 10 Life per second
{variant:3}Regenerate 20 Life per second
1% of Physical Attack Damage Leeched as Life
50% increased Mana Cost of Skills
50% chance to cause Bleeding on Hit
]],[[
Debeon's Dirge
Despot Axe
Implicits: 0
Adds (310-350) to (460-500) Cold Damage
15% increased Movement Speed if you've Warcried Recently
150% increased Elemental Damage if you've Warcried Recently
Warcries Knock Back and Interrupt Enemies in a smaller Area
]],[[
The Harvest
Jasper Chopper
League: Beyond
Implicits: 0
(120-140)% increased Physical Damage
1.2% of Damage Leeched as Life on Critical Strike
3% increased Global Critical Strike Chance per Level
Gain a Flask Charge when you deal a Critical Strike
]],[[
Replica Harvest
Jasper Chopper
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 0
(120-140)% increased Physical Damage
1.2% of Damage Leeched as Life on Critical Strike
3% increased Global Critical Strike Chance per Level
Gain Elusive on Critical Strike
]],[[
Hezmana's Bloodlust
Vaal Axe
Variant: Pre 3.11.0
Variant: Current
Implicits: 1
{variant:2}25% chance to Maim on Hit
{variant:1}(150-170)% increased Physical Damage
{variant:2}(100-125)% increased Physical Damage
Adds (7-10) to (15-25) Physical Damage
1% of Physical Attack Damage Leeched as Life
{variant:2}40% increased Attack Speed if you've taken a Savage Hit Recently
Attacks Cost Life instead of Mana
]],[[
Kaom's Primacy
Karui Chopper
League: Legion
Variant: Pre 1.0.0
Variant: Pre 3.7.0
Variant: Pre 3.11.0
Variant: Pre 3.25.0
Variant: Current
Implicits: 0
{variant:1}(120-150)% increased Physical Damage
{variant:2,3}(160-220)% increased Physical Damage
{variant:4,5}(100-140)% increased Physical Damage
{variant:1,2}Adds (16-21) to (32-38) Fire Damage
Gain 20 Life per Enemy Killed
+(150-250) to Accuracy Rating
Culling Strike
{variant:5}Gain 5 Rage on Melee Hit
{variant:3,4}Gain 1 Rage on Critical Strike with Attacks
{variant:3,4,5}Every Rage also grants 1% of Physical Damage as Extra Fire Damage
]],[[
Kingmaker
Despot Axe
Source: Vendor Recipe
Variant: Pre 2.6.0
Variant: Pre 3.6.0
Variant: Pre 3.11.0
Variant: Pre 3.16.0
Variant: Pre 3.20.0
Variant: Current
Implicits: 0
{variant:1,2}(200-250)% increased Physical Damage
{variant:3}(250-285)% increased Physical Damage
{variant:4}(170-200)% increased Physical Damage
{variant:5}(190-240)% increased Physical Damage
{variant:6}(300-360)% increased Physical Damage
(7-12)% increased Attack Speed
{variant:2,3,4,5,6}(30-40)% increased Critical Strike Chance
{variant:1}+(100-150) to maximum Mana
Nearby Allies have 30% increased Item Rarity
Nearby Allies have Culling Strike
{variant:2,3,4,5,6}Insufficient Mana doesn't prevent your Melee Attacks
{variant:3,4,5,6}Nearby Allies have +50% to Critical Strike Multiplier
{variant:3,4}Nearby Allies have +1 Fortification
{variant:5,6}Nearby Allies have +10 Fortification
]],[[
Kitava's Feast
Void Axe
Variant: Pre 3.5.0
Variant: Pre 3.11.0
Variant: Current
Implicits: 0
Socketed Gems are supported by Level 30 Melee Splash
{variant:1}(250-300)% increased Physical Damage
{variant:2}(265-330)% increased Physical Damage
{variant:3}(200-240)% increased Physical Damage
1% of Physical Attack Damage Leeched as Life
1% of Physical Attack Damage Leeched as Mana
Recover 5% of Life on Kill
Enemies Killed by your Hits are destroyed
]],[[
Limbsplit
Woodsplitter
Variant: Pre 3.11.0
Variant: Current
Implicits: 0
+1 to Level of Socketed Strength Gems
{variant:2}Trigger Level 1 Gore Shockwave on Melee Hit if you have at least 150 Strength
+(15-30) to Strength
(80-100)% increased Physical Damage
Adds 5 to 10 Physical Damage
Culling Strike
]],[[
The Cauteriser
Woodsplitter
Source: No longer obtainable
Variant: Pre 3.11.0
Variant: Current
LevelReq: 40
Implicits: 0
+1 to Level of Socketed Strength Gems
{variant:2}Trigger Level 5 Gore Shockwave on Melee Hit if you have at least 150 Strength
+(15-30) to Strength
(80-100)% increased Physical Damage
Adds (35-45) to (80-90) Physical Damage
Gain 70% of Physical Damage as Extra Fire Damage
Culling Strike
]],[[
Ngamahu's Flame
Abyssal Axe
Variant: Pre 3.11.0
Variant: Current
Implicits: 0
20% chance to Trigger Level 16 Molten Burst on Melee Hit
{variant:1}(190-230)% increased Physical Damage
{variant:2}(170-190)% increased Physical Damage
(8-12)% increased Attack Speed
{variant:1}50% of Physical Damage Converted to Fire Damage
{variant:2}60% of Physical Damage Converted to Fire Damage
Damage Penetrates 20% Fire Resistance
]],[[
Reaper's Pursuit
Shadow Axe
Implicits: 0
(100-125)% increased Physical Damage
(30-40)% increased Rarity of Items found
Gain 10 Life per Enemy Killed
15% increased Movement Speed when on Full Life
Culling Strike
Hits can't be Evaded
]],[[
Sinvicta's Mettle
Ezomyte Axe
Variant: Pre 3.11.0
Variant: Current
Implicits: 0
{variant:1}(200-212)% increased Physical Damage
{variant:2}(140-152)% increased Physical Damage
(8-12)% increased Attack Speed
2% increased Area of Effect per 25 Rampage Kills
Gain a Frenzy Charge on every 50th Rampage Kill
Rampage
]],[[
Spinesnatch
Fleshripper
League: Allflame
Source: Drops from unique{Zorath}
Requires Level 70, 156 Str, 84 Dex
Implicits: 1
50% increased Critical Strike Chance
Has 6 Abyssal Sockets
(25-50)% increased Physical Damage per socketed Murderous Eye Jewel
(8-16)% increased Attack Speed per socketed Searching Eye Jewel
(20-40)% increased Critical Strike Chance per socketed Hypnotic Eye Jewel
Minions have (20-40)% chance to Impale on Attack Hit per socketed Ghastly Eye Jewel
]],[[
Uul-Netol's Kiss
{variant:1}Labrys
{variant:2}Vaal Axe
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Uul-Netol Breach or from unique{Uul-Netol, Unburdened Flesh}
Upgrade: Upgrades to unique{Uul-Netol's Embrace} using currency{Blessing of Uul-Netol}
Implicits: 1
{variant:2}25% chance to Maim on Hit
{variant:1}(140-170)% increased Physical Damage
{variant:2}(230-270)% increased Physical Damage
15% reduced Attack Speed
Curse Enemies with Vulnerability on Hit
{variant:1}Attacks have 25% chance to inflict Bleeding when Hitting Cursed Enemies
{variant:2}Exerted Attacks deal 200% increased Damage
{variant:2}Exerted Attacks Knock Enemies Back on Hit
]],[[
Uul-Netol's Embrace
Vaal Axe
League: Breach
Source: Upgraded from unique{Uul-Netol's Kiss} using currency{Blessing of Uul-Netol}
Variant: Pre 3.11.0
Variant: Pre 3.21.0
Variant: Current
Implicits: 1
{variant:2,3}25% chance to Maim on Hit
Trigger Level 20 Bone Nova when you Hit a Bleeding Enemy
(280-320)% increased Physical Damage
(25-30)% reduced Attack Speed
{variant:3}25% chance to cause Bleeding on Hit
{variant:1,2}Attacks have 25% chance to inflict Bleeding when Hitting Cursed Enemies
]],[[
Wideswing
Poleaxe
Variant: Pre 3.7.0
Variant: Current
Implicits: 0
Socketed Gems are Supported by Level 20 Increased Area of Effect
+10 to Strength
(120-160)% increased Physical Damage
Gain 10 Mana per Enemy Killed
{variant:1}+(50-80) to Accuracy Rating
{variant:2}+(120-150) to Accuracy Rating
+0.2 metres to Weapon Range
]],[[
Replica Wings of Entropy
Ezomyte Axe
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.26.0
Variant: Current
Implicits: 0
(7-10)% Chance to Block Spell Damage
+(8-12)% Chance to Block Attack Damage while Dual Wielding
(60-80)% increased Physical Damage
Counts as Dual Wielding
{variant:1}+(8-10)% to Off Hand Critical Strike Chance
{variant:2}+(10-20)% to Off Hand Critical Strike Chance
{variant:1}(50-70)% more Main Hand attack speed
{variant:2}(50-100)% more Main Hand attack speed
]],[[
Wings of Entropy
{variant:1,2,3,4}Sundering Axe
{variant:5}Ezomyte Axe
Variant: Pre 1.3.0
Variant: Pre 2.0.0
Variant: Pre 3.4.0
Variant: Pre 3.11.0
Variant: Pre 3.26.0
Variant: Current
Implicits: 0
{variant:1,2,3}7% Chance to Block Spell Damage
{variant:4}(6-7)% Chance to Block Spell Damage
{variant:5,6}(7-10)% Chance to Block Spell Damage
{variant:1}+10% Chance to Block Attack Damage while Dual Wielding
{variant:2,3,4}+8% Chance to Block Attack Damage while Dual Wielding
{variant:5,6}+(8-12)% Chance to Block Attack Damage while Dual Wielding
{variant:1,2}(80-120)% increased Physical Damage
{variant:3,4}(100-120)% increased Physical Damage
{variant:5,6}(60-80)% increased Physical Damage
{variant:1,2,3,4}Adds (55-65) to (100-120) Fire Damage in Main Hand
{variant:5}Adds (75-100) to (165-200) Fire Damage in Main Hand
{variant:6}Adds (150-200) to (330-400) Fire Damage in Main Hand
{variant:1,2,3,4}Adds (55-65) to (100-120) Chaos Damage in Off Hand
{variant:5}Adds (75-100) to (165-200) Chaos Damage in Off Hand
{variant:6}Adds (151-199) to (331-401) Chaos Damage in Off Hand
Counts as Dual Wielding
]],
}
