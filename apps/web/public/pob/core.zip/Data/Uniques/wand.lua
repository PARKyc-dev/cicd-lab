-- Item data (c) Grinding Gear Games

return {
-- Weapon: Wand
[[
Abberath's Horn
Goat's Horn
Variant: Pre 2.3.0
Variant: Pre 3.21.0
Variant: Pre 3.29.0
Variant: Current
Implicits: 3
{variant:1}(9-12)% increased Spell Damage
{variant:2}(10-14)% increased Spell Damage
{variant:3,4}Adds (1-2) to (3-4) Fire Damage to Spells and Attacks
{variant:4}+(30-50)% to Damage over Time Multiplier for Ignite from Critical Strikes
{variant:1,2,3}(20-30)% increased Fire Damage
Adds (4-6) to (8-12) Fire Damage to Spells
{variant:1,2,3}(40-60)% increased Global Critical Strike Chance
{variant:4}(80-120)% increased Global Critical Strike Chance
Gain 10 Life per Ignited Enemy Killed
25% reduced Ignite Duration on Enemies
]],[[
Apep's Rage
{variant:1,2,3,4,5}Opal Wand
{variant:6}Omen Wand
Variant: Pre 2.3.0
Variant: Pre 3.7.0
Variant: Pre 3.11.0
Variant: Pre 3.19.0
Variant: Pre 3.21.0
Variant: Current
Implicits: 3
{variant:1}(17-20)% increased Spell Damage
{variant:2,3,4,5}(38-42)% increased Spell Damage
{variant:6}(27-31)% increased Spell Damage
{variant:1,2}Adds (50-65) to (90-105) Chaos Damage to Spells
{variant:3,4,5,6}Adds (90-130) to (140-190) Chaos Damage to Spells
(25-30)% increased Cast Speed
+(5-10)% to Chaos Resistance
{variant:1,2,3}40% increased Mana Cost of Skills
{variant:3,4}Poisons you inflict deal Damage 20% faster
{variant:5,6}Poisons you inflict deal Damage (30-50)% faster
{variant:4,5,6}Lose 40 Mana when you use a Skill
]],[[
Ashcaller
{variant:1,2,3}Quartz Wand
{variant:4}Carved Wand
{variant:5}Goat's Horn
Variant: Pre 3.8.0
Variant: Pre 3.19.0
Variant: Pre 3.21.0
Variant: Pre 3.27.0
Variant: Current
Implicits: 3
{variant:1,2,3}(18-22)% increased Spell Damage
{variant:4}(11-15)% increased Spell Damage
{variant:5}Adds (1-2) to (3-4) Fire Damage to Spells and Attacks
{variant:1,2}10% chance to Trigger Level 10 Summon Raging Spirit on Kill
{variant:3,4,5}25% chance to Trigger Level 10 Summon Raging Spirit on Kill
{variant:2}+(15-25)% to Fire Damage over Time Multiplier
{variant:1}Adds (10-14) to (18-22) Fire Damage
{variant:3,4,5}Adds (20-24) to (38-46) Fire Damage
{variant:1,2}Adds (4-6) to (7-9) Fire Damage to Spells
{variant:3,4,5}Adds (20-24) to (36-46) Fire Damage to Spells
{variant:1}(40-50)% increased Burning Damage
{variant:2}(20-30)% increased Burning Damage
{variant:1,2}(16-22)% chance to Ignite
{variant:3,4,5}10% chance to Cover Enemies in Ash on Hit
]],[[
Eclipse Solaris
{variant:1,2,3,4}Crystal Wand
{variant:5}Engraved Wand
{variant:6}Faun's Horn
Variant: Pre 2.2.0
Variant: Pre 2.3.0
Variant: Pre 3.10.0
Variant: Pre 3.21.0
Variant: Pre 3.27.0
Variant: Current
Implicits: 4
{variant:1,2}(14-18)% increased Spell Damage
{variant:3,4}(29-33)% increased Spell Damage
{variant:5}(22-26)% increased Spell Damage
{variant:6}Adds (5-10) to (11-13) Fire Damage to Spells and Attacks
{variant:1,2,3}Adds (18-22) to (36-44) Physical Damage
{variant:4,5}Adds (30-45) to (60-80) Fire Damage
{variant:4,5}(6-10)% increased Attack Speed
{variant:6}(20-26)% increased Attack Speed
{variant:1}+(18-30)% to Global Critical Strike Multiplier
{variant:2,3,4,5,6}+(27-33)% to Global Critical Strike Multiplier
{variant:1,2,3,4,5}20% increased Light Radius
{variant:6}(15-20)% increased Light Radius
Nearby Enemies are Blinded
(120-140)% increased Critical Strike Chance against Blinded Enemies
Adds 2 to 5 Fire Damage to Attacks for every 1% your Light Radius is above base value
]],[[
Corona Solaris
Crystal Wand
Source: No longer obtainable
Variant: Pre 3.10.0
Variant: Current
LevelReq: 63
Implicits: 1
(30-34)% increased Spell Damage
Triggers Level 20 Blinding Aura when Equipped
{variant:1}Adds (18-22) to (36-44) Physical Damage
{variant:2}Adds (30-45) to (60-80) Fire Damage
{variant:2}(6-10)% increased Attack Speed
+(27-33)% to Global Critical Strike Multiplier
20% increased Light Radius
(120-140)% increased Critical Strike Chance against Blinded Enemies
Increases and Reductions to Light Radius also apply to Accuracy
Adds (145-157) to (196-210) Fire Damage to Hits with this Weapon against Blinded Enemies
]],[[
Grace of the Goddess
Prophecy Wand
Source: Drops from unique{The Maven} (Uber)
Variant: Pre 3.26.0
Variant: Current
Implicits: 1
(36-40)% increased Spell Damage
(300-350)% increased Physical Damage
{variant:1}Gain (10-30)% of Physical Damage as Extra Fire Damage
{variant:2}Gain (10-50)% of Physical Damage as Extra Fire Damage
{variant:1}Gain (10-30)% of Physical Damage as Extra Cold Damage
{variant:2}Gain (10-50)% of Physical Damage as Extra Cold Damage
{variant:1}Gain (10-30)% of Physical Damage as Extra Lightning Damage
{variant:2}Gain (10-50)% of Physical Damage as Extra Lightning Damage
+1 to maximum number of Sacred Wisps
+1 to number of Sacred Wisps Summoned
]],[[
Lifesprig
Driftwood Wand
Implicits: 1
(8-12)% increased Spell Damage
+1 to Level of Socketed Spell Gems
(20-28)% increased Spell Damage
(5-8)% increased Cast Speed
+(15-20) to maximum Life
+(15-20) to maximum Mana
Regenerate (6-8) Life over 1 second for each Spell you Cast
]],[[
Midnight Bargain
{variant:1,2,3}Engraved Wand
{variant:4}Calling Wand
Variant: Pre 2.3.0
Variant: Pre 3.8.0
Variant: Pre 3.27.0
Variant: Current
Implicits: 3
{variant:1}(12-16)% increased Spell Damage
{variant:2,3}(22-26)% increased Spell Damage
{variant:4}Minions deal (12-16)% increased Damage
Cannot be used with Chaos Inoculation
Reserves 30% of Life
+(10-20) to Intelligence
{variant:1,2}Minions have (10-20)% increased Movement Speed
{variant:3,4}Minions have (20-30)% increased Movement Speed
{variant:1,2}Minions deal (10-30)% increased Damage
{variant:3,4}Minions deal (50-70)% increased Damage
+1 to maximum number of Raised Zombies
+1 to maximum number of Spectres
+1 to maximum number of Skeletons
]],[[
Replica Midnight Bargain
{variant:1}Engraved Wand
{variant:2}Calling Wand
Variant: Pre 3.27.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 2
{variant:1}(22-26)% increased Spell Damage
{variant:2}Minions deal (12-16)% increased Damage
Cannot be used with Chaos Inoculation
Reserves 30% of Life
+(10-20) to Intelligence
Minions have (40-50)% increased Movement Speed
Minions deal (50-70)% increased Damage
+6 to maximum number of Raging Spirits
+3 to maximum number of Summoned Phantasms
]],[[
Moonsorrow
Imbued Wand
{variant:1,2,3,4}Imbued Wand
{variant:5}Kinetic Wand
Variant: Pre 2.0.0
Variant: Pre 2.3.0
Variant: Pre 3.0.0
Variant: Pre 3.27.0
Variant: Current
Implicits: 3
{variant:1,2}(15-19)% increased Spell Damage
{variant:3,4}(33-37)% increased Spell Damage
{variant:5}Cannot roll Caster Modifiers
{variant:1,2,3}Socketed Gems are supported by Level 5 Blind
{variant:4,5}Socketed Gems are supported by Level 20 Blind
+10 to Intelligence
(30-40)% increased Spell Damage
{variant:1}125% increased Physical Damage
{variant:2,3}175% increased Physical Damage
{variant:4,5}(250-275)% increased Physical Damage
(20-30)% increased Lightning Damage
10% increased Cast Speed
10% chance to Blind Enemies on hit
]],[[
Mystic Refractor
Pagan Wand
Variant: Pre 3.29.0
Variant: Current
Requires Level 34, 118 Int
Implicits: 1
10% increased Cast Speed
Skills fire (2-3) additional Projectiles
{variant:1}(10-20)% increased Projectile Speed
{variant:2}(10-50)% increased Projectile Speed
(30-50)% increased Projectile Damage
Projectiles cannot continue after colliding with targets
]],[[
Obliteration
{variant:1,2,3,4}Demon's Horn
{variant:5}Imbued Wand
{variant:6}Omen Wand
Variant: Pre 2.3.0
Variant: Pre 3.10.0
Variant: Pre 3.19.0
Variant: Pre 3.21.0
Variant: Pre 3.27.0
Variant: Current
Implicits: 4
{variant:1}(15-18)% increased Spell Damage
{variant:2,3,4}(31-35)% increased Spell Damage
{variant:5}(33-37)% increased Spell Damage
{variant:6}(27-31)% increased Spell Damage
{variant:1,2}Adds (24-30) to (80-92) Physical Damage
{variant:3}Adds (25-50) to (85-125) Physical Damage
{variant:1,2,3}(26-32)% increased Critical Strike Chance
{variant:1,2,3}Gain (13-15)% of Physical Damage as Extra Chaos Damage
{variant:4,5,6}Gain (30-40)% of Physical Damage as Extra Chaos Damage
Enemies you Kill have a 20% chance to Explode, dealing a quarter of their maximum Life as Chaos Damage
]],[[
Piscator's Vigil
{variant:1,2,3}Tornado Wand
{variant:4}Imbued Wand
{variant:5}Kinetic Wand
Variant: Pre 2.3.0
Variant: Pre 2.6.0
Variant: Pre 3.21.0
Variant: Current
Implicits: 4
{variant:1}(16-19)% increased Spell Damage
{variant:2,3}(35-39)% increased Spell Damage
{variant:4}(33-37)% increased Spell Damage
{variant:5}Cannot roll Caster Modifiers
No Physical Damage
(10-18)% increased Attack Speed
(20-30)% increased Critical Strike Chance
+(340-400) to Accuracy Rating
Attacks with this Weapon have (100-115)% increased Elemental Damage
{variant:3,4,5}Damage with Weapons Penetrates 5% Elemental Resistances
]],[[
The Poet's Pen
{variant:1}Carved Wand
{variant:2}Somatic Wand
Implicits: 1
{variant:1}(11-15)% increased Spell Damage
+1 to Level of Socketed Skill Gems per 25 Player Levels
Trigger a Socketed Spell when you Attack with this Weapon, with a 0.25 second Cooldown
Adds 3 to 5 Physical Damage to Attacks with this Weapon per 3 Player Levels
(8-12)% increased Attack Speed
{variant:2}Cannot roll Caster Modifiers
]],[[
Reverberation Rod
Spiraled Wand
Variant: Pre 2.3.0
Variant: Pre 3.11.0
Variant: Pre 3.19.0
Variant: Pre 3.21.0
Variant: Current
Implicits: 3
{variant:1}(10-14)% increased Spell Damage
{variant:2,3,4}(15-19)% increased Spell Damage
{variant:5}Adds (1-2) to (9-11) Lightning Damage to Spells and Attacks
{variant:1,2}+1 to Level of Socketed Gems
{variant:3,4,5}+2 to Level of Socketed Gems
{variant:4,5}Socketed Gems are Supported by Level 10 Arcane Surge
Socketed Gems are Supported by Level 10 Spell Echo
{variant:4,5}Socketed Gems are Supported by Level 10 Controlled Destruction
+(10-30) to Intelligence
]],[[
Relic of the Pact
{variant:1}Spiraled Wand
{variant:2}Sage Wand
Variant: Pre 3.21.0
Variant: Current
League: Ultimatum
Source: Drops from unique{The Trialmaster}
Implicits: 2
{variant:1}(15-19)% increased Spell Damage
{variant:2}(17-21)% increased Spell Damage
Grants Level 1 Blood Sacrament Skill
Your Critical Strike Chance is Lucky while on Low Life
]],[[
Amplification Rod
Spiraled Wand
Source: No longer obtainable
Variant: Pre 3.11.0
Variant: Current
LevelReq: 36
Implicits: 1
(15-19)% increased Spell Damage
{variant:1}+1 to Level of Socketed Gems
{variant:2}+2 to Level of Socketed Gems
Socketed Gems are Supported by Level 10 Intensify
Socketed Gems are Supported by Level 10 Spell Echo
Socketed Gems are Supported by Level 10 Controlled Destruction
+(10-30) to Intelligence
]],[[
Shade of Solaris
Sage Wand
Variant: Pre 3.5.0
Variant: Current
Implicits: 1
(17-21)% increased Spell Damage
Gain (10-20)% of Elemental Damage as Extra Chaos Damage
Critical Strikes deal no Damage
{variant:1}120% increased Spell Damage if you've dealt a Critical Strike in the past 8 seconds
{variant:2}200% increased Spell Damage if you've dealt a Critical Strike in the past 8 seconds
]],[[
Shimmeron
Tornado Wand
Elder Item
Source: Drops from unique{The Elder}
Variant: Pre 3.4.0
Variant: Pre 3.21.0
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:1,2}(35-39)% increased Spell Damage
{variant:3,4}Adds (3-5) to (70-82) Lightning Damage to Spells and Attacks
{variant:1,2,3}(30-40)% increased Spell Damage
{variant:1,2,3}Adds (26-35) to (95-105) Lightning Damage to Spells
{variant:4}+1 to Maximum Power Charges
+(6-10)% to Critical Strike Multiplier per Power Charge
+0.3% to Critical Strike Chance per Power Charge
+2% Chance to Block Spell Damage per Power Charge
{variant:1,2,3}Adds 3 to 9 Lightning Damage to Spells per Power Charge
{variant:4}Adds 3 to (15-25) Lightning Damage to Spells per Power Charge
{variant:1}400 Lightning Damage taken per second per Power Charge if
{variant:1}your Skills have dealt a Critical Strike Recently
{variant:2,3}200 Lightning Damage taken per second per Power Charge if
{variant:2,3}your Skills have dealt a Critical Strike Recently
{variant:4}300 Lightning Damage taken per second per Power Charge if
{variant:4}your Skills have dealt a Critical Strike Recently
]],[[
Storm Prison
{variant:1,2}Carved Wand
{variant:3}Spiraled Wand
Variant: Pre 2.3.0
Variant: Pre 3.21.0
Variant: Current
Implicits: 3
{variant:1}(9-13)% increased Spell Damage
{variant:2}(11-15)% increased Spell Damage
{variant:3}Adds (1-2) to (9-11) Lightning Damage to Spells and Attacks
(40-60)% increased Physical Damage
Adds 1 to (35-45) Lightning Damage
(15-25)% increased Mana Regeneration Rate
+1 to Maximum Power Charges
(25-35)% chance to gain a Power Charge on Kill
]],[[
Tulborn
{variant:1,2}Spiraled Wand
{variant:3}Opal Wand
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Tul Breach or from unique{Tul, Creeping Avalanche}
Upgrade: Upgrades to unique{Tulfall} using currency{Blessing of Tul}
Implicits: 2
{variant:1,2}(15-19)% increased Spell Damage
{variant:3}Adds (14-29) to (42-47) Cold Damage to Spells and Attacks
{variant:3}Adds (120-140) to (150-170) Cold Damage to Spells
{variant:1,2}(10-15)% increased Cast Speed
{variant:1,2}50% chance to gain a Power Charge on Killing a Frozen Enemy
{variant:3}Gain a Power Charge on Killing a Frozen Enemy
{variant:1,2}Adds 10 to 20 Cold Damage to Spells per Power Charge
{variant:3}Cold Exposure you inflict applies an extra -12% to Cold Resistance
+(20-25) Mana gained on Killing a Frozen Enemy
]],[[
Tulfall
{variant:1,2}Tornado Wand
{variant:3}Opal Wand
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Upgraded from unique{Tulborn} using currency{Blessing of Tul}
Implicits: 2
{variant:1,2}(35-39)% increased Spell Damage
{variant:3}Adds (14-29) to (42-47) Cold Damage to Spells and Attacks
{variant:1,2}(10-15)% increased Cast Speed
{variant:3}(10-20)% increased Cast Speed
{variant:1}50% chance to gain a Power Charge on Killing a Frozen Enemy
{variant:2,3}Gain a Power Charge on Killing a Frozen Enemy
{variant:1,2}Adds 15 to 25 Cold Damage to Spells per Power Charge
{variant:3}Adds 50 to 70 Cold Damage to Spells per Power Charge
Lose all Power Charges on reaching Maximum Power Charges
Gain a Frenzy Charge on reaching Maximum Power Charges
{variant:1}(10-15)% increased Cold Damage per Frenzy Charge
{variant:2}(15-20)% increased Cold Damage per Frenzy Charge
]],[[
Replica Tulfall
{variant:1}Tornado Wand
{variant:2}Opal Wand
Variant: Pre 3.21.0
Variant: Pre 3.29.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 2
{variant:1}(35-39)% increased Spell Damage
{variant:2,3}Adds (14-29) to (42-47) Cold Damage to Spells and Attacks
(15-25)% increased Cast Speed
Lose all Power Charges on reaching Maximum Power Charges
Gain a Frenzy Charge on reaching Maximum Power Charges
{variant:1,2}(15-20)% increased Cold Damage per Frenzy Charge
{variant:3}(20-30)% increased Cold Damage per Frenzy Charge
50% chance to gain a Power Charge when you Hit a Frozen Enemy
Take 500 Cold Damage on reaching Maximum Power Charges
]],[[
Twyzel
{variant:1,2}Sage Wand
{variant:3}Blasting Wand
Variant: Pre 2.3.0
Variant: Pre 2.27.0
Variant: Current
Implicits: 2
{variant:1}(11-14)% increased Spell Damage
{variant:2}(17-21)% increased Spell Damage
{variant:1,2}Socketed Gems fire an additional Projectile
{variant:1,2}(80-120)% increased Physical Damage
{variant:3}(80-140)% increased Physical Damage
Adds (5-8) to (13-17) Physical Damage
(5-10)% increased Attack Speed
(10-20)% increased Critical Strike Chance
{variant:3}Cannot roll Caster Modifiers
{variant:3}Attacks fire (1-2) additional Projectile when in Off Hand
{variant:3}Attacks have (40-60)% increased Area of Effect when in Main Hand
]],[[
Replica Twyzel
{variant:1}Sage Wand
{variant:2}Blasting Wand
Variant: Pre 2.27.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 2
{variant:1}(17-21)% increased Spell Damage
{variant:2}Cannot roll Caster Modifiers
(110-170)% increased Physical Damage
(5-10)% increased Attack Speed
(20-40)% increased Critical Strike Chance
Attacks fire an additional Projectile
]],[[
Unlight Extant
Sage Wand
Requires Level 30, 119 Int
Implicits: 1
(17-21)% increased Spell Damage
(31-43)% increased Chaos Damage
(7-13)% increased Cast Speed
+1 to Level of all Chaos Spell Skill Gems
Chaos Skills inflict up to 15 Withered Debuffs on Hit for (5-7) seconds
Cannot Inflict Wither on targets that are not on Full Life
]],[[
Void Battery
Prophecy Wand
Variant: Pre 2.3.0
Variant: Pre 3.29.0
Variant: Current
Implicits: 2
{variant:1}(16-20)% increased Spell Damage
{variant:2,3}(36-40)% increased Spell Damage
{variant:1,2}80% reduced Spell Damage
{variant:3}50% reduced Spell Damage
(10-20)% increased Cast Speed
(50-65)% increased Global Critical Strike Chance
{variant:1,2}+(40-50) to maximum Mana
{variant:3}+(100-120) to maximum Mana
+1 to Maximum Power Charges
{variant:1,2}25% increased Spell Damage per Power Charge
{variant:3}(10-15)% increased Spell Damage per Power Charge
]],
}
