-- Item data (c) Grinding Gear Games

return {
-- Helmet: Armour
[[
Abyssus
Ezomyte Burgonet
Variant: Pre 2.2.0
Variant: Pre 3.0.0
Variant: Current
Requires Level 60, 138 Str
+(20-25) to all Attributes
Adds 40 to 60 Physical Damage to Attacks
{variant:1}+(100-150)% to Melee Critical Strike Multiplier
{variant:2}+(150-225)% to Melee Critical Strike Multiplier
{variant:3}+(100-125)% to Melee Critical Strike Multiplier
(100-120)% increased Armour
(40-50)% increased Physical Damage taken
]],[[
Replica Abyssus
Ezomyte Burgonet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 60, 138 Str
+(20-25) to all Attributes
Adds 40 to 75 Fire Damage to Attacks
Adds 30 to 65 Cold Damage to Attacks
Adds 10 to 130 Lightning Damage to Attacks
+(100-125)% to Melee Critical Strike Multiplier
(100-120)% increased Armour
(40-50)% increased Elemental Damage taken
]],[[
The Baron
Close Helmet
Variant: Pre 3.10.0
Variant: Current
Requires Level 26, 58 Str
+2 to Level of Socketed Minion Gems
{variant:1}+(20-40) to Strength
{variant:1}Minions have 20% increased maximum Life
{variant:2}Minions have (10-20)% increased maximum Life
Half of your Strength is added to your Minions
{variant:1}+1 to maximum number of Raised Zombies per 300 Strength
{variant:2}+1 to maximum number of Raised Zombies per 500 Strength
{variant:1}With at least 1000 Strength, 20% of Damage dealt by your Raised Zombies is Leeched to you as Life
{variant:2}With at least 1000 Strength, (1.5-2)% of Damage dealt by your Raised Zombies is Leeched to you as Life
]],[[
Ezomyte Peak
Iron Hat
Variant: Pre 3.19.0
Variant: Current
{variant:1}20% increased Global Physical Damage
{variant:1}+(15-25) to Armour
{variant:2}+(75-100) to Armour
+(25-50) to maximum Life
{variant:2}(15-20)% increased Area of Effect
{variant:1}Cannot Evade Enemy Attacks
{variant:2}Unwavering Stance
]],[[
Ezomyte Hold
Iron Hat
Source: No longer obtainable
20% increased Global Physical Damage
+(15-25) to Armour
+(25-50) to maximum Life
Cannot Evade Enemy Attacks
Cannot be Stunned
]],[[
The Formless Flame
{variant:1,2}Siege Helmet
{variant:3}Royal Burgonet
League: Breach
Source: Drops in Xoph Breach or from unique{Xoph, Dark Embers}
Upgrade: Upgrades to unique{The Formless Inferno} using currency{Blessing of Xoph}
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
Requires Level 48, 101 Str
{variant:1,2}+(100-120) to Armour
{variant:3}(80-120)% increased Armour
{variant:1,2}+(40-50) to maximum Life
{variant:3}-30% to Fire Resistance
{variant:1,2}-20 Fire Damage taken from Hits
{variant:3}-(200-100) Fire Damage taken from Hits
{variant:1,2,3}Armour is increased by Overcapped Fire Resistance
]],[[
The Formless Inferno
Royal Burgonet
League: Breach
Source: Upgraded from unique{The Formless Flame} using currency{Blessing of Xoph}
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
Requires Level 65, 148 Str
{variant:3}Socketed Gems are Supported by Level 30 Infernal Legion
{variant:1,2}(80-120)% increased Armour
{variant:1,2}+(40-50) to maximum Life
{variant:3}+(60-100) to maximum Life
-30% to Fire Resistance
{variant:1,2}8% of Physical Damage from Hits taken as Fire Damage
{variant:1,2}Armour is increased by Overcapped Fire Resistance
{variant:3}Minion Life is increased by their Overcapped Fire Resistance
]],[[
Echoes of Creation
Shaper Item
Royal Burgonet
Source: Drops from unique{The Shaper} (Uber)
Requires Level 65, 148 Str
Socketed Warcry Skills have +1 Cooldown Use
(80-120)% increased Armour
+(50-70) to maximum Life
When you Attack, take (15-20)% of Life as Physical Damage for
each Warcry Exerting the Attack
Skills deal (10-15)% more Damage for each Warcry Exerting them
]],[[
Hrimnor's Resolve
Samnite Helmet
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Current
Requires Level 55, 114 Str
{variant:1}(10-30)% increased Fire Damage
{variant:2,3}(30-40)% increased Fire Damage
{variant:1}(40-60)% increased Armour
{variant:2,3}(100-120)% increased Armour
{variant:2,3}10% increased Stun and Block Recovery
{variant:3}+(50-70) to maximum Life
+30% to Cold Resistance
{variant:1,2}50% chance to Avoid being Chilled
{variant:1,2}50% chance to Avoid being Frozen
{variant:3}100% chance to Avoid being Chilled or Frozen if you have used a Fire Skill Recently
]],[[
Kaom's Command
Siege Helmet
League: Settlers of Kalguur
Requires Level 48, 101 Str
+(60-80) to maximum Life
(25-35)% increased Warcry Speed
Nearby corpses Explode when you Warcry, dealing (5-10)% of their Life as Physical Damage
Warcry Skills have (25-35)% increased Area of Effect
]],[[
Usurper's Penance
Eternal Burgonet
League: Expedition
Requires Level 69, 138 Str
(50-80)% increased Armour
Attacks have 15% chance to cause Bleeding
50% reduced Light Radius
+4% to Damage over Time Multiplier for Bleeding per Frenzy Charge
Bleeding you inflict deals Damage 4% faster per Frenzy Charge
(20-30)% chance to gain a Frenzy Charge on Critical Strike at Close Range
]],[[
Thrillsteel
Barbute Helmet
Onslaught
]],[[
Blood Price
Reaver Helmet
24% reduced maximum Life
Regenerate (200-250) Life per second
100% increased Stun and Block Recovery
Nearby Enemy Monsters have at least 8% of Life Reserved
]],[[
Howlcrack
Ezomyte Burgonet
Source: Drops from unique{Mercenary} after winning a duel
League: Mercenaries of Trarthus
Requires Level 60, 138 Str
+(30-40) to Strength
(100-160)% increased Armour
Non-Instant Warcries ignore their Cooldown when Used
Warcries Cost +15% of Life
Warcry Skills have (15-25)% increased Area of Effect
]],
[[
Refuge in Isolation
Paladin Crown
Source: Drops from unique{Uber Incarnation of Neglect} in normal{Moment of Loneliness}
Requires Level 78, 116 Str, 116 Int
(350-650)% increased Armour
-(50-40)% to all Elemental Resistances
+(13-29)% to Chaos Resistance
(15-30)% of Elemental Damage from Hits taken as Physical Damage
Physical Damage of Enemies Hitting you is Unlucky
]],
[[
The Hallowed Monarch
Faithful Helmet
Source: Drops from unique{Uber Incarnation of Dread} in normal{Moment of Reverence}
Requires Level 73, 101 Str, 101 Int
(150-230)% increased Armour
+(25-35)% to all Elemental Resistances
50% increased Light Radius
Link Skills can target Damageable Minions
Your Linked Minions take (65-75)% less Damage
On Killing a Rare monster, a random Linked Minion gains its Modifiers for 60 seconds
]],
-- Helmet: Evasion
[[
Alpha's Howl
Sinner Tricorne
Requires Level 64, 138 Dex
+2 to Level of Socketed Aura Gems
(80-100)% increased Evasion Rating
+(20-30)% to Cold Resistance
Cannot be Frozen
25% chance to Avoid being Chilled
16% increased Mana Reservation Efficiency of Skills
]],[[
Replica Alpha's Howl
Sinner Tricorne
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 64, 138 Dex
+4 to Level of Socketed Herald Gems
(80-100)% increased Evasion Rating
+(20-30)% to Chaos Resistance
25% chance to Avoid being Poisoned
16% increased Mana Reservation Efficiency of Skills
You cannot be Hindered
]],[[
Assailum
Sinner Tricorne
Variant: Pre 3.21.0
Variant: Current
Requires Level 64, 138 Dex
Implicits: 0
{variant:1}Grants Level 20 Snipe Skill
{variant:2}Grants Level 30 Snipe Skill
Socketed Non-Channelling Bow Skills are Triggered by Snipe
Socketed Triggered Bow Skills gain a 0.05 second Cooldown
+(350-500) to Accuracy Rating
+(350-500) to Evasion Rating
{variant:2}+2 to maximum Snipe Stages
+(14-20)% chance to Suppress Spell Damage while Channelling
]],[[
Fairgraves' Tricorne
Tricorne
Variant: Pre 3.19.0
Variant: Current
Requires Level 12, 27 Dex
{variant:1}Adds 6 to 12 Cold Damage to Attacks
{variant:2}Adds 15 to 25 Cold Damage to Attacks
70% increased Evasion Rating
{variant:1}+(15-30) to maximum Mana
+(20-30)% to Lightning Resistance
Cannot be Shocked
{variant:1}15% increased Stun and Block Recovery
{variant:2}You can be Touched by Tormented Spirits
]],[[
Goldrim
Leather Cap
+(30-50) to Evasion Rating
10% increased Rarity of Items found
+(30-40)% to all Elemental Resistances
Reflects 4 Physical Damage to Melee Attackers
]],[[
Heatshiver
Leather Hood
Variant: Pre 3.0.0
Variant: Pre 3.19.0
Variant: Pre 3.23.0
Variant: Current
Requires Level 20, 46 Dex
{variant:1}+1 to Level of Socketed Fire Gems
{variant:1}+1 to Level of Socketed Cold Gems
(80-100)% increased Evasion Rating
60% increased Mana Regeneration Rate
{variant:1}-(20-10)% to Fire Resistance
{variant:2,3,4}+(20-30)% to Fire Resistance
{variant:1}-(20-10)% to Cold Resistance
{variant:2,3,4}+(20-30)% to Cold Resistance
{variant:3,4}Gain 1% of Cold Damage as Extra Fire Damage per 1% Chill Effect on Enemy
{variant:3}Gain 100% of Cold Damage as Extra Fire Damage against Frozen Enemies
{variant:4}Gain 30% of Cold Damage as Extra Fire Damage against Frozen Enemies
{variant:2}(20-30)% increased Cold Damage if you have used a Fire Skill Recently
{variant:2}(20-30)% increased Fire Damage if you have used a Cold Skill Recently
]],[[
Replica Heatshiver
Leather Hood
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
(80-100)% increased Evasion Rating
60% increased Mana Regeneration Rate
+(20-30)% to Cold Resistance
+(20-30)% to Lightning Resistance
Gain 1% of Lightning Damage as Extra Cold Damage per 2% Shock Effect on Enemy
]],[[
Frostferno
Leather Hood
Source: No longer obtainable
Requires Level 60, 46 Dex
+2 to Level of Socketed Fire Gems
+2 to Level of Socketed Cold Gems
Socketed Gems are Supported by Level 30 Cold to Fire
(450-500)% increased Evasion Rating
60% increased Mana Regeneration Rate
+(20-30)% to Fire and Cold Resistances
]],[[
Obscurantis
Lion Pelt
Variant: Pre 3.5.0
Variant: Current
Requires Level 70, 150 Dex
{variant:1}+(300-500) to Accuracy Rating
{variant:2}+(800-1000) to Accuracy Rating
(100-120)% increased Evasion Rating
+(50-80) to maximum Life
1% increased Projectile Attack Damage per 200 Accuracy Rating
]],[[
Elevore
Wolf Pelt
+(20-25)% chance to Suppress Spell Damage
(60-100)% increased Evasion Rating
(20-25)% chance to Avoid Elemental Ailments
Recover (100-200) Life when you Suppress Spell Damage
]],[[
Rat's Nest
Ursine Pelt
Requires Level 55, 114 Dex
15% increased Attack Speed
(60-75)% increased Global Critical Strike Chance
150% increased Evasion Rating
(20-25)% increased Rarity of Items found
10% increased Movement Speed
10% reduced Character Size
]],[[
Saqawal's Flock
Silken Hood
League: Bestiary
Source: Drops from unique{Saqawal, First of the Sky}
Requires Level 60, 138 Dex
Trigger Level 20 Twister when you gain Avian's Might or Avian's Flight
(60-80)% increased Evasion Rating
+(40-60) to maximum Life
+(30-40)% to Lightning Resistance
(10-15)% increased Movement Speed
]],[[
Starkonja's Head
Silken Hood
Variant: Pre 2.6.0
Variant: Current
Requires Level 60, 138 Dex
{variant:1}+(30-50) to Dexterity
{variant:2}+(50-70) to Dexterity
50% reduced Damage when on Low Life
10% increased Attack Speed
25% increased Global Critical Strike Chance
{variant:2}(100-130)% increased Evasion Rating
+(80-100) to maximum Life
{variant:1}50% increased Global Evasion Rating when on Low Life
{variant:2}150% increased Global Evasion Rating when on Low Life
]],
-- Helmet: Energy Shield
[[
Asenath's Mark
Iron Circlet
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 8, 23 Int
{variant:3}Trigger a Socketed Spell when you Attack with a Bow, with a 0.3 second Cooldown
{variant:3}(30-60)% increased Spell Damage
(10-15)% increased Attack Speed
{variant:1,2}(10-15)% increased Cast Speed
{variant:2,3}+(30-50) to maximum Energy Shield
{variant:2,3}(10-15)% increased Stun and Block Recovery
{variant:1}50% increased Energy Shield
30% increased Mana Regeneration Rate
{variant:1,2}5% increased Movement Speed
]],[[
Asenath's Chant
Iron Circlet
Source: No longer obtainable
Variant: Pre 3.9.0
Variant: Current
Requires Level 45, 23 Int
{variant:1}25% chance to Trigger a Socketed Spell when you Attack with a Bow, with a 0.3 second Cooldown
{variant:2}Trigger a Socketed Spell when you Attack with a Bow, with a 0.3 second Cooldown
(10-15)% increased Attack Speed
(10-15)% increased Cast Speed
+(100-120) to maximum Energy Shield
30% increased Mana Regeneration Rate
5% increased Movement Speed
(30-40)% increased Stun and Block Recovery
]],[[
Cowl of the Ceraunophile
Solaris Circlet
Requires Level 59, 122 Int
League: Blight
Source: Drops in Blighted Maps
Can have a second Enchantment Modifier
+(20-30) to all Attributes
(60-80)% increased Energy Shield
(50-55)% reduced Fire Resistance
(50-55)% reduced Cold Resistance
Lightning Resistance is 75%
This item can be anointed by Cassia
]],[[
Cowl of the Cryophile
Silken Hood
Requires Level 60, 138 Dex
League: Blight
Source: Drops in Blighted Maps
Can have a second Enchantment Modifier
+(20-30) to all Attributes
(60-80)% increased Evasion Rating
(50-55)% reduced Fire Resistance
Cold Resistance is 75%
(50-55)% reduced Lightning Resistance
This item can be anointed by Cassia
]],[[
Cowl of the Thermophile
Ezomyte Burgonet
Requires Level 60, 138 Str
League: Blight
Source: Drops in Blighted Maps
Can have a second Enchantment Modifier
+(20-30) to all Attributes
(60-80)% increased Armour
Fire Resistance is 75%
(50-55)% reduced Cold Resistance
(50-55)% reduced Lightning Resistance
This item can be anointed by Cassia
]],[[
Chitus' Apex
Necromancer Circlet
Requires Level 54, 112 Int
+(20-30) to Strength
+(20-30) to maximum Mana
5% increased Experience gain
+10% to all Elemental Resistances
(10-20)% increased Elemental Damage
]],[[
Crown of Eyes
Hubris Circlet
Variant: Pre 3.7.0
Variant: Current
Requires Level 69, 154 Int
{variant:1}+(200-250) to Accuracy Rating
{variant:2}+(300-350) to Accuracy Rating
(120-150)% increased Energy Shield
-30% to Fire Resistance
(0.4-0.8)% of Attack Damage Leeched as Life
(0.2-0.4)% of Attack Damage Leeched as Mana
Attacks have 150% Arcane Might
]],[[
Crown of Thorns
Vine Circlet
Variant: Pre 1.2.0
Variant: Pre 3.19.0
Variant: Current
{variant:1}+(12-24) to maximum Energy Shield
{variant:2}+(60-80) to maximum Energy Shield
{variant:3}+(150-225) to maximum Energy Shield
Reflects 5 Physical Damage to Melee Attackers
{variant:1,2}+5 Physical Damage taken from Attack Hits
{variant:3}+25 Physical Damage taken from Attack Hits
Pain Attunement
]],[[
Martyr's Crown
Vine Circlet
Source: No longer obtainable
Variant: Pre 3.0.0
Variant: Current
Requires Level 52
{variant:1}+(260-300) to maximum Energy Shield
{variant:2}+(170-210) to maximum Energy Shield
Reflects 5 Physical Damage to Melee Attackers
+5 Physical Damage taken from Attack Hits
Pain Attunement
]],[[
The Devouring Diadem
Necromancer Circlet
League: Betrayal
Source: Drops from unique{Catarina, Master of Undeath}
Requires Level 54, 112 Int
Variant: Strength and Quality Pre 3.16.0
Variant: Dexterity and Quality Pre 3.16.0
Variant: Intelligence and Quality Pre 3.16.0
Variant: Fire and Chaos Resistances Pre 3.16.0
Variant: Cold and Chaos Resistances Pre 3.16.0
Variant: Lightning and Chaos Resistances Pre 3.16.0
Variant: Strength and Dexterity Pre 3.16.0
Variant: Dexterity and Intelligence Pre 3.16.0
Variant: Strength and Intelligence Pre 3.16.0
Variant: Mine Laying Speed Pre 3.16.0
Variant: Focus Spell Trigger Pre 3.16.0
Variant: Focus Ailment Duration Pre 3.16.0
Variant: Avoid Elemental Damage Pre 3.16.0
Variant: Focus Ailment Duration Pre 3.19.0
Variant: Focus Ailment Duration Pre 3.22.0
Variant: Fire and Chaos Resistances Pre 3.26.0
Variant: Cold and Chaos Resistances Pre 3.26.0
Variant: Lightning and Chaos Resistances Pre 3.26.0
Variant: Strength and Dexterity Pre 3.26.0
Variant: Dexterity and Intelligence Pre 3.26.0
Variant: Strength and Intelligence Pre 3.26.0
Variant: Mine Laying Speed Pre 3.26.0
Variant: Focus Spell Trigger Pre 3.26.0
Variant: Focus Ailment Duration Pre 3.26.0
Variant: Avoid Elemental Damage Pre 3.26.0
Variant: Additional Minions + Minion Life
Variant: +2 AoE Gems + inc AoE
Variant: +2 Proj Gems + Pierce
Variant: +2 Melee Gems + Strike Range
Variant: Life + Mana Regen
Variant: Mana + Life Regen
Variant: Inc Evasion while Focused
Variant: Physical Damage Reduction while Focused
Variant: +2 Gems
Variant: Inc Corpse Life
Variant: Attack/Cast Speed if consumed corpse
Variant: Take no Crit Damage if Recharge
Variant: Damage if consumed corpse
{variant:1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}+1 to Level of Socketed Gems
{variant:34}+2 to Level of Socketed Gems
{variant:29}+2 to Level of Socketed Melee Gems
{variant:1,2,3,4,5,6,7,8,9,10,11,12,13}Socketed Gems have 40% reduced Reservation Efficiency
{variant:14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38}Socketed Gems have 25% increased Reservation Efficiency
Trigger Level 15 Feast of Flesh every 5 seconds
{variant:1}+(10-25) to Strength
{variant:2}+(10-25) to Dexterity
{variant:3}+(10-25) to Intelligence
{variant:7}+(6-17) to Strength and Dexterity
{variant:19}+(31-35) to Strength and Dexterity
{variant:9}+(6-17) to Strength and Intelligence
{variant:21}+(31-35) to Strength and Intelligence
{variant:8}+(6-17) to Dexterity and Intelligence
{variant:20}+(31-35) to Dexterity and Intelligence
(180-220)% increased Energy Shield
{variant:30}+(55-60) to maximum Life
{variant:31}Regenerate 33.3 Life per second
{variant:31}+(55-60) to maximum Mana
{variant:26}Minions have (8-10)% increased maximum Life
{variant:28}Projectiles Pierce an additional Target
{variant:27}(8-10)% increased Area of Effect
{variant:26}+1 to maximum number of Raised Zombies
{variant:26}+1 to maximum number of Spectres
{variant:26}+1 to maximum number of Skeletons
{variant:29}+0.2 metres to Melee Strike Range
10% chance for Energy Shield Recharge to start when you use a Skill
{variant:4}+(8-15)% to Fire and Chaos Resistances
{variant:16}+(16-20)% to Fire and Chaos Resistances
{variant:23}Focus has (5-8)% increased Cooldown Recovery Rate
{variant:26}+1 to maximum number of Skeletons
Eldritch Battery
{variant:1,2,3}{crafted}+(7-18)% to Quality
{variant:5}{crafted}+(8-15)% to Cold and Chaos Resistances
{variant:6}{crafted}+(8-15)% to Lightning and Chaos Resistances
{variant:10}{crafted}(7-12)% increased Mine Laying Speed
{variant:11}{crafted}Trigger Socketed Spells when you Focus
{variant:12}{crafted}(81-140)% increased Duration of Ailments you inflict while Focused
{variant:13}{crafted}(6-9)% chance to Avoid Elemental Damage from Hits during Soul Gain Prevention
{variant:14}(161-180)% increased Duration of Ailments you inflict while Focused
{variant:15}(81-90)% increased Duration of Ailments you inflict while Focused
{variant:17}+(16-20)% to Cold and Chaos Resistances
{variant:18}+(16-20)% to Lightning and Chaos Resistances
{variant:22}(14-16)% increased Mine Laying Speed
{variant:23}Trigger Socketed Spells when you Focus, with a 0.25 second Cooldown
{variant:24}(36-40)% increased Duration of Ailments you inflict while Focused
{variant:25}(10-12)% chance to Avoid Elemental Damage from Hits during Soul Gain Prevention
{variant:27}+2 to Level of Socketed AoE Gems
{variant:28}+2 to Level of Socketed Projectile Gems
{variant:30}Regenerate 5.3 Mana per second
{variant:32}(30-32)% increased Evasion Rating while Focused
{variant:33}(13-15)% additional Physical Damage Reduction while Focused
{variant:35}Corpses you Spawn have 20% increased Maximum Life
{variant:36}20% increased Attack and Cast Speed if you've Consumed a Corpse Recently
{variant:37}Take no Extra Damage from Critical Strikes if Energy Shield Recharge started Recently
{variant:38}20% increased Damage if you have Consumed a corpse Recently
]],[[
Wilma's Requital
Solaris Circlet
+(300-500) to Accuracy Rating
(200-250)% increased Energy Shield
(20-30)% increased Elemental Damage with Attack Skills
Increases and Reductions to Cast Speed apply to Attack Speed
Ancestral Bond
]],[[
Doedre's Scorn
Lunaris Circlet
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 39, 83 Int
{variant:1}+1 to Level of Socketed Curse Gems
{variant:2,3}+2 to Level of Socketed Curse Gems
+(20-30) to Intelligence
{variant:2,3}+(100-120) to maximum Energy Shield
{variant:1,2}20% increased Elemental Damage
{variant:1,2}(10-20)% increased Damage with Hits and Ailments per Curse on Enemy
Curse Skills have (30-50)% increased Skill Effect Duration
{variant:3}Adds 37 to 71 Chaos Damage for each Curse on the Enemy
]],[[
Eber's Unification
Hubris Circlet
Requires Level 69, 154 Int
Implicits: 0
Trigger Level 10 Void Gaze when you use a Skill
(120-150)% increased Energy Shield
+(50-80) to maximum Mana
50% increased Stun and Block Recovery
Gain (5-8)% of Elemental Damage as Extra Chaos Damage
]],[[
Fenumus' Toxins
Necromancer Circlet
League: Bestiary
Source: Drops from unique{Fenumus, First of the Night}
Requires Level 65, 112 Int
Adds (16-21) to (31-36) Chaos Damage to Spells
(220-250)% increased Energy Shield
10% chance to gain a Power Charge on hitting an Enemy affected by a Spider's Web
(6-10)% chance to Poison per Power Charge
(15-20)% increased Damage with Poison per Power Charge
Aspect of the Spider inflicts Spider's Webs and Hinder every 0.5 Seconds instead
]],[[
Sandstorm Visage
Necromancer Circlet
League: Sanctum
Source: Drops from unique{Lycia, Herald of the Scourge} in normal{The Beyond}
(8-10)% increased Cast Speed
(200-250)% increased Energy Shield
Ignore Stuns while Casting
Base Spell Critical Strike Chance of Spells is equal to that of Main Hand Weapon
Cannot deal Critical Strikes with Attacks
]],[[
Flamesight
Solaris Circlet
Variant: Pre 3.19.0
Variant: Current
Requires Level 59, 122 Int
(240-280)% increased Energy Shield
+(30-40)% to Fire Resistance
(30-40)% increased Elemental Damage
{variant:1}25% chance to Scorch Enemies
{variant:1}Cannot inflict Ignite
{variant:2}(25-50)% chance to Scorch Enemies
{variant:2}Cannot inflict Ignite
{variant:1}10% increased Elemental Damage per Sextant affecting the area
]],[[
Galesight
Solaris Circlet
Variant: Pre 3.19.0
Variant: Current
Requires Level 59, 122 Int
(240-280)% increased Energy Shield
+(30-40)% to Cold Resistance
(30-40)% increased Elemental Damage
{variant:1}25% chance to inflict Brittle
{variant:1}Cannot inflict Freeze or Chill
{variant:2}(25-50)% chance to inflict Brittle
{variant:2}Cannot inflict Freeze or Chill
{variant:1}10% increased Elemental Damage per Sextant affecting the area
]],[[
Hale Negator
Mind Cage
League: Delve
Source: Drops from unique{Kurgal, the Blackblooded}
Variant: One Abyssal Socket
Variant: Two Abyssal Sockets
Requires Level 65, 138 Int
{variant:1}Has 1 Abyssal Socket
{variant:2}Has 2 Abyssal Sockets
(6-8)% increased maximum Life
+1 to Maximum Spirit Charges per Abyss Jewel affecting you
Gain a Spirit Charge every second
You lose all Spirit Charges when taking a Savage Hit
Recover (2-3)% of Life when you lose a Spirit Charge
Recover (2-3)% of Energy Shield when you lose a Spirit Charge
]],[[
Indigon
Hubris Circlet
Shaper Item
Elder Item
Source: Drops from unique{The Elder} (Uber)
Variant: Pre 3.5.0
Variant: Current
Requires Level 69, 154 Int
(150-180)% increased Energy Shield
(6-10)% increased maximum Mana
Recover (8-10)% of Life when you use a Mana Flask
Non-instant Mana Recovery from Flasks is also Recovered as Life
(50-60)% increased Cost of Skills for each 200 total Mana Spent Recently
{variant:1}(50-60)% increased Spell Damage for each 200 total Mana you have Spent Recently, up to 2000%
{variant:2}(20-25)% increased Spell Damage for each 200 total Mana you have Spent Recently, up to 2000%
]],[[
Mark of the Red Covenant
Tribal Circlet
Variant: Pre 3.11.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 26, 58 Int
+(30-50) to maximum Energy Shield
(10-15)% increased Stun and Block Recovery
{variant:1}Minions have (10-15)% increased Movement Speed
{variant:2}Minions have (25-45)% increased Movement Speed
{variant:2}Summoned Raging Spirits deal (130-150)% increased Damage
{variant:3}Summoned Raging Spirits deal (175-250)% increased Damage
75% reduced Maximum number of Summoned Raging Spirits
Summoned Raging Spirits' Hits always Ignite
{variant:1}Summoned Raging Spirits refresh their Duration when they Kill an Ignited Enemy
{variant:2,3}Summoned Raging Spirits' Melee Strikes deal Fire-only Splash
{variant:2,3}Damage to Surrounding Targets
]],[[
Maw of Conquest
Steel Circlet
League: Legion
Requires Level 48, 101 Int
(60-80)% increased Critical Strike Chance for Spells
(200-250)% increased Energy Shield
+(50-70) to maximum Life
Unaffected by Poison
(10-20)% of Damage taken Recouped as Life
]],[[
Plume of Pursuit
Bone Circlet
League: Harvest
Source: Drops from unique{Janaar, the Omen} in normal{The Sacred Grove}
Requires Level 64, 73 Int
(30-20)% reduced Cast Speed
(80-130)% increased Energy Shield
Non-critical strikes deal 80% less Damage
Spell Skills always deal Critical Strikes on final Repeat
Spell Skills cannot deal Critical Strikes except on final Repeat
]],[[
Rime Gaze
Mind Cage
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.5.0
Variant: Pre 3.16.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 65, 138 Int
{variant:1,2}Socketed Gems are Supported by Level 15 Concentrated Effect
{variant:3,4,5,6}Socketed Gems are Supported by Level 20 Concentrated Effect
{variant:4,5}+(16-22)% to Cold Damage over Time Multiplier
{variant:6}+50% to Cold Damage over Time Multiplier
{variant:1}10% increased Cold Damage
{variant:2,3,4,5}30% increased Cold Damage
{variant:1,2}(100-120)% increased Energy Shield
{variant:3,4}(180-200)% increased Energy Shield
{variant:5}(140-160)% increased Energy Shield
{variant:6}50% increased Energy Shield
50% reduced Energy Shield Recharge Rate
{variant:1,2,3,4,5}+(40-60) to maximum Mana
{variant:6}+(25-75) to maximum Mana
]],[[
Scold's Bridle
Mind Cage
League: Torment
Requires Level 65, 138 Int
(80-100)% increased Spell Damage
15% reduced Cast Speed
+(30-60) to maximum Mana
Your Skills deal you 400% of Mana Spent on Upfront Skill Mana Costs as Physical Damage
]],[[
Sudden Dawn
Steel Circlet
Source: Drops from unique{The Black Star}
Requires Level 48, 101 Int
(300-350)% increased Energy Shield
+(50-70) to maximum Mana
(10-20)% chance for Energy Shield Recharge to start when you Kill an Enemy
(30-40)% less Energy Shield Recharge Rate
]],[[
Thundersight
Solaris Circlet
Variant: Pre 3.19.0
Variant: Current
Requires Level 59, 122 Int
(240-280)% increased Energy Shield
+(30-40)% to Lightning Resistance
(30-40)% increased Elemental Damage
{variant:1}25% chance to Sap Enemies
{variant:1}Cannot inflict Shock
{variant:2}(25-50)% chance to Sap Enemies
{variant:2}Cannot inflict Shock
{variant:1}10% increased Elemental Damage per Sextant affecting the area
]],[[
Wraithlord
Bone Circlet
Variant: Pre 3.19.0
Variant: Pre 3.24.0
Variant: Current
Requires Level: 34, 73 Int
{variant:3}Has 4 Abyssal Sockets
{variant:1,2}+2 to Level of Socketed Minion Gems
(120-150)% increased Energy Shield
{variant:3}+(1-2) to Level of all Minion Skill Gems
{variant:2}+2 to maximum number of Spectres
{variant:1}Minions Regenerate 1% of Life per second
{variant:3}+1 to maximum number of Raised Spectres per Socketed Ghastly Eye Jewel
{variant:1}+1000 to Spectre maximum Life
{variant:2,3}You cannot have Non-Spectre Minions
]],[[
Wreath of Phrecia
Iron Circlet
League: Legion
Requires Level 8
Has no Attribute Requirements
Increases and Reductions to Light Radius also apply to Area of Effect at 50% of their value
Increases and Reductions to Light Radius also apply to Damage
(15-25)% increased Light Radius
Deal no Chaos Damage
]],[[
Ylfeban's Trickery
Hubris Circlet
League: Tempest
Variant: Pre 2.6.0
Variant: Pre 3.20.0
Variant: Current
Requires Level 69, 154 Int
{variant:2,3}Trigger Level 10 Shock Ground when Hit
Adds 1 to (60-80) Lightning Damage to Spells and Attacks
(130-170)% increased Energy Shield
+(25-35)% to Lightning Resistance
{variant:1}5% chance to create Shocked Ground when Hit
{variant:1}10% chance to Curse non-Cursed Enemies with a random Hex on Hit
{variant:2}20% chance to Curse non-Cursed Enemies with a random Hex on Hit
{variant:3}Curse Enemies which Hit you with a random Hex, ignoring Curse Limit
]],[[
The Dark Monarch
Lich's Circlet
Variant: Animated Weapons
Variant: Summoned Golems
Variant: Summoned Raging Spirits
Variant: Raised Spectres
Variant: Raised Spiders
Variant: Raised Zombies
Variant: Summoned Reapers
Variant: Sentinels of Absolution
Variant: Sentinels of Dominance
Variant: Sentinels of Purity
Variant: Summoned Holy Relics
Variant: Summoned Phantasms
Variant: Summoned Skeletons
Variant: Summoned Spectral Wolves
Variant: Living Lightning
Variant: Holy Armaments
Source: Drops from unique{Incarnation of Dread} in normal{Moment of Reverence}
Requires Level 80, 224 Int
+(50-100) to maximum Energy Shield
+1 to Level of all Minion Skill Gems
+(27-37)% to Chaos Resistance
50% reduced Light Radius
{variant:1}Maximum number of Animated Weapons is Doubled
{variant:1}Cannot have Minions other than Animated Weapons
{variant:2}Maximum number of Summoned Golems is Doubled
{variant:2}Cannot have Minions other than Summoned Golems
{variant:3}Maximum number of Summoned Raging Spirits is Doubled
{variant:3}Cannot have Minions other than Summoned Raging Spirits
{variant:4}Maximum number of Raised Spectres is Doubled
{variant:4}Cannot have Minions other than Raised Spectres
{variant:5}Maximum number of Raised Spiders is Doubled
{variant:5}Cannot have Minions other than Raised Spiders
{variant:6}Maximum number of Raised Zombies is Doubled
{variant:6}Cannot have Minions other than Raised Zombies
{variant:7}Maximum number of Summoned Reapers is Doubled
{variant:7}Cannot have Minions other than Summoned Reapers
{variant:8}Maximum number of Sentinels of Absolution is Doubled
{variant:8}Cannot have Minions other than Sentinels of Absolution
{variant:9}Maximum number of Sentinels of Dominance is Doubled
{variant:9}Cannot have Minions other than Sentinels of Dominance
{variant:10}Maximum number of Sentinels of Purity is Doubled
{variant:10}Cannot have Minions other than Sentinels of Purity
{variant:11}Maximum number of Summoned Holy Relics is Doubled
{variant:11}Cannot have Minions other than Summoned Holy Relics
{variant:12}Maximum number of Summoned Phantasms is Doubled
{variant:12}Cannot have Minions other than Summoned Phantasms
{variant:13}Maximum number of Summoned Skeletons is Doubled
{variant:13}Cannot have Minions other than Summoned Skeletons
{variant:14}Maximum number of Summoned Spectral Wolves is Doubled
{variant:14}Cannot have Minions other than Summoned Spectral Wolves
{variant:15}Maximum number of Living Lightning is Doubled
{variant:15}Cannot have Minions other than Living Lightning
{variant:15}Maximum number of Holy Armaments is Doubled
{variant:15}Cannot have Minions other than Holy Armaments
]],
-- Helmet: Armour/Evasion
[[
Black Sun Crest
Lacquered Helmet
Requires Level 51, 57 Str, 57 Dex
+1 to Level of Socketed Gems
(5-15)% increased Strength
(5-15)% increased Dexterity
(5-15)% increased Intelligence
(100-150)% increased Armour
40% reduced Light Radius
]],[[
The Bringer of Rain
Nightmare Bascinet
Variant: Pre 1.1.0
Variant: Pre 1.3.0
Variant: Pre 3.5.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 67, 62 Str, 85 Dex
{variant:1,2,3,4}Socketed Gems are Supported by Level 18 Melee Physical Damage
{variant:5}Socketed Gems are Supported by Level 30 Melee Physical Damage
{variant:1,4}Socketed Gems are Supported by Level 18 Faster Attacks
{variant:5}Socketed Gems are Supported by Level 30 Faster Attacks
{variant:2,3}Socketed Gems are Supported by Level 12 Faster Attacks
{variant:1,4}Socketed Gems are supported by Level 18 Blind
{variant:5}Socketed Gems are supported by Level 30 Blind
{variant:2,3}Socketed Gems are supported by Level 6 Blind
{variant:1,2}15% Chance to Block Attack Damage
{variant:3,4,5}6% Chance to Block Attack Damage
Adds 20 to 30 Physical Damage to Attacks
(200-300)% increased Armour and Evasion
{variant:1,4}+(200-220) to maximum Life
{variant:5}+(200-300) to maximum Life
{variant:2,3}+(120-160) to maximum Life
{variant:1,2}10% chance to gain an Endurance Charge when you Block
{variant:3,4,5}20% chance to gain an Endurance Charge when you Block
Can't use Chest armour
Extra gore
]],[[
Crest of Desire
Fluted Bascinet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 58, 64 Str, 64 Dex
Has 1 Socket
+(5-8) to Level of Socketed Gems
+(30-50)% to Quality of Socketed Gems
Socketed Skills deal Double Damage
(100-150)% increased Armour and Evasion
]],[[
Deidbell
Gilded Sallet
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 33, 38 Str, 38 Dex
+(20-30) to Strength
+(20-30) to Dexterity
{variant:1,2}20% increased Melee Damage
{variant:2}Adds 10 to 20 Physical Damage to Attacks
+(200-300) to Armour
Cannot Leech when on Low Life
{variant:3}Skills which Exert an Attack have (20-40)% chance to not count that Attack
]],[[
Deidbellow
Gilded Sallet
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Requires Level 33, 38 Str, 38 Dex
+(20-30) to Strength
+(20-30) to Dexterity
20% increased Melee Damage
{variant:2}Adds 10 to 20 Physical Damage to Attacks
+(200-300) to Armour
Cannot Leech when on Low Life
If you've Warcried Recently, you and nearby allies have 20% increased Attack, Cast and Movement Speed
]],[[
Devoto's Devotion
Nightmare Bascinet
Requires Level 67, 62 Str, 85 Dex
+(50-65) to Dexterity
10% reduced Global Physical Damage
16% increased Attack Speed
(150-200)% increased Armour and Evasion
+(15-25)% to Chaos Resistance
20% increased Movement Speed
Mercury Footprints
]],[[
The Devourer of Minds
Pig-Faced Bascinet
Source: Drops from unique{The Elder} (Uber Uber)
Requires Level 63, 85 Str, 62 Dex
+(30-50) to Intelligence
(80-120)% increased Armour and Evasion
+1 to Level of all Minion Skill Gems
25% increased Light Radius
Minions have the same maximum number of Endurance, Frenzy and Power Charges as you
Minions count as having the same number of
Endurance, Frenzy and Power Charges as you
]],[[
The Fledgling
Lacquered Helmet
League: Heist
Source: Drops from unique{Nashta, The Usurper} in normal{Contract: Heart of Glory}
Requires Level 51, 57 Str, 57 Dex
(150-200)% increased Armour and Evasion
(30-50)% increased Projectile Speed
(30-50)% increased Projectile Damage
Projectiles cannot collide with Enemies in Close Range
Far Shot
]],[[
The Peregrine
Visored Sallet
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.7.0
Variant: Current
Requires Level 23, 28 Str, 28 Dex
{variant:1}+100 to Accuracy Rating
{variant:2}+300 to Accuracy Rating
{variant:3}+500 to Accuracy Rating
(40-60)% increased Armour and Evasion
(20-30)% increased Rarity of Items found
+30% to Lightning Resistance
{variant:1}0.2% of Physical Attack Damage Leeched as Mana
{variant:2,3}0.4% of Attack Damage Leeched as Mana
10% increased Movement Speed
]],[[
Skullhead
Secutor Helm
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 36, 42 Str, 42 Dex
(60-80)% increased Armour and Evasion
{variant:1,2}+(50-70) to maximum Life
{variant:1,2}+(50-70) to maximum Mana
{variant:2,3}+(10-20)% to all Elemental Resistances
{variant:1,2}Minions have +10% Chance to Block Attack Damage
{variant:3}Minions have +25% Chance to Block Attack Damage
{variant:3}Minions have +25% Chance to Block Spell Damage
{variant:1,2}Minions have +(300-350) to Armour
{variant:1,2}Minions Regenerate 2% of Life per second
{variant:3}Minions Recover 10% of their Life when they Block
]],[[
El'Abin's Visage
Fencer Helm
League: Crucible
+(20-30) to Strength
+(20-30) to Dexterity
(80-120)% increased Armour and Evasion
(15-25)% increased Rarity of Items found
Has a Crucible Passive Skill Tree
Crucible Passive Skill Tree is removed if this Modifier is removed
]],[[
The Trickster's Smile
Visored Sallet
League: Affliction
Requires Level 23, 28 Str, 28 Dex
(60-100)% increased Armour and Evasion
Reflects 100 Cold Damage to Melee Attackers
Reflects 100 Fire Damage to Melee Attackers
Reflects 100 Lightning Damage to Melee Attackers
When an Enemy Hit deals Elemental Damage to you, their Resistance to those Elements becomes zero for 4 seconds
]],
-- Helmet: Armour/Energy Shield
[[
Ahn's Contempt
Praetor Crown
Requires Level 68, 62 Str, 91 Int
+(15-20) to all Attributes
(60-140)% increased Armour and Energy Shield
+(60-70) to maximum Life
-1 to Maximum Power Charges
Gain (8-12)% of Physical Damage as Extra Chaos Damage while at maximum Power Charges
You take 50% reduced Extra Damage from Critical Strikes while you have no Power Charges
]],[[
Ancient Skull
Bone Helmet
League: Ritual
Requires Level 73, 76 Str, 76 Int
Implicits: 1
Minions deal (15-20)% increased Damage
(150-200)% increased Armour and Energy Shield
Minions have (20-40)% reduced maximum Life
Minions have (15-25)% increased Movement Speed
Minions have 50% increased Critical Strike Chance per Maximum Power Charge you have
Minions can hear the whispers for 5 seconds after they deal a Critical Strike
]],[[
The Brine Crown
Prophet Crown
Variant: Pre 3.5.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 63, 85 Str, 62 Int
{variant:1}(100-120)% increased Armour and Energy Shield
{variant:2,3}(240-300)% increased Armour and Energy Shield
{variant:1}+(50-70) to maximum Life
{variant:2,3}+(80-100) to maximum Life
{variant:3}+3% to maximum Cold Resistance
{variant:1,2}+(30-50)% to Cold Resistance
Cannot be Frozen
{variant:2}5% reduced Cold Damage taken
{variant:1}+800 Armour while stationary
{variant:2,3}+1500 Armour while stationary
{variant:1,2}60% increased Mana Regeneration Rate while stationary
15% chance to create Chilled Ground when Hit with an Attack
]],[[
The Broken Crown
Prophet Crown
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Current
Requires Level 63, 85 Str, 62 Int
Socketed Gems are supported by Level 20 Cast on Death
+(10-15) to all Attributes
20% increased Damage when on Low Life
(60-100)% increased Armour and Energy Shield
{variant:1}+(20-30) to maximum Energy Shield
{variant:2}+(70-90) to maximum Energy Shield
{variant:3}+(50-70) to maximum Energy Shield
20% reduced Mana Regeneration Rate
+(43-61)% to Chaos Resistance
]],[[
Craiceann's Chitin
Magistrate Crown
Variant: Pre 3.4.0
Variant: Current
League: Bestiary
Source: Drops from unique{Craiceann, First of the Deep}
Requires Level 58, 64 Str, 64 Int
(140-180)% increased Armour and Energy Shield
(4-7)% increased maximum Life
{variant:1}+(7-9)% Chance to Block Spell Damage
{variant:2}+(4-6)% Chance to Block Spell Damage
Cannot lose Crab Barriers if you have lost Crab Barriers Recently
+3% Chance to Block Attack Damage while you have at least 5 Crab Barriers
+5% Chance to Block Attack Damage while you have at least 10 Crab Barriers
]],[[
Crown of the Inward Eye
Prophet Crown
Source: Drops from unique{Sirus, Awakener of Worlds}
Requires Level 63, 85 Str, 62 Int
333% increased Armour and Energy Shield
(9-21)% increased maximum Life, Mana and Global Energy Shield
Transfiguration of Soul
Transfiguration of Body
Transfiguration of Mind
]],[[
Crown of the Tyrant
Magistrate Crown
League: Delve
Source: Drops from unique{Aul, the Crystal King}
Variant: Pre 3.11.0
Variant: Current
Requires Level 58, 64 Str, 64 Int
Has 1 Socket
{variant:1}+(50-100) to maximum Life
{variant:2}+(50-175) to maximum Life
Nearby Enemies have -10% to all Resistances
You and Nearby Allies have 64 to 96 added Fire Damage per Red Socket
You and Nearby Allies have 56 to 88 added Cold Damage per Green Socket
You and Nearby Allies have 16 to 144 added Lightning Damage per Blue Socket
You and Nearby Allies have 47 to 61 added Chaos Damage per White Socket
]],[[
Geofri's Crest
Great Crown
Variant: Pre 3.17.0
Variant: Pre 3.19.0
Variant: Current
{variant:1,2}+1 to Level of Socketed Gems
{variant:2}(60-80)% increased Armour and Energy Shield
{variant:3}(120-150)% increased Armour and Energy Shield
{variant:1,2}+(15-20)% to Fire Resistance
{variant:3}+(20-30)% to Fire Resistance
{variant:1,2}+(15-20)% to Cold Resistance
{variant:3}+(20-30)% to Cold Resistance
{variant:1,2}+(15-20)% to Lightning Resistance
{variant:3}+(20-30)% to Lightning Resistance
+(20-30)% to Chaos Resistance
{variant:2,3}+1 to maximum number of Summoned Holy Relics
{variant:2}Summoned Holy Relics have (20-25)% reduced Cooldown Recovery Rate
]],[[
Geofri's Legacy
Great Crown
Source: No longer obtainable
+1 to Level of Socketed Gems
+(15-20)% to Fire Resistance
+(15-20)% to Cold Resistance
+(15-20)% to Lightning Resistance
+(20-30)% to Chaos Resistance
+1 to maximum number of Summoned Holy Relics
Summoned Holy Relics have (20-25)% reduced Cooldown Recovery Rate
(60-80)% increased Armour and Energy Shield
]],[[
Honourhome
Soldier Helmet
League: Legion
Variant: Pre 3.7.0
Variant: Pre 3.19.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 12, 16 Str, 16 Int
{variant:2}+(1-2) to Level of Socketed Gems
{variant:3,4}+2 to Level of Socketed Gems
{variant:1,2}Adds 1 to 13 Lightning Damage to Spells and Attacks
{variant:3,4}Adds 1 to 30 Lightning Damage to Spells and Attacks
{variant:1}(40-50)% increased Armour and Energy Shield
{variant:2,3,4}(100-150)% increased Armour and Energy Shield
{variant:2,3,4}(10-20)% increased Rarity of Items found
{variant:1}+(10-20)% to all Elemental Resistances
{variant:1}+20% to all Elemental Resistances while on Low Life
{variant:2,3}(10-20)% reduced Mana Cost of Skills
{variant:1}20% reduced Mana Cost of Skills when on Low Life
{variant:4}(30-50)% increased Mana Cost Efficiency
]],[[
Kitava's Thirst
Zealot Helmet
Variant: Pre 3.11.0
Variant: Current
Requires Level 44, 50 Str, 50 Int
{variant:1}30% chance to Trigger Socketed Spells when you Spend at least 100 Mana on an
{variant:1}Upfront Cost to Use or Trigger a Skill, with a 0.1 second Cooldown
{variant:2}50% chance to Trigger Socketed Spells when you Spend at least 100 Mana on an
{variant:2}Upfront Cost to Use or Trigger a Skill, with a 0.1 second Cooldown
15% reduced Cast Speed
(70-80)% increased Armour and Energy Shield
+(30-50) to maximum Mana
]],[[
Lightpoacher
Great Crown
League: Abyss
Source: Drops from unique{Amanamu, Liege of the Lightless} or unique{Ulaman, Sovereign of the Well}
Variant: One Abyssal Socket (Pre 3.21.0)
Variant: Two Abyssal Sockets (Pre 3.21.0)
Variant: One Abyssal Socket (Current)
Variant: Two Abyssal Sockets (Current)
{variant:1,3}Has 1 Abyssal Socket
{variant:2,4}Has 2 Abyssal Sockets
Trigger Level 20 Spirit Burst when you Use a Skill while you have a Spirit Charge
+(10-15)% to all Elemental Resistances
+1 to Maximum Spirit Charges per Abyss Jewel affecting you
{variant:1,2}(15-20)% chance to gain a Spirit Charge on Kill
{variant:3,4}Gain a Spirit Charge on Kill
{variant:1,2}Recover (4-5)% of Life when you lose a Spirit Charge
{variant:3,4}Gain 5% of Physical Damage as Extra Damage of each Element per Spirit Charge
]],[[
Malachai's Vision
Praetor Crown
Source: Use currency{Vaal Orb} on unique{Voll's Vision}
Variant: Pre 3.0.0
Variant: Pre 3.11.0
Variant: Pre 3.19.0
Variant: Current
Adds (13-17) to (29-37) Chaos Damage
{variant:1}+(200-250) to maximum Energy Shield
{variant:2,3,4}+(150-200) to maximum Energy Shield
+(32-40)% to Cold Resistance
+(15-20)% to Lightning Resistance
{variant:1,2}Regenerate 100 Energy Shield per second if all Equipped items are Corrupted
{variant:3}Regenerate 250 Energy Shield per second if all Equipped items are Corrupted
{variant:4}Regenerate 400 Energy Shield per second if all Equipped items are Corrupted
Regenerate 35 Mana per second if all Equipped Items are Corrupted
Corrupted
]],[[
Mask of the Spirit Drinker
{variant:1}Crusader Helmet
{variant:2}Magistrate Crown
Variant: Pre 3.14.0
Variant: Current
League: Incursion
Source: Opening normal{Pools Coffer} in normal{Sanctum of Immortality}
Upgrade: Upgrades to unique{Mask of the Stitched Demon} via currency{Vial of Summoning}
{variant:1}(60-80)% increased Armour and Energy Shield
{variant:2}(140-220)% increased Armour and Energy Shield
{variant:2}+(30-60) to maximum Energy Shield
{variant:1}+(30-50) to maximum Life
{variant:2}+(80-100) to maximum Life
Cannot gain Energy Shield
Regenerate 50 Life per second if you have at least 500 Maximum Energy Shield
Regenerate 100 Life per second if you have at least 1000 Maximum Energy Shield
Regenerate 150 Life per second if you have at least 1500 Maximum Energy Shield
Your Energy Shield starts at zero
]],[[
Mask of the Stitched Demon
Magistrate Crown
League: Incursion
Source: Upgraded from unique{Mask of the Spirit Drinker} via currency{Vial of Summoning}
Requires Level 58, 64 Str, 64 Int
+(40-50) to Intelligence
+(160-180) to maximum Energy Shield
Strength provides no bonus to Maximum Life
Intelligence provides no inherent bonus to Maximum Mana
+1 to Maximum Life per 2 Intelligence
Cannot gain Energy Shield
Regenerate 1% of Life per second per 500 Player Maximum Energy Shield
Your Energy Shield starts at zero
]],[[
Mask of the Tribunal
Magistrate Crown
League: Synthesis
Source: Drops from unique{Altered/Augmented/Rewritten/Twisted Synthete}
Variant: Pre 3.16.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 58, 64 Str, 64 Int
+(25-30) to all Attributes
(150-200)% increased Armour and Energy Shield
{variant:2,3}Nearby Allies have 1% Chance to Block Attack Damage per 100 Strength you have
{variant:1}Nearby Allies have (4-6)% increased Defences per 100 Strength you have
Nearby Allies have +(6-8)% to Critical Strike Multiplier per 100 Dexterity you have
Nearby Allies have (2-4)% increased Cast Speed per 100 Intelligence you have
{variant:1,2}2% increased Mana Reservation Efficiency of Skills per 250 total Attributes
{variant:3}3% increased Mana Reservation Efficiency of Skills per 250 total Attributes
]],[[
Maw of Mischief
Bone Helmet
League: Heist
Source: Obtained from divination card normal{Cursed Words}
Variant: Pre 3.29.0
Variant: Current
Requires Level 73, 76 Str, 76 Int
Implicits: 1
Minions deal (15-20)% increased Damage
Grants Level 20 Death Wish Skill
+(45-65) to maximum Life
{variant:2}(40-60)% increased Mana Cost Efficiency of Minion Skills
{variant:1}(20-30)% reduced Mana Cost of Minion Skills
Minions are Aggressive
]],[[
Memory Vault
Praetor Crown
Requires Level 68, 62 Str, 91 Int
+(130-160) to maximum Energy Shield
+(150-200) to maximum Mana
(30-40)% increased Mana Regeneration Rate
+(20-30)% to Fire Resistance
20% reduced Reservation Efficiency of Skills
1% increased Armour per 50 Reserved Mana
]],[[
Mindspiral
Aventail Helmet
Variant: Pre 3.0.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 37, 42 Str, 42 Int
{variant:1,2}(10-15)% increased Cold Damage
{variant:1,2}(10-15)% increased Lightning Damage
{variant:1}+(100-150) to maximum Mana
{variant:2,3}+(100-120) to maximum Mana
{variant:2}Gain (5-10)% of Maximum Mana as Extra Maximum Energy Shield
{variant:3}Gain (10-15)% of Maximum Mana as Extra Maximum Energy Shield
Enemies Cannot Leech Mana From you
{variant:1,2}(5-10)% of Damage taken Recouped as Mana
{variant:3}(10-20)% of Damage taken Recouped as Mana
Cannot Leech Mana
]],[[
Ravenous Passion
Zealot Helmet
Variant: Pre 3.25.0
Variant: Current
Source: Drops from unique{The Eater of Worlds} (Uber)
Requires Level: 44, 50 Str, 50 Int
+(30-50) to Strength
(80-120)% increased Armour and Energy Shield
{variant:1}Gain (10-15) Rage after Spending a total of 200 Mana
{variant:2}Gain (7-10) Rage after Spending a total of 200 Mana
Rage grants Spell Damage instead of Attack Damage
]],[[
Speaker's Wreath
Prophet Crown
Requires Level 63, 85 Str, 62 Int
+(20-40) to Dexterity
(10-15)% increased Skill Effect Duration
2% increased Minion Attack Speed per 50 Dexterity
2% increased Minion Movement Speed per 50 Dexterity
Minions' Hits can only Kill Ignited Enemies
]],[[
Subsume the Source
Faithful Helmet
League: Allflame
Source: Drops from unique{Zorath}
Requires Level 73, 101 Str, 101 Int
Crafted: true
(120-240)% increased Explicit Modifier magnitudes
Has 4 Abyssal Sockets
Socketed Rare Abyssal Jewels will be Consumed
One modifier from Consumed Jewels will be retained
Cannot have non-Abyssal sockets
]],[[
Veil of the Night
Great Helmet
Requires Level 22, 27 Str, 27 Int
(20-22)% increased Stun and Block Recovery
40% reduced Light Radius
Reflects 1 to (180-220) Lightning Damage to Attackers on Block
(18-22)% increased Global Defences
Elemental Resistances are Zero
]],[[
Replica Veil of the Night
Great Helmet
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 22, 27 Str, 27 Int
(20-22)% increased Stun and Block Recovery
40% reduced Light Radius
Reflects 1 to (180-220) Lightning Damage to Attackers on Block
Defences are Zero
(18-22)% increased Elemental Resistances
]],[[
Voll's Vision
Praetor Crown
Variant: Pre 3.19.0
Variant: Current
+(260-300) to Armour
+(26-32)% to Fire Resistance
+(8-16)% to Chaos Resistance
20% increased Light Radius
(8-12)% increased Maximum Life if no Equipped Items are Corrupted
{variant:1}Regenerate 100 Life per second if no Equipped Items are Corrupted
{variant:2}Regenerate 400 Life per second if no Equipped Items are Corrupted
]],
-- Helmet: Evasion/Energy Shield
[[
Akoya's Gaze
Regicide Mask
Requires Level 52, 58 Dex, 58 Int
+100 Strength Requirement
(20-25)% increased Warcry Speed
Life Leech from Exerted Attacks is instant
Non-Exerted Attacks deal no Damage
]],[[
Crown of the Pale King
Regicide Mask
League: Tempest
Variant: Pre 2.6.0
Variant: Pre 3.19.0
Variant: Current
Requires Level 52, 58 Dex, 58 Int
(150-200)% increased Evasion and Energy Shield
{variant:2,3}+(60-80) to maximum Life
(0.4-0.8)% of Physical Attack Damage Leeched as Life
Reflects 100 to 150 Physical Damage to Melee Attackers
{variant:1,2}30% of Damage you Reflect to Enemies when Hit is leeched as Life
{variant:3}100% of Damage you Reflect to Enemies when Hit is leeched as Life
]],[[
Curtain Call
Plague Mask
Requires Level 20
+23 to maximum Life
(10-15)% reduced Mine Throwing Speed
Mines have (40-50)% increased Detonation Speed
Skills which throw Mines throw up to 1 additional Mine if you have at least 800 Dexterity
Skills which throw Mines throw up to 1 additional Mine if you have at least 800 Intelligence
]],[[
Eye of Malice
Callous Mask
Requires Level 45, 51 Dex, 51 Int
(400-500)% increased Evasion and Energy Shield
+(20-40)% to Fire Resistance
+(20-40)% to Cold Resistance
25% chance to inflict Cold Exposure on Hit
25% chance to inflict Fire Exposure on Hit
Nearby Enemies have 50% increased Fire and Cold Resistances
]],[[
Farrul's Bite
Harlequin Mask
League: Bestiary
Source: Drops from unique{Farrul, First of the Plains}
Requires Level 57, 64 Dex, 64 Int
Grants Level 20 Aspect of the Cat Skill
(180-220)% increased Evasion and Energy Shield
+(25-35)% to Cold Resistance
+1% to Critical Strike Chance while affected by Aspect of the Cat
Critical Strikes have (10-20)% chance to Blind Enemies while you have Cat's Stealth
(40-50)% increased Damage with Hits and Ailments against Blinded Enemies
]],[[
Fractal Thoughts
Vaal Mask
League: Legion
Requires Level: 62, 79 Dex, 72 Int
(140-180)% increased Evasion and Energy Shield
+(25-40)% to Critical Strike Multiplier if Dexterity is higher than Intelligence
15% increased Dexterity if Strength is higher than Intelligence
1% increased Elemental Damage per 10 Dexterity
+2 to Maximum Life per 10 Intelligence
]],[[
Glimpse of Chaos
Vaal Mask
League: Ultimatum
Source: Drops from unique{The Trialmaster}
Requires Level 62, 79 Dex, 72 Int
Variant: Area of Effect
Implicits: 0
Variant: Blind
Variant: Mana Cost + Reservation
Variant: Curse Effect
Variant: Skill Effect Duration
Variant: Crushed
Variant: +2 Gems
Variant: Minimum Charges
Variant: Cooldown Recovery
Variant: Aura Effect
Variant: Additional Projectile
Variant: Malediction
Variant: Quantity
Can be modified while Corrupted
Can have up to 5 Implicit Modifiers while Item has this Modifier
{variant:7}+2 to Level of Socketed Gems
{variant:3}Socketed Skill Gems get a 80% Cost & Reservation Multiplier
(30-40)% increased maximum Life and reduced Fire Resistance
(30-40)% increased maximum Mana and reduced Cold Resistance
(30-40)% increased Global maximum Energy Shield and reduced Lightning Resistance
{variant:13}(5-7)% increased Quantity of Items found
{variant:11}Skills fire an additional Projectile
{variant:1}(15-25)% increased Area of Effect
{variant:5}(15-25)% increased Skill Effect Duration
{variant:4}(10-15)% increased Effect of your Curses
{variant:2}Nearby Enemies are Blinded
{variant:6}Nearby Enemies are Crushed
{variant:12}Nearby Enemies have Malediction
{variant:10}(10-15)% increased effect of Non-Curse Auras from your Skills
{variant:9}(8-12)% increased Cooldown Recovery Rate
{variant:8}+1 to Minimum Endurance, Frenzy and Power Charges
Chaos Resistance is Zero
Corrupted
]],[[
Gorgon's Gaze
Regicide Mask
Requires Level 52, 58 Dex, 58 Int
Implicits: 0
Grants Level 20 Summon Petrification Statue Skill
(200-250)% increased Energy Shield
+(60-80) to maximum Life
(5-10)% increased Attack and Cast Speed
5% additional Physical Damage Reduction while moving
5% reduced Elemental Damage taken while stationary
]],[[
The Gull
Raven Mask
League: Domination
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 38, 44 Dex, 44 Int
{variant:2,3,4}Trigger Level 1 Create Lesser Shrine when you Kill an Enemy
(120-150)% increased Evasion and Energy Shield
{variant:2}+(40-65) to maximum Energy Shield
{variant:3,4}+(30-45) to maximum Energy Shield
{variant:2,3,4}+(60-80) to maximum Life
{variant:1}+(30-40) to maximum Mana
{variant:2,3,4}+(30-40)% to Cold Resistance
{variant:1}Gain (15-20) Life per Enemy Killed
{variant:1}Gain (10-15) Energy Shield per Enemy Killed
{variant:1,2,3}75% increased Effect of Shrine Buffs on you
{variant:4}(25-50)% increased Effect of Shrine Buffs on you
{variant:1,2,3}50% increased Duration of Shrine Effects on you
{variant:4}(25-50)% increased Duration of Shrine Effects on you
]],[[
Heretic's Veil
Deicide Mask
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Pre 3.20.0
Variant: Current
Requires Level 67, 73 Dex, 88 Int
{variant:1,4}+2 to Level of Socketed Curse Gems
{variant:2,3}+1 to Level of Socketed Curse Gems
Socketed Gems are Supported by Level 22 Blasphemy
Socketed Curse Gems have 30% increased Reservation Efficiency
{variant:1,2}(130-150)% increased Evasion and Energy Shield
{variant:3,4}(90-110)% increased Evasion and Energy Shield
+(40-50) to maximum Energy Shield
]],[[
Leer Cast
Festival Mask
Variant: Pre 3.19.0
Variant: Current
+(20-30) to Dexterity
{variant:1}30% reduced Damage
{variant:2}25% reduced Damage
{variant:1}+(20-30) to maximum Life
{variant:2}+(60-100) to maximum Life
{variant:1}+(20-30) to maximum Mana
{variant:2}+(60-100) to maximum Mana
{variant:1}You and nearby allies gain 15% increased Damage
{variant:2}You and nearby allies gain 50% increased Damage
]],[[
Replica Leer Cast
Festival Mask
Variant: Pre 3.19.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
+(20-30) to Dexterity
{variant:1}+(20-30) to maximum Life
{variant:2}+(60-100) to maximum Life
{variant:1}+(20-30) to maximum Mana
{variant:2}+(60-100) to maximum Mana
60% reduced Mana Regeneration Rate
You and nearby Allies have 30% increased Mana Regeneration Rate
]],[[
Malachai's Simula
Iron Mask
Variant: Pre 1.0.0
Variant: Pre 2.0.0
Variant: Pre 3.7.0
Variant: Pre 3.17.0
Variant: Pre 3.19.0
Variant: Current
+20 to Strength
{variant:1,2,3,4,5}(15-30)% increased Spell Damage
{variant:1,2,3,4,5}(20-30)% increased Lightning Damage
{variant:1,2,3,4,5}+10% to Lightning Resistance
{variant:6}+(20-30)% to Lightning Resistance
{variant:1}100% reduced Mana Cost of Skills
{variant:2}20% reduced Mana Cost of Skills
{variant:6}Spells have a 20% chance to deal Double Damage
Blood Magic
{variant:4}Blood Magic
]],[[
Malachai's Awakening
Iron Mask
Source: No longer obtainable
Variant: Pre 3.7.0
Variant: Pre 3.17.0
Variant: Current
Requires Level 60, 21 Dex, 21 Int
+20 to Strength
(15-30)% increased Spell Damage
+10% to all Elemental Resistances
Adds (42-54) to (78-88) Cold Damage to Spells while no Life is Reserved
Adds (54-64) to (96-107) Fire Damage to Spells while no Life is Reserved
Adds (5-14) to (160-173) Lightning Damage to Spells while no Life is Reserved
Blood Magic
{variant:2}Blood Magic
]],[[
Mind of the Council
Harlequin Mask
Variant: Pre 3.10.0
Variant: Current
Requires Level 57, 64 Dex, 64 Int
(230-260)% increased Evasion and Energy Shield
{variant:2}+(15-20) to maximum Energy Shield
(20-30)% increased maximum Mana
10% chance to Shock
+20% chance to be Shocked
30% of Lightning Damage is taken from Mana before Life
{variant:1}Recover 3% of Mana when you Shock an Enemy
{variant:2}Attack Skills have Added Lightning Damage equal to 6% of maximum Mana
{variant:2}Lose 3% of Mana when you use an Attack Skill
]],[[
The Tempest's Binding
Callous Mask
League: Harbinger
Source: No longer obtainable
Requires Level 45, 51 Dex, 51 Int
Socketed Gems are Supported by Level 18 Ice Bite
Socketed Gems are Supported by Level 18 Innervate
Grants Summon Harbinger of Storms Skill
+(100-150) to Evasion Rating
+(40-60) to maximum Energy Shield
+(60-80) to maximum Life
+(10-15)% to all Elemental Resistances
]],[[
The Tempest's Liberation
Callous Mask
Requires Level 60, 51 Dex, 51 Int
Socketed Gems are Supported by Level 18 Ice Bite
Socketed Gems are Supported by Level 18 Innervate
Grants Summon Greater Harbinger of Storms Skill
+(100-150) to Evasion Rating
+(40-60) to maximum Energy Shield
+(60-80) to maximum Life
+(10-15)% to all Elemental Resistances
]],[[
The Three Dragons
Golden Mask
Requires Level 35, 40 Dex, 40 Int
+(26-30)% to all Elemental Resistances
Your Fire Damage can Shock but not Ignite
Your Cold Damage can Ignite but not Freeze or Chill
Your Lightning Damage can Freeze but not Shock
]],[[
The Unblinking Eye
Harlequin Mask
Shaper Item
Source: Drops from unique{The Shaper} (Uber)
Requires Level 57, 64 Dex, 64 Int
+(15-20)% chance to Suppress Spell Damage
+(50-100) to Dexterity
(120-160)% increased Evasion and Energy Shield
Increases and Reductions to your Evasion Rating also apply to your Spell Damage
Physical Damage Reduction is zero
]],[[
The Vertex
Vaal Mask
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Alluring Abyss}
Requires Level 62, 79 Dex, 72 Int
+1 to Level of Socketed Gems
Socketed Gems have 50% less Mana Cost
(245-280)% increased Evasion and Energy Shield
+(30-40) to maximum Energy Shield
+(24-30)% to Chaos Resistance
Enemies Cannot Leech Mana From you
]],[[
Viridi's Veil
Praetor Crown
League: Ritual
Source: Drops from unique{The Maven} (Uber)
Requires Level 68, 62 Str, 91 Int
+(1-2) to Level of Socketed Gems
(120-160)% increased Armour and Energy Shield
+(15-25)% to all Elemental Resistances
Damage of Enemies Hitting you is Unlucky while you have a Magic Ring Equipped
You are Hexproof if you have a Magic Ring in right slot
Take no Extra Damage from Critical Strikes if you have a Magic Ring in left slot
]],[[
Willclash
Golden Mask
League: Heist
Requires Level 35, 40 Dex, 40 Int
(350-400)% increased Evasion and Energy Shield
+5% Chance to Block Spell Damage per Power Charge
(3-5)% increased Elemental Damage per Power charge
Gain a Power Charge every Second if you haven't lost Power Charges Recently
Lose all Power Charges when you Block
]],
-- Helmet: Ward
[[
Faithguard
Runic Helm
League: Expedition
Variant: Pre 3.19.0
Variant: Current
+(20-30) to Intelligence
(25-35)% increased Ward
{variant:1}(20-30)% faster Restoration of Ward
{variant:2}(40-60)% faster Restoration of Ward
(15-25)% increased Light Radius
Increases and Reductions to Maximum Energy Shield instead apply to Ward
]],[[
Cadigan's Crown
Runic Crown
League: Expedition
Source: Drops from unique{Olroth, Origin of the Fall} in normal{Expedition Logbook}
Requires Level 68, 66 Str, 66 Dex, 66 Int
Never deal Critical Strikes
Battlemage
]],}
