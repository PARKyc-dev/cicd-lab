-- Item data (c) Grinding Gear Games

return {
-- Jewel: Drop
[[
Anatomical Knowledge
Cobalt Jewel
Source: No longer obtainable
Radius: Large
(6-8)% increased maximum Life
Adds 1 to Maximum Life per 3 Intelligence Allocated in Radius
]],[[
The Anima Stone
Prismatic Jewel
Variant: Pre 3.23.0
Variant: Current
Source: Vendor Recipe
Limited to: 1
{variant:1}+1 to maximum number of Summoned Golems
+1 to maximum number of Summoned Golems if you have 3 Primordial Items Socketed or Equipped
]],[[
Apex Mode
Cobalt Jewel
League: Heist
Source: Drops from unique{The Unbreakable} in normal{Contract: Breaking the Unbreakable}
Limited to: 1
Requires Level 20
(20-25)% increased Spell Damage
Spells have 10% reduced Critical Strike Chance per Intensity
Spells which have gained Intensity Recently gain 1 Intensity every 0.5 Seconds
]],[[
Apparitions
Viridian Jewel
Source: No longer obtainable
Minions have (5-10)% increased Movement Speed
Minions have +(2-5)% chance to Suppress Spell Damage
]],[[
The Blue Dream
Cobalt Jewel
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Chayula Breach or from unique{Chayula, Who Dreamt}
Upgrade: Upgrades to unique{The Blue Nightmare} using currency{Blessing of Chayula}
Radius: Large
{variant:1}Gain 5% of Lightning Damage as Extra Chaos Damage
{variant:2}Gain (6-10)% of Lightning Damage as Extra Chaos Damage
Passives granting Lightning Resistance or all Elemental Resistances in Radius
also grant an equal chance to gain a Power Charge on Kill
]],[[
The Blue Nightmare
Cobalt Jewel
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Upgraded from unique{The Blue Dream} using currency{Blessing of Chayula}
Limited to: 1
Radius: Large
{variant:1}Gain 5% of Lightning Damage as Extra Chaos Damage
{variant:2}Gain (6-10)% of Lightning Damage as Extra Chaos Damage
{variant:1}Passives granting Lightning Resistance or all Elemental Resistances in Radius
{variant:1}also grant Chance to Block Spell Damage at 35% of its value
{variant:2}Passives granting Lightning Resistance or all Elemental Resistances in Radius
{variant:2}also grant Chance to Block Spell Damage at 50% of its value
{variant:1}Passives granting Lightning Resistance or all Elemental Resistances in Radius
{variant:1}also grant an equal chance to gain a Power Charge on Kill
]],[[
Brawn
Crimson Jewel
Source: No longer obtainable
(4-6)% increased Strength
(4-6)% increased Dexterity
(10-15)% reduced Intelligence
]],[[
Bloodnotch
Crimson Jewel
Variant: Pre 3.28.0
Variant: Current
Limited to: 1
{variant:1}(40-60)% of Damage taken from Stunning Hits is Recovered as Life
{variant:2}(20-30)% of Damage taken from Stunning Hits is Recovered as Life
]],[[
Calamitous Visions
Small Cluster Jewel
League: Delirium
Source: Drops from unique Delirium bosses in maps
Adds Lone Messenger
]],[[
Cheap Construction
Viridian Jewel
Source: No longer obtainable
10% reduced Trap Duration
Can have up to 1 additional Trap placed at a time
]],[[
Replica Cheap Construction
Viridian Jewel
Source: No longer obtainable
League: Heist
(100-120)% increased Critical Strike Chance with Traps
Can have 5 fewer Traps placed at a time
]],[[
Clear Mind
Cobalt Jewel
Source: No longer obtainable
Limited to: 1
(20-30)% increased Mana Regeneration Rate
(40-60)% increased Spell Damage while no Mana is Reserved
]],[[
Coated Shrapnel
Crimson Jewel
Source: No longer obtainable
Radius: Small
Variant: Pre 3.8.0
Variant: Current
{variant:1}Traps and Mines deal (3-5) to (10-15) additional Physical Damage
Traps and Mines have a 25% chance to Poison on Hit
{variant:2}Passive Skills in Radius also grant: Traps and Mines deal (2-3) to (4-6) added Physical Damage
]],[[
Cold Steel
Viridian Jewel
Source: No longer obtainable
Radius: Large
Increases and Reductions to Physical Damage in Radius are Transformed to apply to Cold Damage
Increases and Reductions to Cold Damage in Radius are Transformed to apply to Physical Damage
]],[[
Dissolution of the Flesh
Prismatic Jewel
Source: Drops from unique{The Searing Exarch}
Limited to: 1
Removes all Energy Shield
Life that would be lost by taking Damage is instead Reserved
until you take no Damage to Life for 2 seconds
(20-30)% more Maximum Life
]],[[
Divine Inferno
Crimson Jewel
Source: No longer obtainable
Limited to: 1
Radius: Medium
With at least 40 Strength in Radius, Combust is Disabled
With at least 40 Strength in Radius, Attacks Exerted by Infernal Cry deal (40-60)% more Damage with Ignite
]],[[
Eldritch Knowledge
Cobalt Jewel
Source: No longer obtainable
Radius: Medium
5% increased Chaos Damage per 10 Intelligence from Allocated Passives in Radius
]],[[
Endless Misery
Cobalt Jewel
Source: No longer obtainable
League: Heist
Limited to: 1
Radius: Medium
(7-10)% increased Elemental Damage
With at least 40 Intelligence in Radius, Discharge has 60% less Area of Effect
With at least 40 Intelligence in Radius, Discharge Cooldown is 250 ms
With at least 40 Intelligence in Radius, Discharge deals 60% less Damage
]],[[
Fireborn
Crimson Jewel
Source: No longer obtainable
Radius: Medium
Increases and Reductions to other Damage Types in Radius are Transformed to apply to Fire Damage
]],[[
Fortified Legion
Cobalt Jewel
Source: No longer obtainable
Limited to: 1
Minions have (5-15)% increased maximum Life
Minions Recover 2% of their Life when they Block
]],[[
Fragile Bloom
Crimson Jewel
Source: No longer obtainable
Limited to: 1
Variant: Pre 3.11.0
Variant: Current
{variant:1}Regenerate 2% of Life per second
{variant:1}10% increased Damage taken
{variant:2}Maximum 10 Fragile Regrowth
{variant:2}0.7% of Life Regenerated per second per Fragile Regrowth
{variant:2}Lose all Fragile Regrowth when Hit
{variant:2}Gain 1 Fragile Regrowth each second
]],[[
Replica Fragile Bloom
Crimson Jewel
Source: No longer obtainable
League: Heist
Limited to: 1
Implicits: 0
Maximum 5 Fragile Regrowth
0.7% of Life Regenerated per second per Fragile Regrowth
Gain up to maximum Fragile Regrowth when Hit
Lose 1 Fragile Regrowth each second
]],[[
From Dust
Cobalt Jewel
Source: No longer obtainable
Limited to: 1
Variant: Pre 3.8.0
Variant: Current
Implicits: 0
{variant:1}Summon 2 additional Skeletons with Summon Skeletons
{variant:2}Summon 4 additional Skeletons with Summon Skeletons
+1 second to Summon Skeleton Cooldown
]],[[
The Front Line
Small Cluster Jewel
League: Delirium
Source: Drops from unique Delirium bosses in maps
Adds Veteran's Awareness
]],[[
Grand Spectrum
Cobalt Jewel
Source: Drops in The Lord's Labyrinth
Limited to: 3
Variant: Pre 3.0.0
Variant: Pre 3.10.0
Variant: Current - Crit Chance
Variant: Current - Minion Crit Multi
Variant: Current - Min Power Charge
{variant:1}Gain 15 Mana per Grand Spectrum
{variant:2}Gain 30 Mana per Grand Spectrum
{variant:3}25% increased Critical Strike Chance per Grand Spectrum
{variant:5}+1 to Minimum Power Charges per Grand Spectrum
{variant:4}Minions have +10% to Critical Strike Multiplier per Grand Spectrum
]],[[
Grand Spectrum
Crimson Jewel
Source: Drops in The Lord's Labyrinth
Limited to: 3
Variant: Pre 3.0.0
Variant: Pre 3.10.0
Variant: Current - Elemental Resistances
Variant: Current - Maximum Life
Variant: Current - Min Endurance Charge
{variant:1}Gain 75 Armour per Grand Spectrum
{variant:2}Gain 200 Armour per Grand Spectrum
{variant:3}+7% to all Elemental Resistances per Grand Spectrum
{variant:4}5% increased Maximum Life per Grand Spectrum
{variant:5}+1 to Minimum Endurance Charges per Grand Spectrum
]],[[
Grand Spectrum
Viridian Jewel
Source: Drops in The Lord's Labyrinth
Limited to: 3
Variant: Pre 2.5.0
Variant: Pre 3.0.0
Variant: Pre 3.10.0
Variant: Current - Elemental Damage
Variant: Current - Chance to avoid Ailments
Variant: Current - Min Frenzy Charge
{variant:5}12% chance to Avoid Elemental Ailments per Grand Spectrum
{variant:1}5% increased Elemental Damage per Grand Spectrum
{variant:2}4% increased Elemental Damage per Grand Spectrum
{variant:3}12% increased Elemental Damage per Grand Spectrum
{variant:4}15% increased Elemental Damage per Grand Spectrum
{variant:6}+1 to Minimum Frenzy Charges per Grand Spectrum
]],[[
The Green Dream
Viridian Jewel
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Drops in Chayula Breach or from unique{Chayula, Who Dreamt}
Upgrade: Upgrades to unique{The Green Nightmare} using currency{Blessing of Chayula}
Radius: Large
{variant:1}Gain 5% of Cold Damage as Extra Chaos Damage
{variant:2}Gain (6-10)% of Cold Damage as Extra Chaos Damage
Passives granting Cold Resistance or all Elemental Resistances in Radius
also grant an equal chance to gain a Frenzy Charge on Kill
]],[[
The Green Nightmare
Viridian Jewel
Variant: Pre 3.16.0
Variant: Pre 3.21.0
Variant: Current
League: Breach
Source: Upgraded from unique{The Green Dream} using currency{Blessing of Chayula}
Limited to: 1
Radius: Large
{variant:1,2}Gain 5% of Cold Damage as Extra Chaos Damage
{variant:3}Gain (6-10)% of Cold Damage as Extra Chaos Damage
{variant:1,2}Passives granting Cold Resistance or all Elemental Resistances in Radius
{variant:1,2}also grant an equal chance to gain a Frenzy Charge on Kill
{variant:1}Passives granting Cold Resistance or all Elemental Resistances in Radius
{variant:1}also grant Chance to Suppress Spell Damage at 35% of its value
{variant:2}Passives granting Cold Resistance or all Elemental Resistances in Radius
{variant:2}also grant Chance to Suppress Spell Damage at 50% of its value
{variant:3}Passives granting Cold Resistance or all Elemental Resistances in Radius
{variant:3}also grant Chance to Suppress Spell Damage at 70% of its value
]],[[
Hair Trigger
Viridian Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
(15-25)% increased Trap Damage
{variant:1}(20-30)% increased Trap Trigger Area of Effect
{variant:2}(40-60)% increased Trap Trigger Area of Effect
]],[[
Hotheaded
Viridian Jewel
Source: No longer obtainable
Limited to: 1
Variant: Pre 3.11.0
Variant: Current
{variant:1}(10-15)% increased Movement Speed while Ignited
{variant:2}(10-20)% increased Movement Speed while Ignited
{variant:2}(10-20)% increased Attack Speed while Ignited
{variant:2}(10-20)% increased Cast Speed while Ignited
]],[[
Replica Hotheaded
Viridian Jewel
Source: No longer obtainable
League: Heist
Limited to: 1
(10-20)% increased Attack Speed while Chilled
(10-20)% increased Cast Speed while Chilled
(10-20)% increased Movement Speed while Chilled
]],[[
Inspired Learning
Crimson Jewel
Radius: Small
With 4 Notables Allocated in Radius, When you Kill a Rare monster, you gain 1 of its Modifiers for 20 seconds
]],[[
The Interrogation
Small Cluster Jewel
League: Delirium
Source: Drops from unique Delirium bosses in maps
Adds Secrets of Suffering
]],[[
Intuitive Leap
Viridian Jewel
Radius: Small
Passive Skills in Radius can be Allocated without being connected to your tree
Passage
]],[[
Izaro's Turmoil
Crimson Jewel
Source: No longer obtainable
(18-25)% increased Fire Damage
(18-25)% increased Cold Damage
2% chance to Ignite
2% chance to Freeze
]],[[
Kitava's Teachings
Small Cluster Jewel
League: Delirium
Source: Drops from unique Delirium bosses in maps
Adds Disciple of Kitava
]],[[
The Light of Meaning
Prismatic Jewel
Variant: Life
Variant: Energy Shield
Variant: Mana
Variant: Armour
Variant: Evasion Rating
Variant: Attributes
Variant: Global Crit Chance
Variant: Physical Damage
Variant: Lightning Damage
Variant: Cold Damage
Variant: Fire Damage
Variant: Chaos Damage
Variant: Chaos Resistance
Selected Variant: 1
Source: King of The Mists
Limited to: 1
Radius: Large
{variant:6}Passive Skills in Radius also grant +2 to all Attributes
{variant:13}Passive Skills in Radius also grant +4% to Chaos Resistance
{variant:1}Passive Skills in Radius also grant +5 to maximum Life
{variant:3}Passive Skills in Radius also grant +5 to maximum Mana
{variant:12}Passive Skills in Radius also grant 6% increased Chaos Damage
{variant:10}Passive Skills in Radius also grant 6% increased Cold Damage
{variant:7}Passive Skills in Radius also grant 5% increased Global Critical Strike Chance
{variant:5}Passive Skills in Radius also grant 7% increased Evasion Rating
{variant:11}Passive Skills in Radius also grant 6% increased Fire Damage
{variant:9}Passive Skills in Radius also grant 6% increased Lightning Damage
{variant:2}Passive Skills in Radius also grant 3% increased Energy Shield
{variant:8}Passive Skills in Radius also grant 6% increased Physical Damage
{variant:4}Passive Skills in Radius also grant 7% increased Armour
]],[[
Lioneye's Fall
Viridian Jewel
Radius: Medium
Melee and Melee Weapon Type modifiers in Radius are Transformed to Bow Modifiers
]],[[
Lord of Steel
Viridian Jewel
Source: No longer obtainable
League: Heist
Limited to: 1
Variant: Impale Chance (Pre 3.13.0)
Variant: Impale Overwhelm (Pre 3.13.0)
Variant: Impale Effect (Pre 3.13.0)
Variant: Impale Chance (Current)
Variant: Impale Overwhelm (Current)
Variant: Impale Effect (Current)
{variant:2,5}Impale Damage dealt to Enemies Impaled by you Overwhelms 10% Physical Damage Reduction
{variant:1,4}10% chance to Impale Enemies on Hit with Attacks
{variant:3,6}5% increased Impale Effect
{variant:1,3,4,6}Call of Steel deals Reflected Damage with (40-50)% increased Area of Effect
{variant:2,3,5,6}Call of Steel has (80-100)% increased Use Speed
{variant:1,2}Call of Steel causes (40-50)% increased Reflected Damage
{variant:4,5}Call of Steel causes (20-25)% increased Reflected Damage
]],[[
Malicious Intent
Cobalt Jewel
Source: No longer obtainable
5% chance to Gain Unholy Might for 4 seconds on Melee Kill
]],[[
Mantra of Flames
Crimson Jewel
Source: No longer obtainable
Limited to: 1
Adds (3-5) to (8-12) Fire Attack Damage per Buff on you
Adds (2-3) to (5-8) Fire Spell Damage per Buff on you
]],[[
Martial Artistry
Crimson Jewel
Source: No longer obtainable
Limited to: 1
Variant: Pre 3.11.0
Variant: Current
Radius: Small
{variant:1}(10-15)% increased Area of Effect while Unarmed
{variant:2}+(0.3-0.4) metres to Melee Strike Range with Unarmed Attacks
{variant:2}Passive Skills in Radius also grant: 1% increased Unarmed Attack Speed with Melee Skills
]],[[
Melding of the Flesh
Cobalt Jewel
Variant: Pre 3.19.0
Variant: Current
Source: Drops from unique{The Eater of Worlds}
Limited to: 1
-(80-70)% to all Elemental Resistances
{variant:2}-(6-4)% to all maximum Elemental Resistances
Elemental Resistances are capped by your highest Maximum Elemental Resistance instead
]],[[
Might in All Forms
Crimson Jewel
Source: No longer obtainable
Radius: Medium
Dexterity and Intelligence from passives in Radius count towards Strength Melee Damage bonus
]],[[
Might of the Meek
Crimson Jewel
Radius: Large
50% increased Effect of non-Keystone Passive Skills in Radius
Notable Passive Skills in Radius grant nothing
]],[[
Immutable Force
Crimson Jewel
Limited to: 1
(500-1000)% increased Stun and Block Recovery
]],[[
Firesong
Crimson Jewel
+(10-15)% to Fire Resistance
Modifiers to Ignite Duration on you apply to all Elemental Ailments
]],[[
Stormshroud
Viridian Jewel
+(10-15)% to Lightning Resistance
Modifiers to Chance to Avoid being Shocked apply to all Elemental Ailments
]],[[
Witchbane
Cobalt Jewel
+(5-15) to Intelligence
When you Kill an Enemy Cursed with a Non-Aura Hex, become Immune to
Curses for remaining Hex Duration
]],[[
Rational Doctrine
Cobalt Jewel
Source: Drops from unique{Synthete Nightmare} in normal{The Cortex} (Uber)
You have Consecrated Ground around you while
stationary if Strength is your highest Attribute
25% chance to create Profane Ground on Critical
Strike if Intelligence is your highest Attribute
Effects of Consecrated Ground you create Linger for 4 seconds
Effects of Profane Ground you create Linger for 4 seconds
]],[[
Nadir Mode
Cobalt Jewel
Variant: Pre 3.26
Variant: Current
League: Heist
Source: Drops from unique{The Unbreakable} in normal{Contract: Breaking the Unbreakable}
Limited to: 1
Item Level: 82
(20-25)% increased Spell Damage
{variant:1}Spells have 30% increased Critical Strike Chance per Intensity
{variant:2}Spells have (30-50)% increased Critical Strike Chance per Intensity
Spells which have gained Intensity Recently lose 1 Intensity every 0.5 Seconds
]],[[
Natural Affinity
Small Cluster Jewel
League: Delirium
Source: Drops from unique Delirium bosses in maps
Adds Nature's Patience
]],[[
One With Nothing
Small Cluster Jewel
League: Delirium
Source: Drops from unique Delirium bosses in maps
Adds Hollow Palm Technique
]],[[
The Perandus Pact
Prismatic Jewel
Variant: Life
Variant: Energy Shield
Variant: Mana
Variant: Armour
Variant: Evasion Rating
Variant: Attributes
Variant: Global Crit Chance
Variant: Physical Damage
Variant: Lightning Damage
Variant: Cold Damage
Variant: Fire Damage
Variant: Chaos Damage
Variant: Chaos Resistance
Selected Variant: 1
League: Necropolis
Source: No longer obtainable
Limited to: 1
Radius: Large
{variant:6}Passive Skills in Radius also grant +2 to all Attributes
{variant:13}Passive Skills in Radius also grant +4% to Chaos Resistance
{variant:1}Passive Skills in Radius also grant +5 to maximum Life
{variant:3}Passive Skills in Radius also grant +5 to maximum Mana
{variant:12}Passive Skills in Radius also grant 6% increased Chaos Damage
{variant:10}Passive Skills in Radius also grant 6% increased Cold Damage
{variant:7}Passive Skills in Radius also grant 5% increased Global Critical Strike Chance
{variant:5}Passive Skills in Radius also grant 7% increased Evasion Rating
{variant:11}Passive Skills in Radius also grant 6% increased Fire Damage
{variant:9}Passive Skills in Radius also grant 6% increased Lightning Damage
{variant:2}Passive Skills in Radius also grant 3% increased Energy Shield
{variant:8}Passive Skills in Radius also grant 6% increased Physical Damage
{variant:4}Passive Skills in Radius also grant 7% increased Armour
]],[[
Primordial Eminence
Viridian Jewel
Golems have (16-20)% increased Attack and Cast Speed
30% increased Effect of Buffs granted by your Golems
Golems have +(800-1000) to Armour
Primordial
]],[[
Primordial Harmony
Cobalt Jewel
Variant: Pre 3.3.0
Variant: Current
Golem Skills have (20-30)% increased Cooldown Recovery Rate
{variant:1}Summoned Golems have (10-15)% increased Cooldown Recovery Rate
{variant:2}Summoned Golems have (30-45)% increased Cooldown Recovery Rate
(16-20)% increased Golem Damage for each Type of Golem you have Summoned
Summoned Golems Regenerate 2% of their Life per second
Primordial
]],[[
Primordial Might
Crimson Jewel
(25-30)% increased Damage if you Summoned a Golem in the past 8 seconds
Golems Summoned in the past 8 seconds deal (35-45)% increased Damage
Golems have (18-22)% increased Maximum Life
Primordial
Summoned Golems are Aggressive
]],[[
Replica Primordial Might
Crimson Jewel
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
-1 to maximum number of Summoned Golems
(25-30)% increased Damage if you Summoned a Golem in the past 8 seconds
Golems Summoned in the past 8 seconds deal (100-125)% increased Damage
Golems have (18-22)% increased Maximum Life
Primordial
Summoned Golems are Aggressive
]],[[
Pugilist
Viridian Jewel
Source: No longer obtainable
Radius: Large
1% increased Evasion Rating per 3 Dexterity Allocated in Radius
1% increased Claw Physical Damage per 3 Dexterity Allocated in Radius
1% increased Melee Physical Damage with Unarmed Attacks per 3 Dexterity Allocated in Radius
]],[[
Pure Talent
Viridian Jewel
Variant: Pre 3.20.0
Variant: Current
Limited to: 1
While your Passive Skill Tree connects to a class' starting location, you gain:
{variant:1}Marauder: Melee Skills have 15% increased Area of Effect
{variant:2}Marauder: Melee Skills have 25% increased Area of Effect
Duelist: 1% of Attack Damage Leeched as Life
Ranger: 7% increased Movement Speed
Shadow: +0.5% to Critical Strike Chance
Witch: 0.5% of Mana Regenerated per second
Templar: Damage Penetrates 5% Elemental Resistances
Scion: +25 to All Attributes
]],[[
Replica Pure Talent
Viridian Jewel
Source: No longer obtainable
League: Heist
Limited to: 1
While your Passive Skill Tree connects to a class' starting location, you gain:
Marauder: 1% of Life Regenerated per second
Duelist: +2 to Melee Strike Range
Ranger: 20% increased Flask Charges gained
Shadow: 12% increased Attack and Cast Speed
Witch: 20% increased Skill Effect Duration
Templar: +4% Chance to Block Attack and Spell Damage
Scion: 30% increased Damage
]],[[
Replica Reckless Defence
Cobalt Jewel
Variant: Pre 3.25.0
Variant: Current
League: Heist
{variant:1}+(2-4)% Chance to Block Attack Damage
{variant:2}+(2-6)% Chance to Block Attack Damage
{variant:1}+(2-4)% Chance to Block Spell Damage
{variant:2}+(2-6)% Chance to Block Spell Damage
+10% chance to be Frozen, Shocked and Ignited
]],[[
The Red Dream
Crimson Jewel
League: Breach
Source: Drops in Chayula Breach or from unique{Chayula, Who Dreamt}
Upgrade: Upgrades to unique{The Red Nightmare} using currency{Blessing of Chayula}
Radius: Large
Variant: Pre 3.21.0
Variant: Current
{variant:1}Gain 5% of Fire Damage as Extra Chaos Damage
{variant:2}Gain (6-10)% of Fire Damage as Extra Chaos Damage
Passives granting Fire Resistance or all Elemental Resistances in Radius
also grant an equal chance to gain an Endurance Charge on Kill
]],[[
The Red Nightmare
Crimson Jewel
League: Breach
Source: Upgraded from unique{The Red Dream} using currency{Blessing of Chayula}
Limited to: 1
Radius: Large
Variant: Pre 3.21.0
Variant: Current
{variant:1}Gain 5% of Fire Damage as Extra Chaos Damage
{variant:2}Gain (6-10)% of Fire Damage as Extra Chaos Damage
{variant:1}Passives granting Fire Resistance or all Elemental Resistances in Radius
{variant:1}also grant Chance to Block Attack Damage at 35% of its value
{variant:2}Passives granting Fire Resistance or all Elemental Resistances in Radius
{variant:2}also grant Chance to Block Attack Damage at 50% of its value
{variant:1}Passives granting Fire Resistance or all Elemental Resistances in Radius
{variant:1}also grant an equal chance to gain an Endurance Charge on Kill
]],[[
The Siege
Small Cluster Jewel
League: Delirium
Source: Drops from unique Delirium bosses in maps
Adds Kineticism
]],[[
Spire of Stone
Crimson Jewel
Source: No longer obtainable
Limited to: 1
Radius: Large
3% increased Totem Life per 10 Strength Allocated in Radius
Totems cannot be Stunned
]],[[
Static Electricity
Viridian Jewel
Source: No longer obtainable
Radius: Large
Adds 1 to 2 Lightning Damage to Attacks
Adds 1 maximum Lightning Damage to Attacks per 1 Dexterity Allocated in Radius
]],[[
Tempered Flesh
Crimson Jewel
League: Incursion
Source: Drops from unique{The Vaal Omnitect}
Upgrade: Upgrades to unique{Transcendent Flesh} via currency{Vial of Transcendence}
Variant: Pre 3.8.0
Variant: Pre 3.10.0
Variant: Current
Radius: Medium
-1 Strength per 1 Strength on Allocated Passives in Radius
{variant:1}+5% to Critical Strike Multiplier per 10 Strength on Unallocated Passives in Radius
{variant:2}+7% to Critical Strike Multiplier per 10 Strength on Unallocated Passives in Radius
{variant:3}2% increased Life Recovery Rate per 10 Strength on Allocated Passives in Radius
]],[[
Transcendent Flesh
Crimson Jewel
League: Incursion
Source: Upgraded from unique{Tempered Flesh} via currency{Vial of Transcendence}
Variant: Pre 3.8.0
Variant: Pre 3.10.0
Variant: Current
Radius: Medium
-1 Strength per 1 Strength on Allocated Passives in Radius
{variant:1,2}1% additional Physical Damage Reduction per 10 Strength on Allocated Passives in Radius
{variant:2,3}+7% to Critical Strike Multiplier per 10 Strength on Unallocated Passives in Radius
{variant:1}+5% to Critical Strike Multiplier per 10 Strength on Unallocated Passives in Radius
{variant:3}3% increased Life Recovery Rate per 10 Strength on Allocated Passives in Radius
{variant:3}2% reduced Life Recovery Rate per 10 Strength on Unallocated Passives in Radius
]],[[
Tempered Mind
Cobalt Jewel
League: Incursion
Source: Drops from unique{The Vaal Omnitect}
Upgrade: Upgrades to unique{Transcendent Mind} via currency{Vial of Transcendence}
Variant: Pre 3.8.0
Variant: Pre 3.10.0
Variant: Current
Radius: Medium
-1 Intelligence per 1 Intelligence on Allocated Passives in Radius
{variant:1}+100 to Accuracy Rating per 10 Intelligence on Unallocated Passives in Radius
{variant:2}+125 to Accuracy Rating per 10 Intelligence on Unallocated Passives in Radius
{variant:3}2% increased Mana Recovery Rate per 10 Intelligence on Allocated Passives in Radius
]],[[
Transcendent Mind
Cobalt Jewel
League: Incursion
Source: Upgraded from unique{Tempered Mind} via currency{Vial of Transcendence}
Variant: Pre 3.8.0
Variant: Pre 3.10.0
Variant: Current
Radius: Medium
-1 Intelligence per 1 Intelligence on Allocated Passives in Radius
{variant:1,2}Regenerate 0.4% of Energy Shield per Second for
{variant:1,2}every 10 Intelligence on Allocated Passives in Radius
{variant:1}+100 to Accuracy Rating per 10 Intelligence on Unallocated Passives in Radius
{variant:2}+125 to Accuracy Rating per 10 Intelligence on Unallocated Passives in Radius
{variant:3}+3% to Damage over Time Multiplier per 10 Intelligence on Unallocated Passives in Radius
{variant:3}3% increased Mana Recovery Rate per 10 Intelligence on Allocated Passives in Radius
{variant:3}2% reduced Mana Recovery Rate per 10 Intelligence on Unallocated Passives in Radius
]],[[
Tempered Spirit
Viridian Jewel
League: Incursion
Source: Drops from unique{The Vaal Omnitect}
Upgrade: Upgrades to unique{Transcendent Spirit} via currency{Vial of Transcendence}
Variant: Pre 3.10.0
Variant: Current
Radius: Medium
-1 Dexterity per 1 Dexterity on Allocated Passives in Radius
{variant:2}2% increased Movement Speed per 10 Dexterity on Allocated Passives in Radius
{variant:1}+15 to Maximum Mana per 10 Dexterity on Unallocated Passives in Radius
]],[[
Transcendent Spirit
Viridian Jewel
League: Incursion
Source: Upgraded from unique{Tempered Spirit} via currency{Vial of Transcendence}
Variant: Pre 3.10.0
Variant: Current
Radius: Medium
-1 Dexterity per 1 Dexterity on Allocated Passives in Radius
{variant:1}2% increased Movement Speed per 10 Dexterity on Allocated Passives in Radius
{variant:2}3% increased Movement Speed per 10 Dexterity on Allocated Passives in Radius
{variant:1}+15 to Maximum Mana per 10 Dexterity on Unallocated Passives in Radius
{variant:2}+125 to Accuracy Rating per 10 Dexterity on Unallocated Passives in Radius
{variant:2}2% reduced Movement Speed per 10 Dexterity on Unallocated Passives in Radius
]],[[
Thread of Hope
Crimson Jewel
Source: Drops from unique{Sirus, Awakener of Worlds}
Variant: Small Ring
Variant: Medium Ring
Variant: Large Ring
Variant: Very Large Ring
Variant: Massive Ring (Uber)
Radius: Variable
Implicits: 0
{variant:1}Only affects Passives in Small Ring
{variant:5}Only affects Passives in Massive Ring
-(20-10)% to all Elemental Resistances
Passive Skills in Radius can be Allocated without being connected to your tree
Passage
{variant:2}Only affects Passives in Medium Ring
{variant:3}Only affects Passives in Large Ring
{variant:4}Only affects Passives in Very Large Ring
]],[[
Unnatural Instinct
Viridian Jewel
Limited to: 1
Radius: Small
Allocated Small Passive Skills in Radius grant nothing
Grants all bonuses of Unallocated Small Passive Skills in Radius
]],[[
Unstable Payload
Cobalt Jewel
Source: No longer obtainable
(8-12)% Chance for Traps to Trigger an additional time
]],[[
Replica Unstable Payload
Cobalt Jewel
Source: No longer obtainable
League: Heist
Implicits: 0
Recover (20-30) Life when your Trap is triggered by an Enemy
]],[[
Voices
Large Cluster Jewel
League: Delirium
Source: Drops from the Simulacrum Encounter
Variant: Adds 1 Small Passive Skill
Variant: Adds 3 Small Passive Skills
Variant: Adds 5 Small Passive Skills
Variant: Adds 7 Small Passive Skills
Adds 3 Jewel Socket Passive Skills
{variant:1}Adds 1 Small Passive Skill which grants nothing
{variant:2}Adds 3 Small Passive Skills which grant nothing
{variant:3}Adds 5 Small Passive Skills which grant nothing
{variant:4}Adds 7 Small Passive Skills which grant nothing
]],[[
Split Personality
Crimson Jewel
League: Delirium
Source: Drops from the Simulacrum Encounter
Has Alt Variant: true
Variant: Strength
Variant: Dexterity
Variant: Intelligence
Variant: Life
Variant: Mana
Variant: Energy Shield
Variant: Armour
Variant: Evasion Rating
Variant: Accuracy Rating
Limited to: 2
This Jewel's Socket has 25% increased effect per Allocated Passive Skill between
it and your Class' starting location
{variant:1}+5 to Strength
{variant:2}+5 to Dexterity
{variant:3}+5 to Intelligence
{variant:9}+40 to Accuracy Rating
{variant:7}+40 to Armour
{variant:8}+40 to Evasion Rating
{variant:6}+5 to maximum Energy Shield
{variant:4}+5 to maximum Life
{variant:5}+5 to maximum Mana
Corrupted
]],[[
Warrior's Tale
Crimson Jewel
League: Ancestor
Source: No longer obtainable
Limited to: 1
Radius: Medium
100% increased effect of Tattoos in Radius
]],
-- Jewel: Abyss
[[
Amanamu's Gaze
Ghastly Eye Jewel
+(5-10) to all Attributes
Minions have +6% to Damage over Time Multiplier per
Ghastly Eye Jewel affecting you, up to a maximum of +30%
]],[[
Kurgal's Gaze
Hypnotic Eye Jewel
+(10-20) to Intelligence
8% increased Effect of Arcane Surge on you per
Hypnotic Eye Jewel affecting you, up to a maximum of 40%
]],[[
Tecrod's Gaze
Murderous Eye Jewel
Variant: Pre 3.21.0
Variant: Current
Requires Level 40
+(10-20) to Strength
{variant:1}20% increased Main Hand Critical Strike Chance per
{variant:1}Murderous Eye Jewel affecting you, up to a maximum of 200%
{variant:2}40% increased Main Hand Critical Strike Chance per
{variant:2}Murderous Eye Jewel affecting you, up to a maximum of 200%
{variant:1}+10% to Off Hand Critical Strike Multiplier per
{variant:1}Murderous Eye Jewel affecting you, up to a maximum of +100%
{variant:2}+20% to Off Hand Critical Strike Multiplier per
{variant:2}Murderous Eye Jewel affecting you, up to a maximum of +100%
]],[[
Ulaman's Gaze
Searching Eye Jewel
Requires Level 40
+(10-20) to Dexterity
Projectiles have 4% chance to be able to Chain when colliding with terrain per
Searching Eye Jewel affecting you, up to a maximum of 20%
]],
-- Jewel: Threshold
[[
Combat Focus
Crimson Jewel
Source: Vendor Recipe
Limited to: 2
Variant: Pre 3.21.0
Variant: Current
Radius: Medium
{variant:2}(10-15)% increased Elemental Damage
{variant:1}(10-15)% increased Elemental Damage with Attack Skills
With 40 total Strength and Intelligence in Radius, Prismatic Skills deal 50% less Cold Damage
With 40 total Strength and Intelligence in Radius, Prismatic Skills cannot choose Cold
]],[[
Combat Focus
Cobalt Jewel
Source: Vendor Recipe
Limited to: 2
Variant: Pre 3.21.0
Variant: Current
Radius: Medium
{variant:2}(10-15)% increased Elemental Damage
{variant:1}(10-15)% increased Elemental Damage with Attack Skills
With 40 total Intelligence and Dexterity in Radius, Prismatic Skills deal 50% less Fire Damage
With 40 total Intelligence and Dexterity in Radius, Prismatic Skills cannot choose Fire
]],[[
Combat Focus
Viridian Jewel
Source: Vendor Recipe
Limited to: 2
Variant: Pre 3.21.0
Variant: Current
Radius: Medium
{variant:2}(10-15)% increased Elemental Damage
{variant:1}(10-15)% increased Elemental Damage with Attack Skills
With 40 total Dexterity and Strength in Radius, Prismatic Skills deal 50% less Lightning Damage
With 40 total Dexterity and Strength in Radius, Prismatic Skills cannot choose Lightning
]],[[
Collateral Damage
Viridian Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
(10-15)% increased Global Physical Damage
With at least 40 Dexterity in Radius, Galvanic Arrow has 25% increased Area of Effect
With at least 40 Dexterity in Radius, Galvanic Arrow deals 50% increased Area Damage
]],[[
Dead Reckoning
Cobalt Jewel
Limited to: 1
Variant: Pre 3.0.0
Variant: Pre 3.8.0
Variant: Pre 3.23.0
Variant: Current
Radius: Medium
{variant:1,2,3}Minions have +(7-10)% to all Elemental Resistances
{variant:1}With at least 40 Intelligence in Radius, Summon Skeletons can Summon up to 3 Skeleton Mages
{variant:2}With at least 40 Intelligence in Radius, Summon Skeletons can Summon up to 5 Skeleton Mages
{variant:3}With at least 40 Intelligence in Radius, Summon Skeletons can Summon up to 15 Skeleton Mages
{variant:4}Skeletons gain Added Chaos Damage equal to (20-30)% of Maximum Energy Shield on your Equipped Shield
]],[[
Fight for Survival
Viridian Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
(10-15)% increased Cold Damage
With at least 40 Dexterity in Radius, Melee Damage
dealt by Frost Blades Penetrates 15% Cold Resistance
With at least 40 Dexterity in Radius, Frost Blades has 25% increased Projectile Speed
]],[[
First Snow
Cobalt Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
(7-10)% increased Projectile Damage
With at least 40 Intelligence in Radius, Freezing Pulse fires 2 additional Projectiles
With at least 40 Intelligence in Radius, 25% increased Freezing Pulse Damage if
you've Shattered an Enemy Recently
]],[[
Frozen Trail
Cobalt Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
(7-10)% increased Projectile Damage
With at least 40 Intelligence in Radius, Frostbolt fires 2 additional Projectiles
With at least 40 Intelligence in Radius, Frostbolt Projectiles gain 40% increased Projectile Speed per second
]],[[
Growing Agony
Viridian Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Limited to: 1
Radius: Medium
{variant:1}(4-12)% increased Damage over Time
{variant:2}(8-12)% increased Damage over Time
With at least 40 Dexterity in Radius, Viper Strike deals 2% increased Damage with Hits and Poison for each Poison on the Enemy
{variant:2}With at least 40 Dexterity in Radius, Viper Strike has a 10% chance per Poison on Enemy to grant Unholy Might for 4 seconds on Hit
]],[[
Hazardous Research
Cobalt Jewel
Source: No longer obtainable
Variant: Pre 3.17.0
Variant: Current
Limited to: 1
Radius: Medium
(10-15)% increased Lightning Damage
{variant:1}With at least 40 Intelligence in Radius, 2 additional Spark Projectiles
With at least 40 Intelligence in Radius, Spark fires Projectiles in a circle
{variant:1}(20-15)% reduced Spark Duration
]],[[
Inevitability
Cobalt Jewel
Source: No longer obtainable
Variant: Pre 3.11.0
Variant: Current
Limited to: 1
Radius: Medium
(10-15)% increased Fire Damage
{variant:2}With at least 40 Intelligence in Radius, Rolling Magma deals 50% less Damage
{variant:2}With at least 40 Intelligence in Radius, Rolling Magma deals 40% more Damage per Chain
{variant:2}With at least 40 Intelligence in Radius, Rolling Magma
{variant:2}has 10% increased Area of Effect per Chain
{variant:1}With at least 40 Intelligence in Radius, Rolling Magma fires an additional Projectile
{variant:1}With at least 40 Intelligence in Radius, Rolling Magma
{variant:1}has 10% increased Area of Effect per Chain
]],[[
The Long Winter
Cobalt Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
(10-15)% increased Cold Damage
With 40 Intelligence in Radius, Glacial Cascade has an additional Burst
With 40 Intelligence in Radius, 20% of Glacial Cascade Physical Damage
Converted to Cold Damage
]],[[
Might and Influence
Viridian Jewel
Source: No longer obtainable
Has Alt Variant: true
Variant: Pre 3.11.0
Variant: Axe
Variant: Claw
Variant: Dagger
Variant: Mace
Variant: Sword
Limited to: 1
Radius: Medium
{variant:2,3,4,5,6}(10-15)% increased Attack Damage
{variant:1}(10-15)% increased Global Physical Damage
{variant:6}With at least 40 Dexterity in Radius, Dual Strike has (20-30)% increased
{variant:6}Accuracy Rating while wielding a Sword
{variant:3}With at least 40 Dexterity in Radius, Dual Strike has (10-15)% increased Attack
{variant:3}Speed while wielding a Claw
{variant:4}With at least 40 Dexterity in Radius, Dual Strike has +(20-30)% to Critical Strike
{variant:4}Multiplier while wielding a Dagger
{variant:2}With at least 40 Dexterity in Radius, Dual Strike Hits Intimidate Enemies for
{variant:2}4 seconds while wielding an Axe
{variant:1}With at least 40 Dexterity in Radius, Dual Strike has a 20% chance
{variant:1}to deal Double Damage with the Main-Hand Weapon
{variant:1}With at least 40 Dexterity in Radius, Dual Strike deals Off Hand Splash Damage
{variant:1}to surrounding targets
{variant:5}With at least 40 Dexterity in Radius, Dual Strike deals Splash Damage
{variant:5}to surrounding targets while wielding a Mace
]],[[
Omen on the Winds
Viridian Jewel
Source: No longer obtainable
Variant: Pre 3.1.0
Variant: Current
Limited to: 2
Radius: Medium
(15-20)% increased Damage with Hits against Chilled Enemies
{variant:1}With at least 40 Dexterity in Radius, Ice Shot has 25% increased Area of Effect
{variant:1}With at least 40 Dexterity in Radius, Ice Shot Pierces 5 additional Targets
{variant:2}With at least 40 Dexterity in Radius, Ice Shot has 25% increased Area of Effect
{variant:2}With at least 40 Dexterity in Radius, Ice Shot Pierces 3 additional Targets
]],[[
Overwhelming Odds
Crimson Jewel
Source: No longer obtainable
Limited to: 1
Radius: Medium
(10-15)% increased Global Physical Damage
With at least 40 Strength in Radius, Hits with Cleave Fortify
With at least 40 Strength in Radius, Cleave has +0.1 metres to Radius per Nearby
Enemy, up to a maximum of +1 metre
]],[[
Pitch Darkness
Viridian Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Radius: Medium
+10% to Fire Damage over Time Multiplier
{variant:1}(5-15)% increased Fire Damage
{variant:2}(10-15)% increased Fire Damage
]],[[
Rapid Expansion
Crimson Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.3.0
Variant: Current
Limited to: 2
Radius: Medium
{variant:1}(4-12)% increased Global Physical Damage
{variant:2,3}(8-12)% increased Global Physical Damage
{variant:2}With at least 40 Strength in Radius, Ground Slam has a 25% chance
{variant:2}to grant an Endurance Charge when you Stun an Enemy
{variant:3}With at least 40 Strength in Radius, Ground Slam has a 35% chance
{variant:3}to grant an Endurance Charge when you Stun an Enemy
{variant:1}With at least 40 Strength in Radius, Ground Slam
{variant:1}has a 20% increased angle
{variant:2}With at least 40 Strength in Radius, Ground Slam
{variant:2}has a 35% increased angle
{variant:3}With at least 40 Strength in Radius, Ground Slam
{variant:3}has a 50% increased angle
]],[[
Ring of Blades
Viridian Jewel
Source: No longer obtainable
Variant: Pre 3.0.0
Variant: Pre 3.17.0
Variant: Current
Limited to: 1
Radius: Medium
(10-15)% increased Global Physical Damage
With at least 40 Dexterity in Radius, Ethereal Knives fires Projectiles in a circle
{variant:1}With at least 40 Dexterity in Radius, Ethereal Knives fires 10 additional Projectiles
{variant:2}With at least 40 Dexterity in Radius, Ethereal Knives fires 5 additional Projectiles
]],[[
Rolling Flames
Cobalt Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.11.0
Variant: Current
Limited to: 1
Radius: Medium
{variant:1}(5-15)% increased Fire Damage
{variant:2,3}(10-15)% increased Fire Damage
{variant:1}With at least 40 Intelligence in Radius, Fireball Projectiles gain Area as they travel farther, up to 50% increased Area of Effect
{variant:2}With at least 40 Intelligence in Radius, Projectiles gain radius as they travel farther, up to a maximum of +0.4 metres to radius
{variant:3}With at least 40 Intelligence in Radius, Fireball cannot ignite
{variant:3}With at least 40 Intelligence in Radius, Fireball has +(30-50)% chance to inflict scorch
]],[[
Shattered Chains
Crimson Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Radius: Medium
{variant:1}(5-15)% increased Cold Damage
{variant:2}(10-15)% increased Cold Damage
With at least 40 Strength in Radius, 20% increased
Rarity of Items dropped by Enemies Shattered by Glacial Hammer
]],[[
Spirit Guards
Viridian Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.20.0
Variant: Current
Limited to: 1
Radius: Medium
Minions deal (8-12)% increased Damage
{variant:1}With at least 40 Dexterity in Radius, Animate Weapon can Animate up to 4 Ranged Weapons
{variant:2}With at least 40 Dexterity in Radius, Animate Weapon can Animate up to 12 Ranged Weapons
{variant:3}With at least 40 Dexterity in Radius, Animate Weapon can Animate up to 20 Ranged Weapons
]],[[
Spirited Response
Cobalt Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Limited to: 1
Radius: Medium
{variant:1}(5-10)% increased maximum Mana
{variant:2}(7-10)% increased maximum Mana
With at least 40 Intelligence in Radius, 10% of Damage taken Recouped as Mana if you've Warcried Recently
]],[[
Spreading Rot
Cobalt Jewel
Source: No longer obtainable
Variant: Pre 3.17.0
Variant: Current
Limited to: 1
Radius: Medium
(7-13)% increased Chaos Damage
{variant:1,2}With at least 40 Intelligence in Radius, Blight inflicts Withered for 2 seconds
{variant:1,2}With at least 40 Intelligence in Radius, Blight has 50% increased Hinder Duration
]],[[
Steel Spirit
Viridian Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Current
Radius: Medium
{variant:1}(6-10)% increased Projectile Damage
{variant:2}(7-10)% increased Projectile Damage
{variant:1}With at least 40 Dexterity in Radius, each Spectral Throw Projectile gains 4% increased Damage each time it Hits
{variant:2}With at least 40 Dexterity in Radius, each Spectral Throw Projectile gains 5% increased Damage each time it Hits
]],[[
Sudden Ignition
Viridian Jewel
Source: No longer obtainable
Limited to: 1
Radius: Medium
(10-15)% increased Fire Damage
Ignited Enemies Killed by your Hits are destroyed
]],[[
Unending Hunger
Cobalt Jewel
Variant: Pre 2.6.0
Variant: Current
Limited to: 2
Radius: Medium
{variant:1}Minions have (5-8)% increased Area of Effect
{variant:2}Minions have (6-8)% increased Area of Effect
With at least 40 Intelligence in Radius, Raised Spectres have a 50% chance to gain Soul Eater for 20 seconds on Kill
]],[[
The Vigil
Crimson Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.14.0
Variant: Current
Limited to: 1
Radius: Medium
(8-15)% increased Armour
{variant:1}With at least 40 Strength in Radius, Hits with Vigilant Strike Fortify you and Nearby Allies for 3 seconds
{variant:2}With at least 40 Strength in Radius, Hits with Vigilant Strike Fortify you and Nearby Allies for 12 seconds
{variant:3}With at least 40 Strength in Radius, Hits with Vigilant Strike Fortify you and Nearby Allies for 8 seconds
]],[[
Violent Dead
Cobalt Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
Minions deal (10-15)% increased Damage
With at least 40 Intelligence in Radius, Raised
Zombies' Slam Attack has 100% increased Cooldown Recovery Rate
With at least 40 Intelligence in Radius, Raised Zombies' Slam
Attack deals 30% increased Damage
]],[[
Volley Fire
Viridian Jewel
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.9.0
Variant: Current
Limited to: 1
Radius: Medium
{variant:1}(6-10)% increased Projectile Damage
{variant:2,3}(7-10)% increased Projectile Damage
{variant:1,2}With at least 40 Dexterity in Radius, Barrage fires an additional 2 projectiles simultaneously on the first and final attacks
{variant:3}With at least 40 Dexterity in Radius, Barrage fires an additional 6 projectiles simultaneously on the first and final attacks
]],[[
Weight of the Empire
Crimson Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
(8-12)% increased Global Physical Damage
With at least 40 Strength in Radius, Heavy Strike has a 
20% chance to deal Double Damage
]],[[
Wildfire
Crimson Jewel
Source: No longer obtainable
Variant: Pre 3.11.0
Variant: Current
Limited to: 1
Radius: Medium
(10-15)% increased Fire Damage
{variant:2}With at least 40 Strength in Radius, Molten Strike Projectiles Chain on impacting ground
{variant:2}With at least 40 Strength in Radius, Molten Strike Projectiles Chain +1 time
{variant:2}With at least 40 Strength in Radius, Molten Strike fires 50% less Projectiles
{variant:1}With at least 40 Strength in Radius, Molten Strike fires 2 additional Projectiles
{variant:1}With at least 40 Strength in Radius, Molten Strike has 25% increased Area of Effect
]],[[
Winter Burial
Crimson Jewel
Source: No longer obtainable
Limited to: 2
Radius: Medium
(10-15)% increased Cold Damage
With at least 40 Strength in Radius, Glacial Hammer deals
Cold-only Splash Damage to surrounding targets
With at least 40 Strength in Radius, 25% of Glacial
Hammer Physical Damage Converted to Cold Damage
]],[[
Winter's Bounty
Cobalt Jewel
Source: No longer obtainable
Limited to: 1
Radius: Medium
(10-15)% increased Cold Damage
With at least 40 Intelligence in Radius, Cold Snap grants Power Charges instead of Frenzy Charges when Enemies die in its Area
With at least 40 Intelligence in Radius, Cold Snap's Cooldown can be bypassed by Power Charges instead of Frenzy Charges
]],[[
Ancestral Vision
Viridian Jewel
Limited to: 1
+(5-10) to Dexterity
Modifiers to Chance to Suppress Spell Damage also apply to Chance to Avoid Elemental Ailments at 50% of their Value
]],
-- Jewel: Corrupted
[[
Ancient Waystones
Crimson Jewel
Source: No longer obtainable
Limited to: 1
60% reduced Cost of Aura Skills that summon Totems
Corrupted
]],[[
Atziri's Reign
Crimson Jewel
Source: Use currency{Vaal Orb} on normal{Crimson Jewel}
Variant: Pre 3.14.0
Variant: Current
Limited to: 1
{variant:1,2}Vaal Skills have (15-20)% increased Skill Effect Duration
{variant:2}Vaal Skills have (15-20)% chance to regain consumed Souls when used
Corrupted
]],[[
Brute Force Solution
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 3.20.0
Variant: Current
Radius: Large
+(16-24) to Intelligence
Strength from Passives in Radius is Transformed to Intelligence
{variant:2}Corrupted
]],[[
Blood Sacrifice
Crimson Jewel
Source: No longer obtainable
Lose 1% of Life on Kill
Recover 1% of Mana on Kill
Lose 1% of Energy Shield on Kill
Corrupted
]],[[
Replica Blood Sacrifice
Crimson Jewel
Source: No longer obtainable
League: Heist
Implicits: 0
Recover 1% of Life on Kill
Recover 1% of Energy Shield on Kill
Cannot Leech or Regenerate Mana
]],[[
Brittle Barrier
Cobalt Jewel
Source: No longer obtainable
20% faster start of Energy Shield Recharge
10% increased Damage taken while on Full Energy Shield
Corrupted
]],[[
Careful Planning
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Variant: Pre 3.20.0
Variant: Current
Radius: Large
+(16-24) to Dexterity
Intelligence from Passives in Radius is Transformed to Dexterity
{variant:2}Corrupted
]],[[
Chill of Corruption
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Limited to: 1
50% chance to gain an additional Vaal Soul per Enemy Shattered
Corrupted
]],[[
Combustibles
Crimson Jewel
Source: No longer obtainable
10% reduced Quantity of Items found
(20-30)% increased Burning Damage
Corrupted
]],[[
Corrupted Energy
Cobalt Jewel
Source: No longer obtainable
Implicits: 0
With 5 Corrupted Items Equipped: 50% of Chaos Damage taken does not bypass Energy Shield, and 50% of Physical Damage taken bypasses Energy Shield
Corrupted
]],[[
Efficient Training
Crimson Jewel
Source: Use currency{Vaal Orb} on normal{Crimson Jewel}
Variant: Pre 3.20.0
Variant: Current
Radius: Large
+(16-24) to Strength
Intelligence from Passives in Radius is Transformed to Strength
{variant:2}Corrupted
]],[[
Energised Armour
Crimson Jewel
Source: Use currency{Vaal Orb} on normal{Crimson Jewel}
Variant: Pre 3.20.0
Variant: Current
Radius: Large
(15-20)% increased Armour
Increases and Reductions to Energy Shield in Radius are Transformed to apply to Armour at 200% of their value
{variant:2}Corrupted
]],[[
Energy From Within
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 2.5.0
Variant: Pre 3.20.0
Variant: Current
Radius: Large
{variant:1}(8-12)% increased maximum Energy Shield
{variant:2,3}(3-6)% increased maximum Energy Shield
Increases and Reductions to Life in Radius are Transformed to apply to Energy Shield
{variant:3}Corrupted
]],[[
Fertile Mind
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 3.20.0
Variant: Current
Radius: Large
+(16-24) to Intelligence
Dexterity from Passives in Radius is Transformed to Intelligence
{variant:2}Corrupted
]],[[
Fevered Mind
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 3.10.0
Variant: Pre 3.11.0
Variant: Current
Limited to: 1
Radius: Small
{variant:3}+(5-10) to Intelligence
{variant:1}(20-30)% increased Spell Damage
{variant:2}(30-40)% increased Spell Damage
{variant:1}100% increased Mana Cost of Skills
{variant:2}50% increased Mana Cost of Skills
{variant:3}Notable Passive Skills in Radius are Transformed to
{variant:3}instead grant: 10% increased Mana Cost of Skills and 20% increased Spell Damage
Corrupted
]],[[
Fluid Motion
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Variant: Pre 3.20.0
Variant: Current
Radius: Large
+(16-24) to Dexterity
Strength from Passives in Radius is Transformed to Dexterity
{variant:2}Corrupted
]],[[
Fortress Covenant
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 3.20.0
Variant: Current
Requires Level: 20
Limited to: 1
Radius: Medium
Minions deal (35-45)% increased Damage
Minions have +(10-12)% Chance to Block Attack Damage
Minions have +(10-12)% Chance to Block Spell Damage
Notable Passive Skills in Radius are Transformed to
instead grant: Minions take 20% increased Damage
{variant:2}Corrupted
]],[[
Fragility
Crimson Jewel
Source: Use currency{Vaal Orb} on normal{Crimson Jewel}
-1 to Maximum Endurance Charges
Corrupted
]],[[
Replica Fragility
Crimson Jewel
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Lose an Endurance Charge each second
Corrupted
]],[[
Healthy Mind
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 3.20.0
Variant: Current
Limited to: 1
Radius: Large
(15-20)% increased maximum Mana
Increases and Reductions to Life in Radius are Transformed to apply to Mana at 200% of their value
{variant:2}Corrupted
]],[[
Hidden Potential
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Variant: Pre 3.20.0
Variant: Current
Limited to: 1
(20-25)% increased Damage for each Magic Item Equipped
{variant:2}Corrupted
]],[[
Hungry Abyss
Viridian Jewel
Source: No longer obtainable
Limited to: 1
With 5 Corrupted Items Equipped: Life Leech recovers based on your Chaos Damage instead
Corrupted
]],[[
Inertia
Crimson Jewel
Source: Use currency{Vaal Orb} on normal{Crimson Jewel}
Variant: Pre 3.20.0
Variant: Current
Radius: Large
+(16-24) to Strength
Dexterity from Passives in Radius is Transformed to Strength
{variant:2}Corrupted
]],[[
Mutated Growth
Cobalt Jewel
Source: No longer obtainable
Limited to: 1
10% increased Experience Gain for Corrupted Gems
Corrupted
]],[[
Pacifism
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
-1 to Maximum Frenzy Charges
Corrupted
]],[[
Replica Pacifism
Viridian Jewel
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Lose a Frenzy Charge each second
Corrupted
]],[[
Powerlessness
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
-1 to Maximum Power Charges
Corrupted
]],[[
Replica Powerlessness
Cobalt Jewel
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Lose a Power Charge each second
Corrupted
]],[[
Quickening Covenant
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Variant: Pre 3.20.0
Variant: Current
Requires Level: 20
Limited to: 1
Radius: Medium
Minions have (12-16)% increased Attack Speed
Minions have (12-16)% increased Cast Speed
Minions have +(20-24)% chance to Suppress Spell Damage
Notable Passive Skills in Radius are Transformed to
instead grant: Minions have 25% reduced Movement Speed
{variant:2}Corrupted
]],[[
Rain of Splinters
Crimson Jewel
Source: Use currency{Vaal Orb} on normal{Crimson Jewel}
Variant: Pre 3.20.0
Variant: Current
Limited to: 1
(30-50)% reduced Totem Damage
Totems fire 2 additional Projectiles
{variant:2}Corrupted
]],[[
Reckless Defence
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 3.4.0
Variant: Pre 3.20.0
Variant: Pre 3.25.0
Variant: Current
{variant:1,2,3}(2-4)% Chance to Block Attack Damage
{variant:4}+(2-6)% Chance to Block Attack Damage
{variant:1}+6% Chance to Block Spell Damage
{variant:2,3}+(2-4)% Chance to Block Spell Damage
{variant:4}+(2-6)% Chance to Block Spell Damage
Hits have (140-200)% increased Critical Strike Chance against you
{variant:3}Corrupted
]],[[
Sacrificial Harvest
Viridian Jewel
Source: No longer obtainable
Limited to: 1
(20-30)% chance to gain an additional Vaal Soul on Kill
Corrupted
]],[[
Seething Fury
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Variant: Pre 3.16.0
Variant: Pre 3.20.0
Variant: Current
League: Legion
Requires Level: 20
Limited to: 1
(10-15)% increased Attack Damage while holding a Shield
{variant:1}+0.2% to Off Hand Critical Strike Chance per 10 Maximum Energy Shield on Shield
{variant:2,3}+0.15% to Off Hand Critical Strike Chance per 10 Maximum Energy Shield on Shield
+4% to Off Hand Critical Strike Multiplier per 10 Maximum Energy Shield on Shield
{variant:3}Corrupted
]],[[
Self-Flagellation
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Limited to: 1
(10-20)% increased Damage per Curse on you
An additional Curse can be applied to you
Corrupted
]],[[
Soul's Wick
Cobalt Jewel
Source: No longer obtainable
Variant: Pre 3.20.0
Variant: Current
Limited to: 1
+2 to maximum number of Spectres
(40-50)% reduced Mana Cost of Raise Spectre
Raised Spectres have (800-1000)% increased Critical Strike Chance
Raised Spectres have a Base Duration of 20 seconds
Spectres do not travel between Areas
{variant:2}Corrupted
]],[[
The Golden Rule
Viridian Jewel
Source: Use currency{Vaal Orb} on normal{Viridian Jewel}
Variant: Pre 3.20.0
Variant: Current
(30-40)% increased Armour while Bleeding
Bleeding you inflict is Reflected to you
+1% to Chaos Resistance per Poison on you
Poison you inflict is Reflected to you if you have fewer than 100 Poisons on you
{variant:2}Corrupted
]],[[
To Dust
Cobalt Jewel
Source: Use currency{Vaal Orb} on normal{Cobalt Jewel}
Variant: Pre 3.0.0
Variant: Pre 3.20.0
Variant: Current
(10-20)% reduced Skeleton Duration
Minions deal (8-12)% increased Damage
{variant:1}2% increased Skeleton Attack Speed
{variant:2,3}(7-10)% increased Skeleton Attack Speed
{variant:2,3}(7-10)% increased Skeleton Cast Speed
{variant:2,3}(3-5)% increased Skeleton Movement Speed
{variant:3}Corrupted
]],[[
Vaal Sentencing
Cobalt Jewel
Source: No longer obtainable
(80-120)% increased Vaal Skill Critical Strike Chance
Corrupted
]],[[
Weight of Sin
Viridian Jewel
Source: No longer obtainable
(15-20)% increased Chaos Damage
15% reduced Movement Speed
Corrupted
]],
-- Jewel: Quest rewards
[[
Assassin's Haste
Cobalt Jewel
Source: No longer obtainable
Limited to: 1
10% increased Mana Regeneration Rate
4% increased Movement Speed
4% increased Attack and Cast Speed
]],[[
Conqueror's Efficiency
Crimson Jewel
Source: No longer obtainable
Limited to: 1
3% reduced Mana Cost of Skills
4% increased Skill Effect Duration
4% increased Mana Reservation Efficiency of Skills
]],[[
Replica Conqueror's Efficiency
Crimson Jewel
Source: No longer obtainable
League: Heist
Limited to: 1
4% increased Skill Effect Duration
+5 to Maximum Rage
Non-Channelling Skills have -9 to Total Mana Cost
]],[[
Conqueror's Longevity
Viridian Jewel
Source: No longer obtainable
Variant: Pre 3.16.0
Variant: Current
Limited to: 1
{variant:1}+3% chance to Suppress Spell Damage
{variant:2}+5% chance to Suppress Spell Damage
{variant:1}3% chance to Avoid Elemental Ailments
{variant:2}10% chance to Avoid Elemental Ailments
{variant:1}8% increased Life Recovery from Flasks
{variant:2}10% increased Life Recovery from Flasks
]],[[
Conqueror's Potency
Cobalt Jewel
Source: No longer obtainable
Limited to: 1
4% increased Effect of your Curses
Flasks applied to you have 8% increased Effect
3% increased effect of Non-Curse Auras from your Skills
]],[[
Poacher's Aim
Viridian Jewel
Source: No longer obtainable
Limited to: 1
Projectiles Pierce an additional Target
10% increased Projectile Damage
]],[[
Survival Instincts
Viridian Jewel
Source: No longer obtainable
Limited to: 1 Survival
Variant: Pre 3.16.0
Variant: Current
{variant:1}+20 to Dexterity
{variant:1}+6% to all Elemental Resistances
{variant:2}20% reduced Flask Charges gained
{variant:2}50% increased Flask Effect Duration
Survival
]],[[
Survival Secrets
Cobalt Jewel
Source: No longer obtainable
Limited to: 1 Survival
Variant: Pre 3.16.0
Variant: Current
{variant:1}Regenerate 3 Mana per second
{variant:1}10% increased Elemental Damage
{variant:2}Flasks applied to you have 20% reduced Effect
{variant:2}Flasks gain 3 Charges every 3 seconds while they are inactive
Survival
]],[[
Survival Skills
Crimson Jewel
Source: No longer obtainable
Limited to: 1 Survival
Variant: Pre 3.16.0
Variant: Current
{variant:1}10% increased Global Physical Damage
{variant:1}+50 to Armour
{variant:2}Flasks gain 2 Charges when you hit a Non-Unique Enemy, no more than once per second
{variant:2}80% less Flask Charges gained from Kills
Survival
]],[[
Warlord's Reach
Crimson Jewel
Source: No longer obtainable
Variant: Pre 3.16.0
Variant: Current
Limited to: 1
{variant:1}8% increased Attack Damage
{variant:2}10% increased Attack Damage
{variant:1}+0.1 metres to Melee Strike Range
{variant:2}+0.2 metres to Melee Strike Range
]],[[
The Adorned
Crimson Jewel
Variant: Pre 3.25.0
Variant: Current
League: Affliction
Source: Vaal Aspect Combination
{variant:1}(50-150)% increased Effect of Jewel Socket Passive Skills containing Corrupted Magic Jewels
{variant:2}(0-100)% increased Effect of Jewel Socket Passive Skills containing Corrupted Magic Jewels
]],
-- Jewel: Labyrinth rewards
[[
Emperor's Cunning
Viridian Jewel
Source: Drops in The Eternal Labyrinth
Limited to: 1
(4-6)% increased Dexterity
20% increased Global Accuracy Rating
3% increased Character Size
]],[[
Emperor's Mastery
Prismatic Jewel
Source: Drops in The Eternal Labyrinth
Limited to: 1
(5-7)% increased Attributes
4% increased maximum Life
3% increased Character Size
5% increased Global Defences
]],[[
Emperor's Might
Crimson Jewel
Source: Drops in The Eternal Labyrinth
Limited to: 1
(4-6)% increased Strength
10% increased Damage
3% increased Character Size
]],[[
Emperor's Wit
Cobalt Jewel
Source: Drops in The Eternal Labyrinth
Limited to: 1
(4-6)% increased Intelligence
30% increased Global Critical Strike Chance
3% increased Character Size
]],
-- Jewel: Timeless
[[
Brutal Restraint
Timeless Jewel
League: Legion
Source: Drops from Maraketh Legion
Limited to: 1 Historic
Variant: Asenath (Dance with Death)
Variant: Deshret (Wind Dancer) (Pre 3.11.0)
Variant: Nasima (Second Sight)
Variant: Balbala (The Traitor)
Radius: Large
Implicits: 0
{variant:1}Denoted service of (500-8000) dekhara in the akhara of Asenath
{variant:2}Denoted service of (500-8000) dekhara in the akhara of Deshret
{variant:3}Denoted service of (500-8000) dekhara in the akhara of Nasima
{variant:4}Denoted service of (500-8000) dekhara in the akhara of Balbala
Passives in radius are Conquered by the Maraketh
Historic
]],[[
Elegant Hubris
Timeless Jewel
League: Legion
Source: Drops from Eternal Legion
Limited to: 1 Historic
Variant: Cadiro (Supreme Decadence)
Variant: Chitus (Supreme Ego) (Pre 3.11.0)
Variant: Victario (Supreme Grandstanding)
Variant: Caspiro (Supreme Ostentation)
Radius: Large
Implicits: 0
{variant:1}Commissioned (2000-160000) coins to commemorate Cadiro
{variant:2}Commissioned (2000-160000) coins to commemorate Chitus
{variant:3}Commissioned (2000-160000) coins to commemorate Victario
{variant:4}Commissioned (2000-160000) coins to commemorate Caspiro
Passives in radius are Conquered by the Eternal Empire
Historic
]],[[
Glorious Vanity
Timeless Jewel
League: Legion
Source: Drops from Vaal Legion
Limited to: 1 Historic
Variant: Doryani (Corrupted Soul)
Variant: Xibaqua (Divine Flesh)
Variant: Zerphi (Eternal Youth) (Pre 3.11.0)
Variant: Ahuana (Immortal Ambition)
Radius: Large
Implicits: 0
{variant:1}Bathed in the blood of (100-8000) sacrificed in the name of Doryani
{variant:2}Bathed in the blood of (100-8000) sacrificed in the name of Xibaqua
{variant:3}Bathed in the blood of (100-8000) sacrificed in the name of Zerphi
{variant:4}Bathed in the blood of (100-8000) sacrificed in the name of Ahuana
Passives in radius are Conquered by the Vaal
Historic
]],[[
Heroic Tragedy
Timeless Jewel
League: Legion
Source: Drops from Legion in Mirage
Limited to: 1 Historic
Variant: Vorana (Black Scythe Training)
Variant: Uhtred (Celestial Mathematics)
Variant: Medved (The Unbreaking Circle)
Radius: Large
Implicits: 0
{variant:1}Remembrancing (100-8000) songworthy deeds by the line of Vorana
{variant:2}Remembrancing (100-8000) songworthy deeds by the line of Uhtred
{variant:3}Remembrancing (100-8000) songworthy deeds by the line of Medved
Passives in radius are Conquered by the Kalguur
Historic
]],[[
Lethal Pride
Timeless Jewel
League: Legion
Source: Drops from Karui Legion
Limited to: 1 Historic
Variant: Kaom (Strength of Blood)
Variant: Kiloava (Glancing Blows) (Pre 3.11.0)
Variant: Rakiata (Tempered by War)
Variant: Akoya (Chainbreaker)
Radius: Large
Implicits: 0
{variant:1}Commanded leadership over (10000-18000) warriors under Kaom
{variant:2}Commanded leadership over (10000-18000) warriors under Kiloava
{variant:3}Commanded leadership over (10000-18000) warriors under Rakiata
{variant:4}Commanded leadership over (10000-18000) warriors under Akoya
Passives in radius are Conquered by the Karui
Historic
]],[[
Militant Faith
Timeless Jewel
League: Legion
Source: Drops from Templar Legion
Limited to: 1 Historic
Has Alt Variant: true
Has Alt Variant Two: true
Selected Variant: 1
Variant: Avarius (Power of Purpose)
Variant: Dominus (Inner Conviction)
Variant: Venarius (The Agnostic) (Pre 3.11.0)
Variant: Maxarius (Transcendence)
Variant: Totem Damage
Variant: Brand Damage
Variant: Channelling Damage
Variant: Area Damage
Variant: Elemental Damage
Variant: Elemental Resistances
Variant: Effect of non-Damaging Ailments
Variant: Elemental Ailment Duration
Variant: Duration of Curses
Variant: Minion Attack and Cast Speed
Variant: Minions Accuracy Rating
Variant: Mana Regen
Variant: Skill Cost (Pre 3.29.0)
Variant: Non-Curse Aura Effect
Variant: Defences from Shield
Variant: Skill Cost
Radius: Large
Implicits: 0
{variant:1}Carved to glorify (2000-10000) new faithful converted by High Templar Avarius
{variant:2}Carved to glorify (2000-10000) new faithful converted by High Templar Dominus
{variant:3}Carved to glorify (2000-10000) new faithful converted by High Templar Venarius
{variant:4}Carved to glorify (2000-10000) new faithful converted by High Templar Maxarius
{variant:8}4% increased Area Damage per 10 Devotion
{variant:20}3% increased Mana Cost Efficiency per 10 Devotion
{variant:7}Channelling Skills deal 4% increased Damage per 10 Devotion
{variant:9}4% increased Elemental Damage per 10 Devotion
{variant:10}+2% to all Elemental Resistances per 10 Devotion
{variant:17}1% reduced Mana Cost of Skills per 10 Devotion
{variant:16}Regenerate 0.6 Mana per Second per 10 Devotion
{variant:15}Minions have +60 to Accuracy Rating per 10 Devotion
{variant:14}1% increased Minion Attack and Cast Speed per 10 Devotion
{variant:18}1% increased effect of Non-Curse Auras per 10 Devotion
{variant:11}3% increased Effect of non-Damaging Ailments on Enemies per 10 Devotion
{variant:13}4% reduced Duration of Curses on you per 10 Devotion
{variant:12}4% reduced Elemental Ailment Duration on you per 10 Devotion
{variant:19}3% increased Defences from Equipped Shield per 10 Devotion
{variant:6}4% increased Brand Damage per 10 Devotion
{variant:5}4% increased Totem Damage per 10 Devotion
Passives in radius are Conquered by the Templars
Historic
]],[[
Festering Vengeance
Murderous Eye Jewel
League: Abyss
Source: Drops from unique{Zorath, Vile Assembled}
Limited to: 1 Historic
Implicits: 0
Subjugating (100-8000) souls in the thrall of Tecrod
Passives affected are Conquered by the Abyssal
Historic
]],[[
Extinguishing Grasp
Searching Eye Jewel
League: Abyss
Source: Drops from unique{Zorath, Vile Assembled}
Limited to: 1 Historic
Implicits: 0
Subjugating (100-8000) souls in the thrall of Ulaman
Passives affected are Conquered by the Abyssal
Historic
]],[[
Baleful Dominion
Hypnotic Eye Jewel
League: Abyss
Source: Drops from unique{Zorath, Vile Assembled}
Limited to: 1 Historic
Implicits: 0
Subjugating (100-8000) souls in the thrall of Kurgal
Passives affected are Conquered by the Abyssal
Historic
]],[[
Destructive Aspiration
Ghastly Eye Jewel
League: Abyss
Source: Drops from unique{Zorath, Vile Assembled}
Limited to: 1 Historic
Implicits: 0
Subjugating (100-8000) souls in the thrall of Amanamu
Passives affected are Conquered by the Abyssal
Historic
]],[[
Reclaimed Malevolence
Assembled Eye Jewel
League: Abyss
Source: Vendor Recipe
Limited to: 1 Historic
Implicits: 0
Binding (100-8000) souls to phylacteries to sustain Zorath
Passives affected are Conquered by the Abyssal
Historic
]],
}
