-- Item data (c) Grinding Gear Games

return {
-- Weapon: Staff
[[
Agnerod East
Imperial Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 66, 158 Str, 113 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+25% Chance to Block Spell Damage
40% increased Strength Requirement
+(80-120) to Intelligence
(30-50)% increased Lightning Damage
{variant:1}+1 to Level of all Lightning Spell Skill Gems
{variant:2,3}+2 to Level of all Lightning Spell Skill Gems
Damage Penetrates 20% Lightning Resistance
100% increased Duration of Lightning Ailments
]],[[
Agnerod North
Imperial Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 66, 158 Str, 113 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+25% Chance to Block Spell Damage
40% increased Strength Requirement
+(80-120) to Intelligence
(30-50)% increased Lightning Damage
{variant:1}+1 to Level of all Lightning Spell Skill Gems
{variant:2,3}+2 to Level of all Lightning Spell Skill Gems
15% chance to Shock
Damage Penetrates 20% Lightning Resistance
]],[[
Agnerod South
Imperial Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 66, 158 Str, 113 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+25% Chance to Block Spell Damage
40% increased Strength Requirement
+(80-120) to Intelligence
(30-50)% increased Lightning Damage
{variant:1}+1 to Level of all Lightning Spell Skill Gems
{variant:2,3}+2 to Level of all Lightning Spell Skill Gems
+5% to maximum Lightning Resistance
Damage Penetrates 20% Lightning Resistance
]],[[
Agnerod West
Imperial Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 66, 158 Str, 113 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+25% Chance to Block Spell Damage
40% increased Strength Requirement
+(80-120) to Intelligence
(30-50)% increased Lightning Damage
Adds (5-15) to (100-140) Lightning Damage to Spells
{variant:1}+1 to Level of all Lightning Spell Skill Gems
{variant:2,3}+2 to Level of all Lightning Spell Skill Gems
Damage Penetrates 20% Lightning Resistance
]],[[
The Annihilating Light
Quarterstaff
Variant: Pre 3.25.0
Variant: Current
Source: Drops from unique{The Searing Exarch} (Uber)
Requires Level 68, 78 Str, 78 Int
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+22% Chance to Block Spell Damage
(60-70)% reduced Elemental Resistances
Deal Triple Damage with Elemental Skills
]],[[
Atziri's Rule
Judgement Staff
Variant: Pre 3.25.0
Variant: Pre 3.29.0
Variant: Current
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Alluring Abyss}
Requires Level 68, 113 Str, 113 Int
Implicits: 2
{variant:2,3}+25% Chance to Block Attack Damage
{variant:1}+20% Chance to Block Spell Damage
Grants Level 20 Queen's Demand Skill
Queen's Demand can Trigger Level 20 Flames of Judgement
Queen's Demand can Trigger Level 20 Storm of Judgement
{variant:3}(100-300)% increased Spell Critical Strike Chance
Cannot be Stunned
Damage cannot be Reflected
]],[[
The Winds of Fate
Foul Staff
Variant: Pre 3.25.0
Variant: Pre 3.26.0
Variant: Current
League: Sanctum
Source: Drops from unique{Lycia, Herald of the Scourge} in normal{The Beyond}
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2,3}+22% Chance to Block Attack Damage
(700-800)% increased Physical Damage
{variant:1,2}+100% to Global Critical Strike Multiplier
{variant:3}+(100-150)% to Global Critical Strike Multiplier
75% of Physical Damage converted to a random Element
25% of Physical Damage Converted to Chaos Damage
Maximum Critical Strike Chance is 50%
Non-Critical Strikes deal no Damage
]],[[
The Blood Thorn
Gnarled Branch
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Spell Damage
+12% Chance to Block Attack Damage while wielding a Staff
100% increased Physical Damage
(5-10)% increased Attack Speed
Reflects (22-44) Physical Damage to Attackers on Block
Curse Enemies with Vulnerability on Block
]],[[
Replica Blood Thorn
Gnarled Branch
Variant: Pre 3.25.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+20% Chance to Block Spell Damage
+12% Chance to Block Attack Damage while wielding a Staff
(100-200)% increased Fire Damage
(5-10)% increased Attack Speed
Curse Enemies with Flammability on Block
Reflects (22-44) Fire Damage to Attackers on Block
]],[[
The Broken Elegy
Foul Staff
League: Mirage
Source: No longer obtainable
LevelReq: 64
Implicits: 1
+22% Chance to Block Attack Damage
Trigger level 25 Ceaseless Flesh once every second
Minions deal (113-157)% increased Damage
(17-31)% increased Minion Duration
When a nearby Minion dies, gain Rotten Bulwark equal to (7-9)% of its maximum Life
Minions gain (59-83)% of Physical Damage as Extra Chaos Damage
]],[[
Cane of Unravelling
Ezomyte Staff
Variant: Pre 3.5.0
Variant: Pre 3.11.0
Variant: Pre 3.25.0
Variant: Pre 3.29.0
Variant: Current
Requires Level: 60, 113 Str, 113 Int
Implicits: 3
{variant:1,2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Attack Damage
{variant:4,5}+25% Chance to Block Attack Damage
{variant:2,3,4,5}+(40-55)% to Chaos Damage over Time Multiplier
{variant:1}(60-80)% increased Chaos Damage
{variant:2,3,4}(20-30)% increased Chaos Damage
+2 to Level of all Chaos Spell Skill Gems
{variant:5}+1 to Maximum Power Charges
{variant:1,2,3,4}2% increased Cast Speed per Power Charge
{variant:5}5% increased Cast Speed per Power Charge
{variant:1,2,3,4}Regenerate 2 Mana per Second per Power Charge
{variant:5}Regenerate 5 Mana per Second per Power Charge
Gain a Power Charge after Spending a total of 200 Mana
]],[[
The Crustacean's Call
Primordial Staff
League: Allflame
Source: Drops from unique{Velka, the Tide Witch}
Socketed Spells are Supported by level 20 Crab Totem
Totems have 100% increased Movement Speed
(150-200)% increased Spell Damage
(50-75)% increased Totem Duration
+2 to maximum number of Summoned Totems
+25% Chance to Block Spell Damage
]],[[
Disintegrator
Maelstrom Staff
Shaper Item
Elder Item
Source: Drops from unique{The Elder} (Uber)
Variant: Pre 3.7.0
Variant: Pre 3.11.0
Variant: Pre 3.13.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 64, 113 Str, 113 Int
Implicits: 2
{variant:1,2}+20% Chance to Block Attack Damage
{variant:3,4,5}+25% Chance to Block Attack Damage
{variant:1}Adds (270-300) to (340-380) Physical Damage
{variant:2}Adds (250-280) to (315-355) Physical Damage
{variant:3,4,5}Adds (220-240) to (270-300) Physical Damage
+1 to Maximum Siphoning Charges per Elder or Shaper Item Equipped
25% chance to gain a Siphoning Charge when you use a Skill
{variant:1,2,3,4}Adds (12-14) to (15-16) Physical Damage to Attacks and Spells per Siphoning Charge
{variant:5}Adds (20-23) to (26-30) Physical Damage to Attacks and Spells per Siphoning Charge
Gain 4% of Non-Chaos Damage as extra Chaos Damage per Siphoning Charge
{variant:1,2,3,4}1% additional Physical Damage Reduction from Hits per Siphoning Charge
{variant:5}2% additional Physical Damage Reduction from Hits per Siphoning Charge
0.2% of Damage Leeched as Life per Siphoning Charge
Take 150 Physical Damage per Second per Siphoning Charge if you've used a Skill Recently
{variant:1,2,3,4,5}Battlemage
]],[[
Duskdawn
Maelström Staff
Source: Vendor Recipe
Variant: Pre 2.6.0
Variant: Pre 3.5.0
Variant: Pre 3.11.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 64, 113 Str, 113 Int
Implicits: 3
{variant:1}+18% Chance to Block Attack Damage
{variant:2,3}+20% Chance to Block Attack Damage
{variant:4,5}+25% Chance to Block Attack Damage
{variant:1,2}+4% Chance to Block Attack Damage while wielding a Staff
{variant:3,4}+10% Chance to Block Attack Damage while wielding a Staff
{variant:5}+(20-30)% Chance to Block Attack Damage while wielding a Staff
(60-80)% increased Spell Critical Strike Chance
Gain (10-20)% of Elemental Damage as Extra Chaos Damage
+1% to Critical Strike Multiplier per 1% Chance to Block Attack Damage
+60% to Critical Strike Multiplier if you've dealt a Non-Critical Strike Recently
{variant:1,2}120% increased Spell Damage if you've dealt a Critical Strike Recently
{variant:3,4}(120-150)% increased Spell Damage if you've dealt a Critical Strike Recently
]],[[
Replica Duskdawn
Maelström Staff
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Variant: Pre 3.29.0
Variant: Current
Requires Level 64, 113 Str, 113 Int
Implicits: 1
+25% Chance to Block Attack Damage
{variant:1}+10% Chance to Block Attack Damage while wielding a Staff
{variant:2}+(20-30)% Chance to Block Attack Damage while wielding a Staff
(40-50)% increased Critical Strike Chance
Gain (10-20)% of Elemental Damage as Extra Chaos Damage
+1% to Critical Strike Multiplier per 1% Chance to Block Attack Damage
+60% to Critical Strike Multiplier if you've dealt a Non-Critical Strike Recently
(120-150)% increased Elemental Damage if you've dealt a Critical Strike Recently
]],[[
Dying Breath
{variant:1}Coiled Staff
{variant:2}Iron Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Implicits: 2
{variant:1,2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Attack Damage
18% increased Cast Speed
18% increased maximum Mana
18% increased Area of Effect of Aura Skills
18% increased Area of Effect of Hex Skills
Nearby Enemies have 18% increased Effect of Curses on them
Nearby allies gain 18% increased Damage
18% increased effect of Non-Curse Auras from your Skills
]],[[
The Enmity Divine
Imperial Staff
League: Harbinger
Source: Created from item parts obtained from Boss in The Beachhead
Upgrade: Upgrades to unique{The Yielding Mortality} via currency{Haemocombustion Scroll}
Variant: Pre 3.11.0
Variant: Pre 3.25.0
Variant: Pre 3.26.0
Variant: Current
Requires Level 66, 113 Str, 113 Int
Implicits: 2
{variant:2}+18% Chance to Block Attack Damage
{variant:3,4}+25% Chance to Block Spell Damage
{variant:1}Socketed Gems are supported by Level 10 Life Leech
{variant:2,3,4}Socketed Gems are supported by Level 1 Chance to Bleed
Grants Summon Harbinger of Brutality Skill
+5% Chance to Block Attack Damage while wielding a Staff
{variant:2,3}+(30-40)% to Damage over Time Multiplier for Bleeding from Critical Strikes
{variant:4}+(60-80)% to Damage over Time Multiplier for Bleeding from Critical Strikes
{variant:1,2,3}Adds (160-185) to (200-225) Physical Damage
{variant:4}Adds (225-265) to (315-385) Physical Damage
(30-40)% increased Critical Strike Chance
]],[[
The Yielding Mortality
Imperial Staff
Variant: Pre 3.25.0
Variant: Pre 3.26.0
Variant: Current
League: Harvest
Source: Upgraded from unique{The Enmity Divine} via currency{Haemocombustion Scroll}
Requires Level 66, 113 Str, 113 Int
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2,3}+25% Chance to Block Spell Damage
Socketed Gems are supported by Level 1 Chance to Bleed
Grants Summon Greater Harbinger of Brutality Skill
+5% Chance to Block Attack Damage while wielding a Staff
{variant:1,2}+(30-40)% to Damage over Time Multiplier for Bleeding from Critical Strikes
{variant:3}+(60-80)% to Damage over Time Multiplier for Bleeding from Critical Strikes
{variant:1,2}Adds (160-185) to (200-225) Physical Damage
{variant:3}Adds (225-265) to (315-385) Physical Damage
(30-40)% increased Critical Strike Chance
]],[[
Femurs of the Saints
Primordial Staff
Variant: Pre 2.6.0
Variant: Pre 3.8.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 58, 99 Str, 99 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2,3}+18% Chance to Block Attack Damage
{variant:4}+25% Chance to Block Spell Damage
+2 to Level of Socketed Minion Gems
{variant:3,4}Minions deal (60-80)% increased Damage
{variant:1,2}Minions Regenerate (1.5-2.5)% of Life per second
{variant:1,2}2% increased Minion Attack and Cast Speed per Skeleton you own
{variant:1,2}2% increased Minion Duration per Raised Zombie
{variant:1,2}(8-12)% increased Minion Damage per Raised Spectre
{variant:3,4}+1% Chance to Block Attack Damage per Summoned Skeleton
{variant:3,4}2% increased Attack and Cast Speed per Summoned Raging Spirit
{variant:3,4}Regenerate 0.6% of Life per second for each Raised Zombie
{variant:3,4}30% increased Mana Regeneration Rate per Raised Spectre
]],[[
Fencoil
Gnarled Branch
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Spell Damage
Socketed Gems are Supported by Level 8 Trap
(40-50)% increased Global Damage
(10-20)% increased maximum Life
(10-20)% increased maximum Mana
]],[[
Replica Fencoil
Gnarled Branch
Variant: Pre 3.25.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+20% Chance to Block Spell Damage
Socketed Gems are Supported by Level 1 Multiple Totems
(40-50)% increased Global Damage
(10-20)% increased maximum Life
(10-20)% increased maximum Mana
]],[[
The Burden of Shadows
Primordial Staff
Variant: Pre 3.25.0
Variant: Current
League: Affliction
Requires Level 58, 99 Str, 99 Int
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+25% Chance to Block Spell Damage
Socketed Gems are Supported by Level 1 Lifetap
(20-30)% increased Cast Speed
Lose 500 Life per second
Spells deal added Chaos Damage equal to (15-20)% of your maximum Life
]],[[
The Fulcrum
Ezomyte Staff
Variant: Pre 3.25.0
Variant: Current
League: Heist
Source: Steal from a unique{Curio Display} during a Grand Heist
Requires Level 60, 113 Str, 113 Int
Implicits: 2
{variant:1}+20% Chance to Block Attack Damage
{variant:2}+25% Chance to Block Attack Damage
(140-180)% increased Physical Damage
(0-50)% of Physical Damage Converted to Fire Damage
(0-50)% of Physical Damage Converted to Cold Damage
(0-50)% of Physical Damage Converted to Lightning Damage
Elemental Ailments you inflict are Reflected to you
Elemental Damage with Hits is Lucky while you are Shocked
Damage Penetrates (8-10)% Elemental Resistances while you are Chilled
Gain (30-40)% of Physical Damage as Extra Damage of a random Element while you are Ignited
]],[[
Mirebough
Gnarled Branch
Variant: Pre 3.25.0
Variant: Current
Source: No longer obtainable
Requires Level 32
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+20% Chance to Block Spell Damage
Socketed Gems are Supported by Level 16 Trap
Socketed Gems are Supported by Level 16 Cluster Trap
Socketed Gems are Supported by Level 16 Trap And Mine Damage
(40-50)% increased Global Damage
(10-20)% increased maximum Life
(10-20)% increased maximum Mana
]],[[
The Grey Spire
Judgement Staff
Variant: Pre 3.11.0
Variant: Pre 3.25.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 68, 113 Str, 113 Int
Implicits: 3
{variant:1}+18% Chance to Block Attack Damage
{variant:3,4}+25% Chance to Block Attack Damage
{variant:2}+20% Chance to Block Spell Damage
Has no Sockets
{variant:1,2,3}(250-300)% increased Global Damage
{variant:4}(300-400)% increased Global Damage
(20-30)% increased Attack Speed
{variant:1,2,3}+(1-4)% to all maximum Resistances
{variant:4}+(1-5)% to all maximum Resistances
{variant:4}Implicit Modifier magnitudes are doubled
]],[[
Hegemony's Era
Judgement Staff
Variant: Pre 2.6.0
Variant: Pre 3.7.0
Variant: Pre 3.11.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 68, 113 Str, 113 Int
Implicits: 4
{variant:1}+12% Chance to Block Attack Damage
{variant:2,3}+18% Chance to Block Attack Damage
{variant:5}+25% Chance to Block Attack Damage
{variant:4}+20% Chance to Block Spell Damage
+6% Chance to Block Attack Damage while wielding a Staff
{variant:1,2}Adds (180-190) to (190-220) Physical Damage
{variant:3}Adds (165-175) to (185-205) Physical Damage
{variant:4,5}Adds (135-145) to (160-175) Physical Damage
(12-16)% increased Attack Speed
{variant:1,2,3}(20-30)% increased Critical Strike Chance
{variant:4,5}(10-20)% increased Critical Strike Chance
+1 to Maximum Power Charges
10% chance to gain a Power Charge if you Knock an Enemy Back with Melee Damage
]],[[
Jiquani's Potential
Imperial Staff
Source: Drops from unique{It That Was Esh} and unique{It That Was Tul} in normal{Hive Colony}
Variant: Pre 3.29.0
Variant: Current
Requires Level 66, 113 Str, 113 Dex
Implicits: 1
+25% Chance to Block Spell Damage
(1-7)% increased Intelligence
(-17-17)% reduced maximum Life
+(-1-1) to Level of all Spell Skill Gems
31% increased Cost of Skills
{variant:1}Adds 1 to (32-53) Lightning Damage to Spells per 10 Intelligence
{variant:2}Adds 1 to (24-35) Lightning Damage to Spells per 10 Intelligence
Blood Magic
]],[[
Legacy of the Rose
Judgement Staff
Variant: Shaper's Despair
Variant: Shaper's Ire
Variant: Shaper's Devastation
Source: Drops from unique{Incarnation of Neglect} in normal{Moment of Loneliness}
Requires Level 68, 113 Str, 113 Int
Implicits: 1
+25% Chance to Block Attack Damage
{variant:1}Grants Level 20 Summon Shaper Memory
{variant:1}Grants Level 20 Shaper's Despair, which will be used by Shaper Memory
{variant:2}Grants Level 20 Summon Shaper Memory
{variant:2}Grants Level 20 Shaper's Ire, which will be used by Shaper Memory
{variant:3}Grants Level 20 Summon Shaper Memory
{variant:3}Grants Level 20 Shaper's Devastation, which will be used by Shaper Memory
(200-300)% increased Physical Damage
(25-40)% increased Cast Speed
+(3-5) to Level of all Spell Skill Gems
Gain 1 Remembrance when you spend a total of 200 Energy
Shield with no Shaper Memory Summoned
Maximum 10 Remembrance
Eldritch Battery
]],[[
Martyr of Innocence
Highborn Staff
Variant: Pre 3.5.0
Variant: Pre 3.13.0
Variant: Pre 3.25.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 52, 89 Str, 89 Int
Implicits: 2
{variant:1,2,3}+18% Chance to Block Attack Damage
{variant:4}+22% Chance to Block Spell Damage
{variant:1,2,3,4}+(12-16)% Chance to Block Attack Damage while wielding a Staff
{variant:5}+(20-25)% Chance to Block Attack Damage while wielding a Staff
{variant:1,2,3,4}100% increased Fire Damage
{variant:5}100% increased Fire Damage
{variant:1,2}Adds (350-400) to (500-600) Fire Damage
{variant:3,4,5}Adds (315-360) to (450-540) Fire Damage
Damage Penetrates 15% of Fire Resistance if you have Blocked Recently
Immune to Freeze and Chill while Ignited
Battlemage
]],[[
Pillar of the Caged God
Iron Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 13, 27 Str, 27 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Attack Damage
1% increased Area of Effect per 20 Intelligence
1% increased Attack Speed per 10 Dexterity
16% increased Physical Weapon Damage per 10 Strength
]],[[
Pledge of Hands
Judgement Staff
League: Legion
Source: Drops from unique{Atziri, Queen of the Vaal} in normal{The Apex of Sacrifice}
Variant: Pre 2.6.0
Variant: Pre 3.11.0
Variant: Pre 3.15.0
Variant: Pre 3.25.0
Variant: Pre 3.28.0
Variant: Current
Requires Level 68, 113 Str, 113 Int
Implicits: 4
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:5,6}+25% Chance to Block Attack Damage
{variant:3,4}+20% Chance to Block Spell Damage
{variant:1,2,3,4,5}Socketed Gems are Supported by Level 1 Greater Spell Echo
{variant:6}Socketed Gems are Supported by Level 1 Greater Spell Echo
(120-160)% increased Spell Damage
{variant:1,2,3}100% increased maximum Mana
{variant:4,5}50% increased maximum Mana
{variant:6}(50-100)% increased maximum Mana
]],[[
Realmshaper
Iron Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 18, 35 Str, 35 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3,4}+20% Chance to Block Attack Damage
{variant:1,2,3}+1 to Level of Socketed Fire Gems
{variant:4}+2 to Level of Socketed Fire Gems
{variant:1,2,3}+1 to Level of Socketed Cold Gems
{variant:4}+2 to Level of Socketed Cold Gems
Socketed Gems are Supported by Level 5 Cold to Fire
Adds (10-15) to (20-25) Fire Damage
Adds (10-15) to (20-25) Cold Damage
(30-50)% increased Elemental Damage
]],[[
Realm Ender
Iron Staff
Source: No longer obtainable
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 40, 35 Str, 35 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Attack Damage
+2 to Level of Socketed Fire Gems
+2 to Level of Socketed Cold Gems
+2 to Level of Socketed Elemental Gems
Socketed Gems are Supported by Level 5 Cold to Fire
Adds (10-15) to (20-25) Fire Damage
Adds (10-15) to (20-25) Cold Damage
(30-50)% increased Elemental Damage
]],[[
The Searing Touch
{variant:1}Long Staff
{variant:2,3,4,5,6,7}Lathi
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.0.0
Variant: Pre 3.8.0
Variant: Pre 3.25.0
Variant: Pre 3.29.0
Variant: Current
Implicits: 3
{variant:1,2}+12% Chance to Block Attack Damage
{variant:3,4,5}+18% Chance to Block Attack Damage
{variant:6,7}+25% Chance to Block Attack Damage
{variant:1,2,3}(30-50)% increased Spell Damage
{variant:5,6,7}+(40-60)% to Fire Damage over Time Multiplier
{variant:1,2,3}(20-40)% increased Fire Damage
{variant:4,5,6,7}(70-90)% increased Fire Damage
{variant:1,2,3,4,5,6}10% increased Cast Speed
{variant:7}(20-40)% increased Cast Speed
+2 to Level of all Fire Spell Skill Gems
{variant:1,2,3,4}70% increased Burning Damage
{variant:7}Voracious Flame
]],[[
Sire of Shards
Serpentine Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 49, 85 Str, 85 Int
Implicits: 3
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+20% Chance to Block Attack Damage
{variant:3}+22% Chance to Block Attack Damage
Socketed Gems fire 4 additional Projectiles
Socketed Gems fire Projectiles in a circle
+(15-20) to all Attributes
+(5-7)% to all Elemental Resistances
(60-100)% increased Projectile Damage
20% increased Light Radius
]],[[
Soulwrest
Ezomyte Staff
League: Delve
Variant: Pre 3.11.0
Variant: Pre 3.25.0
Variant: Pre 3.26.0
Variant: Current
Requires Level 62, 113 Str, 113 Int
Implicits: 3
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+20% Chance to Block Attack Damage
{variant:3,4}+25% Chance to Block Attack Damage
{variant:1,2,3}Trigger Level 20 Summon Phantasm Skill when you Consume a corpse
{variant:4}Trigger Level 25 Summon Phantasm Skill when you Consume a corpse
(100-140)% increased Spell Damage
(25-30)% increased Cast Speed
(80-100)% increased Mana Regeneration Rate
{variant:1,2,3}Minions deal (45-51) to (66-78) additional Physical Damage
{variant:4}Minions deal (90-102) to (132-156) additional Physical Damage
If you Consumed a corpse Recently, you and nearby Allies Regenerate 5% of Life per second
]],[[
The Stormheart
Royal Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 28, 51 Str, 51 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Spell Damage
(80-100)% increased Physical Damage
Adds (25-35) to (45-60) Cold Damage
Adds (1-10) to (70-90) Lightning Damage
(20-35)% increased Critical Strike Chance
{variant:1}You cannot be Shocked while Frozen
{variant:2,3}100% chance to Avoid being Shocked while Chilled
{variant:2,3}50% chance to Shock Chilled Enemies
]],[[
The Stormwall
Royal Staff
Variant: Pre 3.25.0
Variant: Current
Source: No longer obtainable
Requires Level 60, 51 Str, 51 Int
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+20% Chance to Block Spell Damage
+15% Chance to Block Attack Damage while wielding a Staff
Adds (242-260) to (268-285) Physical Damage
(20-35)% increased Critical Strike Chance
50% of Physical Damage Converted to Cold Damage
50% of Physical Damage Converted to Lightning Damage
100% chance to Avoid being Shocked while Chilled
(30-40)% chance to Chill Attackers for 4 seconds on Block
(30-40)% chance to Shock Attackers for 4 seconds on Block
]],[[
Taryn's Shiver
Maelström Staff
Variant: Pre 2.0.0
Variant: Pre 2.6.0
Variant: Pre 3.11.0
Variant: Pre 3.29.0
Variant: Current
Requires Level 64, 113 Str, 113 Int
Implicits: 3
{variant:1,2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Attack Damage
{variant:4,5}+25% Chance to Block Attack Damage
{variant:1}(40-50)% increased Spell Damage
{variant:2,3,4}(50-60)% increased Spell Damage
{variant:1,2,3,4}(40-50)% increased Cold Damage
{variant:5}(80-140)% increased Cold Damage
(10-20)% increased Cast Speed
{variant:1,2}+1 to Level of all Cold Spell Skill Gems
{variant:3,4}+2 to Level of all Cold Spell Skill Gems
{variant:5}+(2-4) to Level of all Cold Spell Skill Gems
{variant:1,2,3,4}8% chance to Freeze
{variant:5}(25-50)% chance to Freeze
Enemies Frozen by you take 20% increased Damage
{variant:5}Bitter Frost
]],[[
Tremor Rod
Military Staff
Variant: Pre 2.6.0
Variant: Pre 3.8.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 45, 78 Str, 78 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2,3}+18% Chance to Block Attack Damage
{variant:4}+22% Chance to Block Attack Damage
{variant:3,4}+2 to Level of Socketed Spell Gems
{variant:1,2,3,4}Socketed Gems are Supported by Level 10 Blastchain Mine
{variant:1,2}35% less Mine Damage
(40-60)% increased Spell Damage
(15-20)% reduced Enemy Stun Threshold
{variant:1,2}(40-60)% increased Mine Throwing Speed
Mines can be Detonated an additional time
]],[[
The Whispering Ice
Vile Staff
Variant: Pre 2.6.0
Variant: Pre 3.25.0
Variant: Current
Requires Level 33, 59 Str, 59 Int
Implicits: 3
{variant:1}+12% Chance to Block Attack Damage
{variant:2}+18% Chance to Block Attack Damage
{variant:3}+20% Chance to Block Attack Damage
+1 to Level of Socketed Support Gems
Grants Level 1 Icestorm Skill
(14-18)% increased Intelligence
(8-12)% increased Cast Speed
1% increased Spell Damage per 10 Intelligence
]],[[
Witchhunter's Judgment
Highborn Staff
Variant: Pre 3.25.0
Variant: Current
League: Harvest
Source: Drops from unique{Oshabi, Avatar of the Grove}
Requires Level 68, 89 Str, 89 Int
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+22% Chance to Block Spell Damage
Grants Level 20 Brandsurge Skill
Brand Skills have (50-100)% increased Duration
]],[[
The Geomantic Gyre
Highborn Staff
Variant: Pre 3.25.0
Variant: Current
League: Crucible
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage
{variant:2}+22% Chance to Block Attack Damage
Has 1 Socket
(150-200)% increased Spell Damage
(80-120)% increased Spell Critical Strike Chance
+(150-200) to maximum Mana
Gain 150 Life per Enemy Killed
Has a Crucible Passive Skill Tree with only Support Passive Skills
Crucible Passive Skill Tree is removed if this Modifier is removed
]],[[
Xirgil's Crank
Coiled Staff
Source: Drops in The Lord's Labyrinth
Variant: Pre 2.6.0
Variant: Pre 3.26.0
Variant: Current
Requires Level 28, 43 Str, 43 Int
Implicits: 2
{variant:1}+18% Chance to Block Attack Damage while wielding a Staff
{variant:2,3}+20% Chance to Block Attack Damage while wielding a Staff
+15% Chance to Block Attack Damage while wielding a Staff
(60-80)% increased Spell Damage
{variant:1,2}+(70-100) to maximum Energy Shield
{variant:3}+(70-150) to maximum Energy Shield
+1 to Level of all Spell Skill Gems
Reflects 1 to 150 Lightning Damage to Melee Attackers
{variant:1,2}20% chance for Energy Shield Recharge to start when you Block
{variant:3}(25-35)% chance for Energy Shield Recharge to start when you Block
]],
}
